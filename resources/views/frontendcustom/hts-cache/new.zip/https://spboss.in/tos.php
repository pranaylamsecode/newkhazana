<!DOCTYPE html><html lang="en-in"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SPBOSS - Terms & Conditions (tos) Satta Matka </title>
<meta name="Description" content="Here We Are Giving You All The Information about satta matka terms and conditions like - 
lifetime matka,d matka app,matka guessing photo,today open to close fix,golden fix open to close,satta matka gossip,kalyan matka gossip, matka guessing home facebook" />
<link rel="canonical" href="https://spboss.in/tos.php" />
<meta http-equiv="refresh" content="900" />
<meta name="google" content="notranslate" />
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="yes" name="apple-touch-fullscreen">
<meta name="Robots" content="index, follow">
<meta name="author" content="SPBOSS">
<meta name="copyright" content="SPBOSS net satta matka" />
<meta property="og:type" content="website">
<meta property="og:title" content="Satta Matka">
<meta property="og:description" content="SattaMatka">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="https://spboss.in/fav/favicon.ico">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html{overflow-x:hidden;scroll-behavior:smooth}.dp-topbox{border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px}.dp-topbox h1{font-size:16px;color:#1a237e;padding-bottom:3px}.dp-topbox p{color:#444;font-size:14px}body{background-color:#fc9;text-align:center;padding:3px 10px;margin:0;scroll-behavior:smooth;font-style:italic;font-family:Helvetica,sans-serif;font-weight:700}*{margin:0;padding:0;box-sizing:border-box}a,a:hover{text-decoration:none}.about-us a,.about-us b,.about-us p,.disclamer h2,.disclamer p,.faq a,.faq h4,.faq p,.ftr-sm h2,.ftr-sm p,.pby-us{font-style:normal}.about-us,.blue-div,.cm-patti,.conta,.disclamer,.faq,.ftr-sm,.matka-result,.mrque-div,.paid-gm,.pby-us,.purpel-header,.red-list>div,.satta-result,.satta-text,.slash-text{color:#000;text-align:center;margin-bottom:8px;margin-top:-2px;display:block;font-size:20px;outline:4px #fff;outline-offset:-9px;border:2px solid #ff182c!important;border-style:outset;border-radius:10px;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}.logo{background:#fc9;padding:0 10px;display:block;color:#fff8f8!important;margin-bottom:20px;letter-spacing:1px;font-weight:700;border:3px solid #ff0016;border-radius:.75em;transform-style:preserve-3d;transition:transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1)}.para1{margin-bottom:5px;display:flex;padding:5px;align-items:center;justify-content:space-between;border-radius:10px;border:2px solid #ff182c;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}p{color:#000b65;text-shadow:1px 1px 2px #fff}.para2{border-width:3px;border:2px solid #0014e2;margin-bottom:5px;border-style:outset;border-radius:10px;border:2px solid #ff182c;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}.para2 h1{background:-webkit-linear-gradient(#ff019c,#72000a);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.para2 h5{color:#061699!important;text-shadow:1px 1px 2px #fff}.para3{background:linear-gradient(187deg,#fc9 50%,#ffc387 50%);border:2px solid #ff0016;border-style:outset;border-radius:10px;margin-bottom:5px;line-height:1.4;font-size:14px;padding:4px 10px;color:#00094d;text-shadow:1px 1px 2px #fff;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}table{box-shadow:0 0 20px 0 rgb(0 0 0 / 40%);margin:5px 0}.paid-gm p,.satta-result div{border-bottom:1px solid #ff0018}.logo img{height:73px;padding:6px 0 0}.mrque-div{display:flex;padding:5px;align-items:center}.mrque-div img{width:90px;height:auto;border-radius:5px}.mrque-div marquee{color:red;font-size:15px;height:21px;display:inline-block}.mrque-div p{padding:0 20px;color:red}.satta-text{padding:5px;height:100px}@media only screen and (max-width:500px){.satta-text{height:150px}}.satta-text h1{font-size:16px;color:#1a237e;padding-bottom:3px}.satta-text p{color:#444;font-size:14px}.cm-patti{border-color:#ff0016}.cm-patti .row{display:-webkit-flex;display:-moz-flex;display:-ms-flex;display:-o-flex;display:flex}.cm-patti .row>div{width:50%}.cm-patti h4{font-size:24px;color:#001699;text-shadow:1px 1px 2px #fff}.cm-patti p{font-size:22px;text-shadow:none}.cm-patti .aa55{border-right:1px solid #ff0016}.cm-patti .bb55{border-left:1px solid #000ff4}.a-27-title,.banner,.cm-patti h3,.fg-div h4,.matka-result h4,.my-table.mumraj-sl h4{background:#ff00a2;padding:5px 10px;text-shadow:1px 1px 2px #000;display:block;color:#fff8f8!important;margin-bottom:20px;letter-spacing:1px;font-weight:700;border:2px solid #fff;border-radius:.75em;transform-style:preserve-3d;transition:transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1)}.a-27-title::before,.banner::before,.cm-patti h3::before,.fg-div h4::before,.matka-result h4::before,.my-table.mumraj-sl h4::before{position:absolute;content:"";width:100%;height:100%;top:0;left:0;right:0;bottom:0;background:#ff182c;border-radius:inherit;transform:translate3d(0,.75em,-1em);transition:transform 150ms cubic-bezier(0,0,.58,1),box-shadow 150ms cubic-bezier(0,0,.58,1)}.matka-card h6{font-size:22px;color:#00094d;text-shadow:1px 1px 2px #fff}.matka-card h6:not(:first-child){border-top:1px solid #ff0020;margin-top:5px}.matka-card h5{color:#880e4f;text-shadow:1px 1px 2px #ffe2c6;font-size:21px;line-height:1;margin:3px 0}.matka-card a,.refresh-btn{border:1px solid #e6e6e6;background:#522f92;color:#fff;padding:5px 7px;border-radius:8px;font-size:12px;margin:2px 0 -1px;display:inline-block;transition:all .3s}.matka-card a:hover,.refresh-btn:hover{box-shadow:0 0 13px 3px #00000033;cursor:pointer}.conta{padding-top:4px;padding-bottom:7px;background-color:#fbe7ff;display:-webkit-flex;display:-moz-flex;display:-ms-flex;display:-o-flex;display:flex;-ms-align-items:center;align-items:center;justify-content:center}.conta p{font-size:22px;color:#ed143d;display:flex;flex-direction:column;justify-content:center;margin-right:12px}.conta a:hover{box-shadow:0 0 10px 0 #000}.slash-text{color:#000;line-height:1.4;font-size:14px;padding:4px 10px;text-shadow:1px 1px #f4e1e1}.satta-result h4{font-size:22px;color:#00094d;text-shadow:1px 1px 2px #fff}.satta-result h5{margin:0;font-size:22px;line-height:1;background:-webkit-linear-gradient(#4500bf,#670009);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.satta-result h6{font-size:15px;padding:2px 0;margin-bottom:0;color:#000;text-shadow:1px 1px 2px #ffd9d9}.satta-result div{padding:3px}.satta-result div:last-child{border-bottom-width:0}.yellowbg{background-color:#ff0;border-bottom:1px solid #ff9800!important}.paid-gm{border-color:#085e58}.paid-gm h4{background-color:#085e58;color:#fff;font-size:28px;padding:3px 0 4px}.paid-gm img{border:2px solid #085e58;border-radius:10px 0 10px 10px;width:250px;height:auto;margin-top:4px}.paid-gm p{padding:6px 20px;text-shadow:1px 1px 2px #eee}.paid-gm .aa,.paid-gm .bb{color:#000;font-size:18px}.paid-gm .bb,.paid-gm .cc,.paid-gm .dd{color:#085e58}.paid-gm .cc{font-size:19px}.paid-gm .dd{font-size:20px}.paid-gm .ee{color:#e91e63;padding-bottom:3px;font-size:21px}.paid-gm .ff{color:#e91e63;font-size:15px}.paid-gm .telegram1{border:2px solid #ff006c;background-color:#ff006c;color:#fff;padding:3px 7px;border-radius:8px 0;box-shadow:0 0 1px #000000d6;font-size:12px;margin:2px 0 -1px;display:inline-block;transition:all .3s;top:auto;position:fixed;left:10px;right:auto}.btn-hide{display:none!important}.gg{color:#000;font-size:32px}.paid-gm span{display:block}.my-table{margin-bottom:2px}.my-table h4{border:solid 2px #ff002b;border-bottom-width:0;padding:3px 5px 2px;font-size:24px}.my-table table{border-collapse:collapse;width:100%}.my-table thead{background-color:#fff;font-size:16px}.my-table tbody{font-size:16px}.my-table td,.my-table th{border:1px solid #ff0016}.my-table td,.my-table th{padding:2px 0;font-size:15px;text-shadow:1px 1px 2px #fff}.my-table th{color:#e91e63}.my-table tr td:nth-child(2),.my-table tr td:nth-child(4){color:#0808b2}.my-table.cm-sl h4,.my-table.mr-sl h4{background:#ffd902;padding:5px 10px;text-shadow:1px 1px 2px #fff;display:block;color:#000!important;margin-bottom:20px;margin-top:10px;letter-spacing:1px;font-weight:700;border:2px solid #000;border-radius:.75em;transform-style:preserve-3d;transition:transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1)}.my-table.cm-sl h4::before,.my-table.mr-sl h4::before{position:absolute;content:"";width:100%;height:100%;top:0;left:0;right:0;bottom:0;background:#ffb002;border-radius:inherit;transform:translate3d(0,.75em,-1em);transition:transform 150ms cubic-bezier(0,0,.58,1),box-shadow 150ms cubic-bezier(0,0,.58,1)}.blue-div{border:2px solid #1f3092}.blue-div h4{background:#ff1731;color:#fff;border-radius:10px;font-size:30px;padding:3px 5px;text-shadow:1px 1px 2px #000;clip-path:polygon(0 0,97% 0,100% 48%,100% 80%,100% 100%,3% 100%,0 46%,0 20%)}.blue-div a:last-child{border-bottom-width:0}.blue-div a{background-image:linear-gradient(-225deg,#231557 0,#44107a 29%,#ff1361 67%,#ff0025 100%);background-size:200% auto;color:#fff;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:textclip 2s linear infinite;font-size:22px;display:block;border-bottom:2px solid #ff0026;padding:5px}@keyframes textclip{to{background-position:200% center}}.red-list>div{border-color:#e71d36}.red-list h4{animation:changeBackgroundColor 5s infinite;border-radius:10px;color:#fff;line-height:1.1;padding:4px 10px 3px;text-shadow:1px 1px 2px #000;font-size:24px}.red-list p{font-size:18px;text-align:center;line-height:1.3}.purpel-header h4{color:#fff;padding:5px 10px 3px;font-size:24px}.purpel-header a{display:block;font-size:22px;padding:5px 7px 4px}.ab1 a{border-bottom:2px solid #00189f;color:#1a237e;text-shadow:1px 1px #d9d9d9}.purpel-header a:last-child{border-bottom-width:0}.ab1{border-color:#00189f!important}.ab2 a{border-bottom:2px solid #b9005e;color:#880e4f;text-shadow:1px 1px 2px #ffe2c6}.ab2{border-color:#b9005e!important}.faq h4{color:#d70544;font-size:22px;padding:5px 5px 6px;border-top:1.5px solid #e0557f;margin-top:5px}.faq h4:first-child{border-top-width:0;margin-top:0}.faq p{font-size:12px;padding:0 5px 15px;line-height:1.4;color:#1a1a1a}.faq a{color:#d70544;text-decoration:underline}.ftr-sm h2{color:#bb2833;text-shadow:1px 1px 2px #fff}@media only screen and (max-width:768px){.faq h4{font-size:15px}}.about-us span{border:1px solid #e6e6e6;background:#522f92;color:#fff;padding:5px 7px;border-radius:8px;font-size:12px;margin:2px 0 -1px;display:inline-block}.disclamer h4{font-size:18px;margin-bottom:15px;padding-top:4px;text-shadow:1px 1px 3px #000}.disclamer p{font-size:13px;color:#340d7a;padding:2px 5px 5px;line-height:1.2}.about-us{padding:5px}.about-us p{font-size:13px;margin-bottom:0;color:#000;padding-bottom:15px}.about-us b{color:#0013a5;text-transform:uppercase}.about-us a{background-color:#e91e63;color:#fff;padding:4px 6px;display:inline-block;text-shadow:1px 1px 2px #2f2f2f;border-radius:4px}.ftr-sm{padding:5px}.ftr-sm h4{font-size:18px;margin-bottom:4px;color:#d3003f}.ftr-sm p{color:#a50031;font-size:12px;line-height:1.4}.pby-us{text-shadow:1px 1px #f4e1e1;color:#000;padding-top:2px;padding-bottom:1px}.refresh-btn{position:fixed;bottom:10px;right:10px}.bdr-b-0{border-width:0!important}.p-0{padding:0!important}@media only screen and (max-width:500px){body{padding:2px 5px}.faq h4{font-size:15px}}.result_timing,.result_timing_right{position:absolute;color:#7a028d;font-size:15px;padding:2px 0;transform:translateY(-158%);border-bottom:none!important}.result_timing{left:14px;right:auto}.result_timing_right{right:14px;left:auto}.btn_chart{color:#fff;padding:5px 7px;border-radius:8px;font-size:12px;margin:2px -5px -1px;display:block;transition:all .3s;text-shadow:1px 1px 2px #222;margin-top:5px;border:1px solid #e6e6e6;background:#522f92}@media(max-width:500px){.btn_chart{margin:2px -9px -1px}}.mb-1{margin-bottom:5px}.p-1{padding:5px 10px 8px}.bdr{border:2px solid #ff001d;border-radius:10px;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}.fg-div h6{font-size:22px;background-color:transparent;color:#1a237e;text-shadow:1px 1px 2px #fff}.fg-div h5{font-size:22px;color:#000;text-shadow:1px 1px 2px #fff}.fg-div .fg-p1{font-size:22px}.fg-div .fg-c1>div{border:2px solid #008906;border-radius:10px;margin:5px 0;padding:5px}.fg-div .fg-c1 .fg-p2{text-shadow:1px 1px 0 #fff;letter-spacing:1px}.fg-div .fg-c1 .fg-p3{font-size:22px;color:#080808;text-shadow:1px 1px 2px #ffe2c6}.fg-div .fg-c1 .fg-p4{font-size:20px}.login-div{margin:0 0 0;padding:6px 30px;margin-bottom:10px}.login-div a{border-radius:5px;font-size:14px}.login-div a:nth-child(2),.nnb8{margin:0 10px}@media only screen and (max-width:500px){.login-div{display:block}.login-div a{display:block;margin:10px 0!important}.conta p{display:block;font-size:17px}.conta{display:block}.conta a{margin-top:5px}}.fg-c1{width:50%;display:inline-block;padding:5px;border-color:#009206;border-style:solid}.fg-div .fg-c1 .fg-p2{background:linear-gradient(#00d309,#004503);font-size:22px!important;margin-bottom:5px;padding:7px 0 7px;border-radius:10px;clip-path:polygon(0 0,97% 0,100% 48%,100% 80%,100% 100%,3% 100%,0 46%,0 20%);color:#fff;text-shadow:1px 1px 2px red}.fg-div .fg-c1 .fg-p4{font-size:20px!important;line-height:24px}p.time{text-align:left;color:#444;margin-left:10px}p.betting{color:#ff0;font-size:12px;text-shadow:1px 1px 2px #000}.paa3{border-radius:10px;border:2px solid #ff001e;border-style:outset;margin:10px 0;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%);text-shadow:1px 1px 2px #fff;padding:10px}.btn{display:inline-block;font-weight:400;line-height:1.5;color:#212529;text-align:center;text-decoration:none;vertical-align:middle;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;user-select:none;background-color:transparent;border:1px solid transparent;padding:3px 10px;margin:4px 0 1px;font-size:1rem;border-radius:.25rem;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;cursor:pointer}.btn-primary{color:#fff;background-color:#0d6efd;border-color:#0d6efd}.btn-danger{color:#fff;background-color:#dc3545;border-color:#dc3545}.fg-main.para-1.bdr.mb-1.p-1{padding:0}.fg-main.para-1.bdr.mb-1.p-1 *{font-style:normal!important}.fgzoc-time{border:2px solid #ff019e;margin:5px 5px 0;border-radius:10px}@media only screen and (max-width:600px){.fg-div .fg-c1 .fg-p2{font-size:14px!important}.fg-div .fg-c1 .fg-p4{font-size:9px!important;line-height:20px}}.card-1212{display:flex;flex-wrap:wrap;margin:5px;border-radius:10px;overflow:hidden}.fg-c1:nth-child(odd){border-width:0 1px 2px 2px!important;margin:0;border-radius:0}.fg-c1:nth-child(even){border-width:0 2px 2px 1px!important;margin:0;border-radius:0}.card-1212 .fg-c1:nth-child(1),.card-1212 .fg-c1:nth-child(2){border-top-width:2px!important}.faq{border:2px solid #003db6;border-radius:10px;width:calc(100% - 8px);padding:3px 0;margin:5px auto 5px;width:auto;display:block}.faq p{color:#000;font-weight:700;text-transform:uppercase;margin:0;font-size:12px;font-style:normal;padding:0 10px 5px;text-transform:capitalize;opacity:.9}.faq a{color:#d70544;font-weight:700;text-transform:capitalize;text-decoration:none}.my-checkbox{position:fixed;top:0;left:-9999px;visibility:hidden}.faq label{cursor:pointer;text-transform:uppercase;color:#0013a5;text-shadow:1px 1px 2px #fff;font-weight:800;font-size:17px;padding:3px 0;display:block}.faq label+div{height:0;overflow:hidden;transition:all .3s;padding:0!important}.faq label+div{height:auto}.faq .faq-card{border-top:1.5px solid #e0557f}.faq .faq-card.aabbcc{border-top:0 solid #dc1f44}@media only screen and (max-width:500px){.faq label{font-size:15px}}@media only screen and (max-width:375px){.faq label{font-size:13px}}@media only screen and (max-width:320px){.faq label{font-size:11px}}.mp-btn{position:fixed;bottom:9px;left:5px;padding:5px 8px;font-size:15px;border:1px solid #fff;text-decoration:none;background-color:#039;color:#fff;border-radius:5px}.btm-btn-f{background:linear-gradient(45deg,navy,#005780);border:1px solid #fff;font-size:14px;border-radius:5px;padding:6px 11px 5px;transition:all .3s ease-in}.btm-btn-f:hover{border:1px solid #011481;background:#fff;box-shadow:0 0 13px 3px #00000033;cursor:pointer;color:navy;background:linear-gradient(45deg,#fff,#dbdbdb)}.let-rock{border:2px solid #ff0020;border-radius:10px;font-style:normal;padding:3px 0;margin:5px auto 5px;width:auto;display:block;font-weight:600;font-family:roboto,sans-serif;height:200px;overflow-y:scroll}.let-rock .t-rock{cursor:pointer;text-transform:uppercase;color:#0013a5;text-shadow:1px 1px 2px #fff;font-weight:800;font-size:17px;padding:4px 0 3px;border-top:1.5px solid #e0557f;margin-top:8px;font-style:italic;font-weight:700}.let-rock p{padding:0 10px;font-size:14px;margin-bottom:0;color:#000;padding-bottom:0}.let-rock a{color:#e91e63}.let-rock i{margin:5px 0;display:block;padding:0 10px;font-size:14px;margin-bottom:7px;color:#000;padding-bottom:0;text-shadow:1px 1px #f4e1e1}.let-rock ul{text-align:left;padding:0 10px;list-style:none;font-size:13px;margin-bottom:0;margin:0 10px 0;color:#000;text-shadow:1px 1px #f4e1e1;border:1px solid #e91e63;border-radius:5px;margin-bottom:12px}.let-rock li{margin:7px 0}.t-0{margin-top:0!important;border-top:0!important}@keyframes changeBackgroundColor{0%{background-color:#ff019e}25%{background-color:#ff001d}50%{background-color:#009a07}75%{background-color:#001fad}100%{background-color:#ff019e}}

.red-list-bg-change{
  animation: changeBackgroundColor 5s infinite;
  border-radius: 10px;
  color: #fff;
  line-height: 1.1;
  padding: 4px 10px 3px;
  text-shadow: 1px 1px 2px #000;
  font-size: 24px;
}

.red-list-bg-change h3{
  font-size: 22px;
}

.red-list-bg-change a{
  color:white; 
}

.form-group label {
  text-align: left !important;
  display: block;
  color: #373737;
  font-size: 15px;
}

.form-group {
  padding: 0px 9px;
}

.address div {
  text-align: left;
  font-size: 12px;
}
.address {
  margin-top: 34px;
  padding-left: 79px;
}

.conta h4 {
  background: #ff00a2;
  padding: 5px 10px;
    padding-top: 5px;
  padding-top: 5px;
  text-shadow: 1px 1px 2px #000;
  display: block;
  color: #fff8f8 !important;
  margin-bottom: 20px;
  letter-spacing: 1px;
  font-weight: 700;
  border: 2px solid #fff;
  border-radius: .75em;
  transform-style: preserve-3d;
  transition: transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1);
}

.conta h4::before {
  position: absolute;
  content: "";
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: #ff182c;
  border-radius: inherit;
  transform: translate3d(0,.75em,-1em);
  transition: transform 150ms cubic-bezier(0,0,.58,1),box-shadow 150ms cubic-bezier(0,0,.58,1);
}
</style>
</head>
<body>
<style>.B1{background-color:#FFCC99;color:black;border-width:3px;border-color:#FF006C;border-style:solid;border-top-left-radius:10px;border-top-right-radius:2px;border-bottom-left-radius:2px;margin-top:1px;margin-bottom:1px;font-weight:bold;font-size:x-large;font-style:none;text-shadow:1px 1px navy;padding-top:1px;padding-bottom:1px;padding-left:2px;padding-right:2px;}
.button2 {
  background-color: #fff0; /* Green */
  border: none;
  color: navy;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  border-radius:5px;
  border: lime 2px solid;
font-weight: 800;
text-shadow: 1px 1px aqua;
cursor: pointer;
}

.button2 {
  box-shadow: 0 8px 10px 0 rgba(0,0,0,0.2), 0 6px 8px 0 rgba(0,0,0,0.19);
}

</style>
<div class="B1" align="center" style="box-shadow: 0 8px 0px -3px #ff9628;">
<a href="https://spboss.in/">
<img src=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkgAAACSCAYAAAC+JDXPAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAALNNJREFUeJztnQuQXcWZ3xtsnsaAMcYUZvGYsDZhgcWUVsXykGeBZVmiJZiwlEzAUQixWUdxFIqiKEKxE4LlmTsUhQnLqjAhUxizKpeCCSsDy1JIGDAPiVdkjLEAScYg3XsQj+VpcJXy/XXOXa6v76O/73SfPlf6/6r+hTEzp7/umTn93e7v4RwhhBBCCCGEEEIIIaTGtNz0ji3XODhzjRMzNz1fNCFaLLpedLvori7dVvz3q0QXiebJ9x8hz9kt9VwIIYQQQkxkW5yh6QWiGdGTol+LNgfSc6I7RJeJ0zSHThMhhBBCaknTNXYQp+hfirPyVXFclohWi94O6BT10geiF0QPii4VZ+lYsWPX1GtBCCGEkG0ccYgOLJwinOhsjOwQDdO7okdEDdEfwWlLvT6EEEII2YYQB+Rw0Q2i9Ymdon56VfQ9cd5OQfxT6vUihBBCyFZM5hq7i+PxTdGaGjhBPspEC1KvGyGEEEK2Qta5ie3F0Zgner4GTo9F92x0kzunXkdCCCGEbCW03PRRWR7bk9rJKatlov1SrychhBBCRhxxKC6tgWMTUrxuI4QQQoiNjW5yx5abvlAcijdq4NSE1HWp15YQQgghI0jLNQ4SR+KHNXBmYmhZ6vUlhBBCyIhROEf318CRiaUbUq8xIYQQQkaIpmvskeV90FI7MTF1Zep1JoQQQsiIgBR4cR6urYEDE1sLU681IYQQQkYEcRyW1sB5qUJzU681IYQQQkYAcRrOr4HjUoVQVXt26vUmhBBCSM1pucae4jQ8WwPnpQrdnbnG76Vec0IIIYTUHHEarqvYSXlX9IxoeZbHPKEQ5cIsb2MiaiyQf14sukb0I9FKUTPE2OIMLnrJfYuNawkhhBDSH3EazhD9ugKn6H3RKjg+4qQc23RT+/ra2HLTu8n3HSI6uXCoVlttlmedHHM9CSGEEDLiZK7xKXEaflqBc/SOOEWXiD4Zwm55zt7yzLmZoZBl0zV2DWEDIYQQQrZSxGE4uwLn6B5xxA6JOIcjRbeIXvOxJZYdhBBCCNkKKK6tVsZ0jmSMmYrng7ilNwfYdFpV9hBCCCFkBBFn4SRrHI+nbk4xr2Z+/Xa1aFOXPStS2EMIIYSQEUIchkZE5+hXLdc4MN3cGrvL+H8hdtyR5eULVrfc9NGp7CGEEELICNB0jU+I0/BkJOeoJRpPPUcg89xBnKX9RHuntoUQQgghNUccmONE70VykP625aY/knqOhBBCCCEqsnhtRd4RfSn1/AghhBBC1IgTsySSg/R0yzX2ST0/QgghhBAVG90k+q49FMlBWpp6ftsSL7tvIxh9XNb9ItGVWH/RXVlesRwFQO8p/n1J8d8XtNzUofI7sHNq2wkhhJBagTYfslE+H8lBujj1/Kqg5aZ3bG1pfdI4Mcv7x10omugS/r95WG/52r1Cjd10jVlZXsbg0cxepgG98G6HfU0GsBNCCCFbrtfOEr0SyUGal3p+MRFn53Pi7Exng4tR9hMcmjkb3eT2+nGn95CxzyhOg0L/zDa1tjhy02zgSwghZNsly6tNf0AHSYc4EKfJ/J4ouT7rRQf7jilfi6KX54geyOJlHUI4ibpVnLCDxYH7aMx1JIQQQmqJbIRXRNxoz0o9v1jI3NYGWqPxYWPhSi7Lr+hWi96P+PPq1gbRX4s+VsGSEkIIIfVBNr/r4m2wjQtSzy8GhcMSYo1eF31x0FhN1zhAvuapCp2ibr0v8/0fVa0tIYQQUgtkA1wccXPdKrPYimDsEOvzdMtN9SyDgMyylmtcLl+TJXSO2npXnKTzq15nQgghJBmRHaS1srGOpZ5jaLL8uivE+tzfK8ZHHKOxLE/JT+0Ydept0ddSrDchhBBSObLpTUbeWC9NPcfQZOEKa17Z/Wxxjk7K8tif1A5RT4l9p6VYc0IIIaRSsrxGT8xN9Veiw1PPMyQyn5+FcTamz+18Lv49tQPkoadZAoAQQshWT5Zvyq9H3lR/3nRT+6eeawjgHGT2goydQjbalzqee6b8+xs1cIB8HLv5CX8EhBBCSHxkw5sjeqGCjfVh2Vj3TT3fsmSuMTvQevxS1uNf4Jnyz+NHxTkq9HzTNXZN/bPYRtlJtJtoD9F+hXYrtFNCu0Kyi8vn8ynR/u7D+dUZnKrCRlTJh817Fv/+kZRGEUJKIJsz0sgfr+jkYcVGN1n3F91AsnDXYI+jIrasB0oGNGvg9Gh/lqen/llsI2DDPUPUEC0X/US0UvS46NlCKwvhv/296LLie4K1tIkMnIvj3YdzfNjl8/mpaI37cH74b9eJvuxyJyolsPkI0X9z+Zo/6HIbn3K5zU8U//5j0Q0iJDiMys+DENJGNrzbKtxcn8hc45DUc7aS5U1eQ6wD1nwf0dOpnR2jlrZco2eJAgOoJj4pWhxI1xXPm3C5o3Ckyz/RjwI4fUBs2hLRL0SbS+pJl68JqtrX6cMJfuZw5FaI3nT2uV0tmlWRzehTiHIXd5W0eUY0VzSKTaLPc/nv5irRz0XrXT6vN4t/h1N7m+gKUdn3w47FeNe64X/zSHjBh7YqTrbhGC8SoYzNAy6fd1tw7jF/vIP+rAJbSGxko1tY8eaKlPErRvGaJsvbfJReg5abvkz+eX0NHJ0yOqPkcuLnD0emrBPgK5y24MWFl26dnAXYgo0Xm07M+WMTw2ZyYjXT+h0wzwtFDw2w0arnRMiY3T2wzdikz4xkM5yLq1zuFNcd/Oy0f6vXlhhvvug15XjQapc7MLE4WGHLqoh2kKqQje7ILE0MzEOio1LPX0Nma0zbS9cUjmJqJ6eMbi65nHAKqnKOejkLeOHvXXIOZUB2JxwWy0ZQVjgFGYs+ww+BU5oFnkMvPSMK9U6BzY9VYDN+F88OZHMscOqP0yHNvC40jnWys5/QtXWocexhLFTYQAdpawBxQbLZPZhok0UG3VVo35F6HYYhNh4RaM7viF6qgYNTVk/ImlivrhC8iviMqh2Dbm0Q/UfRDsZ5WED8zALR6wHnYdEm0RyXn5LE4guieyue1yOunOOLU6iZim3eXNLm2Jzk9POZaxhne5dfUZVdyyWGsX24UWHD30aygVSNbHYXJd5s0W/sTNlwUwdf9iVzjYtr4JR0613RetGaQvjfVTW0fUV0mHE5P+PCxNiE0Fuiy101gb+43kKcwnsVzm+QcKqDXnsx5g7na3WCOcHptRY0Rabt3Qls3lzC5irQnJxAr4r+0DAO1v8Z5Vi99LboAMP4w3hYYcNXIoxPUoCUc9nsfpl4s0d9oXtbrvFlcUZqlbIs6/MRse0fauAQQSi++XeiBaKjZK0OFO1fSP739AmtvB3Ks7FtKZHNhsDassfoIQWH5WIX7zQF8VaX1mzOnXNHUG3IvzmcHrQDeKvWRpcH7Fpsjh0HNkh1zgy9yenmAifHUtYl5HvhEsP4g8C74V3Psd93eXII2RpY5ya2k83u2zXY/CFcQX1PHKUjevUqS4HYI87HlhOalOvyAn5Gsi5fgMPmYfN+oqWRbZowLulZLr1j0K1XXB4XFRqclv2gBvMbpHdEXw80X8TupHKOIATjazPbjk1s82aDzVWBAG2ULNDMBadwlhpQId8LKw3jD+IIxdhIGtgv8PgkJbLxIlh7Uw0cpLZQEuC81OsCxBYUiEwZVP2ArMUccWS319iN4pzyvS9GtGupcUlxYpFyM+qnNcb59AOpzktrMC8fPe3KB7ciI2tD4nk85nSZYYg5uiOxzZuVNlcJrqqed7q5WDPYQr8XQpb3OEMxLuLganULQgIgG978GjhGv+MctNxUrKwEL8R5PCPV/MXJubik7SdmeWxSDPseNPZmW+bSb0j9NG6YTy9wxaCJWaiDHig55xUBbPi1yz+Bt2vLaLPfblPaPBHAZmhdh83a06jXlDZXCbICfa+W2rJ+sA39Xgj1ARvvuCsV41o/OJK6Ixve1TVwinrp+qabSnJsKWNPJpjvilagMgjynCsi2bg6cw1t9g2+Xhu8i4KAEwOEwm0zLj8FKftSvVI5n14gKzNU9hZOZJYU80QRyXkdWljYu8LlgakhxjvZOOf5JcbEyR2uN1Fnpte1Oq55EPSN4pJPDXnWQoXNuNbaZLQZ34fgfly99Cr6iE11tsvT3e8Z8iytU1clcDI06wJnz/Lews8+dFD/MoMdvcAp2rCfYacWBBqX1I0i7X9DDRyiXsJJyOwq1wPxWXBWKp7nKnFqPhNqDvK8o7MwTXa79bw4SNpskT9w8Nl0LzrNKdUfu9yh+LVyjLbuUc6nGwRk/41x7Lbwif1Rlx/r+4L+bHAkXyk59h2GOSPexOqcLjaMhdYkqOXU/TNGwPkfez4H19X3lbBZG4R8RGHzqz2ed4HyWVWCYpaatUH5js8ZxkFBTu17wUchisLCkdZcHZ8UYExSV2RzHs/q20AVMTXntVyjkvYRTTe5Z7YlHqqy+a2W9Q8asIm2IFmctiboI6dtHYOXx2+c/8vmWcOU4VB9w+mvBqCfGsbrBCc6bxnGhbAuuOY6VfQxw9hwHo5x+qyjTmHNtKeC5xjG+SfRf3H2lhtwRLFOnfW0EBzsu25zDDZDV5W0GQ7c910eGI/n4cQlVNue0OD3SVv2AM6jxSmZcLr3gq9COJ/zFOPhfWUtf0JGBdmkz8y2XKEkd4h6CfV/VrQq6Osm4xyW5TV/qpjXqtDOEdjoJreXZ98ZwV4U+vyi0pzvON0L7sYSU79BORb08xLjoZaN9eSqKfrPok+WGL8NHMSrjXZA5yrG+oTLe4xpno+NEGUPQnS7R5A1UvRxzXq44vssTiRO10KUgkAA7wkud7YsBRWrwlKXSPO700msQHk0Di77YVrTZmUmwHhkFMBmXWMnCXoJQchx16Axt6K5PBryWq2bLFyj3W6NK01BAK7mBVcm9X62cqwyDhJOXawZXIjBCV03Bacc1k1HU4n4OKcvfPkz0afLTK4kiHN6o4ddw6RxwLYG8OFHW/Hd2gvN92/nPaf7fcPPuUxYhvYUDUk125UYj4wSsgGentUr/b9ba8WxOCje/BsLKprHsbHmkM9jOlYl8HGFGTh6125KZRzgvQ3jWa/YLjaMBaEwXqyehCcbbdKswXzD88v28SvLmNPb/GIKQxOD0y3tOlmu1zTvBZxWrlHaVOZDljapxJrkQEaVlmvgJGlVDZyhfnoRV4Ix5p7FL7ZYOpXfB/kZnl0DBwnOThUv3DYWh8ySUYSrXmsF4NgtJm432uUbZ2O5ytMEn8fgNKe3uUx3+lEF16CaNbJ+uNC8F65x+n5tCI63Fh3GqaEm07HOPfVITIoWFqmdoX56Q+wLmj3wslu0qzz3kch2l82a8kLGmVcDBwkpz5oX23Mlpz2mHA/SpvlbyhZAOPqvov/WuLPFRfnWHltuePZ42UmVZMLpbZ5IYGdqtI6I9WRQ815ACr2maCOE+D5rvKrmFC0zjkG2FlqucbJsilkNHKJeWtN0U2Oh5pq5xpg8c21Ee9/JKgg0z+dSCwdpxulebGXrw1iumE5VjnG+YQyLI2ZlTLTWYN+4x7MRn9GZRTYqDtIiRwdpGCgb8bjTrZH1JHxGMQZ61qG5sjZD9WyjbZcpxrjdOAbZmiiCt3+Yb/DJnaJu3RCqBIA86zjR+5HsfE9UWf2TSA7SW6I/UpihzXaaKDnty5Xj4aWr+d3B1z6oHANCKnC0uLkukPb+qMHGeR7PtvTpKrNZhWKx09t8QxJL04HfT8RdadbIGn/j+15AE9hjiu9ZobTtFpfXvtKyRDFGVR96SN3JXGMncUS+nFVbI8hHKAFwXYg5yvxitl5ZJo7mLiHs9CGSg4STRN+rGKRHa696ylxBYbxnleNpWwRY0vqR4v6f7NMycafSRl8HCb+/lnYqsMdaSygE1/Sxa5BQr2hbSt/+U9EHTrdG2uKZQPNeWOc+LEKpOdmBXhB9Vmnbx0WrFGOcpXw+2dpp5V3jL8q2VFVO7hy19Ws0dy07N3nO9ZHse1V0zHALwiHjLYwwDxTt9D0JsaTcl2ktc65yLNR70WQS4sVucTxw4vKpEvOycL3BTh8HCSw3PBsndSjkaflEH4KJIfb104yzB/uOGpraP9B64zia9wL+dnYzfB+EDyb/Xmkb2p9oSneMKZ9PthXEUTpWNstnauActaWp5fI7rHMTH5Vn3BfJtjuarrFrqLX3IYuT5r9GHFHfLuS4VtG80DaVmC5OJ7QF7q5QjvF50UvKMaAUfZosV0q+DtJSw7MhXN9Ya+aUZYGnjb1URWB9HdD2ErQmm2jeC8s7vm9npX2bizlpONrpToi3FeeZWClOKmJ1j1dJnJCDrfNoualDszjtOd4WHR9yzX3I4jQhfqLpH++l6YYN3WKcKo75b1aOhSw0bXruQuUY0JPGOZUlpoOkzUzsVpkaNVZmlbC3bfPulVtdHZbyGNb4G817oXuMuwx2avYETQLGw4rnkm0ZnI7I5okCi6kLTM5Y51DY/3YEm+7Y6CYrj7/I4tRzul/m4vupCT3GNC+y0w3THHf6kyOkAGsr7cKZekQ5DnSeYU4hiOkg4VrS0vOuU8hWtMSvWMHv7GslbX7M5ScMWyP4mWrXw1rbSvNemN/1vZaTwEsVtmlaFW2LdbJIGTa6KTRJvUL0WionSZw1U+GulmtcG8meA0Kv8/C5TO8oYz8YYT6aoGZNIUVN3RJsdog3m3H6gOnVxfdqOV85n83F16cK8rVcg417PtuaydYtOCy45qyqcavFaewWHEMkhJhPqmuK5XTUmpXp+3eEte6uOL+/wU7fYpaIMdRkqKa4OiejDjK1ZCM9I0sWn9SwnETgxOXuCPY8FHp9fWi5qb1k7KcizMf3WB3B1pqXWMvljVvnDRBOY7Chot8YMlS0ncARPwTnaAfDkloanWrjH0KyfIBd/aRpmvxXhuf3Enps4doECQwhGtkO4qSANsPRRiX/EI1s64DWeYTzYpn7FxRjvFx8fScI8l+rtBUfonxOK9EX8xeK526tp4mkClqusa9sqDNZ9bWTZppuSvXJfZ2b2D6LcL0mzuL8SMs7EBn7oCzPOAu9tr7xI5bWDjGFTdhaoBMnVpbg7G8YxyuLNRVfk0EIZ2a5YYx+ekX0fRe+gW8n2FxnAtqMjff2wuadItpdBdrfF2v8jaZ/IdLtP97jGZaSDT7vLXxA0JwSl2mJRAiu3CaRGfYXWbWnSWhmq8qWabrJsQh2vCvzT3LFImN/KQtf8PI3ohM8TZhw1Tg+g4RP+si0wcuxzMvsCOP4B5YYswy4snra08ZOaTNysC5l43q6hUxGbKKxAqJxkvBQBJu/69L9vMuCkyBtTNliwzhwqv9BMUa/rOQ5Slshn9Pcryue96zvpAkZijgsp8rm2qzQSZqrsU++/uQINqyKtZ7DaLlGjCKRiCvzdTw11WhjCJtWqPgWS2uRlD2aLBWRrfZqMxV9hefG+oSOq7G3I9i8zI1mXRz8vmjmCWdqoWEcbQ/DfmU4kPCiaSYLvemGFyq9RfE8bYFZQgYjTtKcCp0kTeYCHKQrItgwGWstPeZzZYT5PN1yU74OB5rOxnJ+fIXsNvTgGjcvZM61hrFL1eQqCQJbtScCK0qMN2MYz0dw2mLVIDo/os3nRrI5FtpGsM87XYHVNoc7nWMz6EPupUqbN7vhWXca27Q11AgZTuYaCN7eUIGDpOqjlEVJiW+MR1rGgYgjulsWJ4PtPsRqeZiwl4vn9Fi1wtkzjzStB9qyfMIOxTcG2NVPV5ccEwH02iw/H8GJiVU3CTZrqiZrNBPJ5hhoTwGR6WU53ZurGAMfsA4f8CzEEzaVdg/60HKo4jk4nbX2oCNkMLLRjlfgIC1X2pSFtiFF7aN8Lg2s79oIa+p7IvY1F2fTKSts4DiR0MbaWMayfMIOhaWYXoiUZRRD1fbC8xGcpIkA9vUCaeMrItgMzUSyOTSI09PMy1r/5wrFGHBmBpVrwd+w9vccf//9HLv5iuc8MsQ2QuxErNHTqRXr3MR2Pva85L61W4Tx18Rex37I2JdkW3rTBZ+Tb2NGTbG1qoVPf5oCd/sax6myCGInCLi1nOSESFlGEO6fuLDZbZ2bW6zrtjGXF64MbfO7hc11LwWAnmqaeVlPRzVxiRNueNkHbfNa6Jw+z5pQPANlRlL1FCTbAi3XODWyg/SIb++zzDWOjjB+shgUGfveCPN5VnSYx/DabtgphBgK35R/S8bM657PjoHFXmzkIU878Skd11drDbYMEuJ7yjQzHsTOhc2o8qytrzXM5jr3ctN+APjA5SeFWrTvBZ81QzX8N5T2I5ut1+/6MsUzLlHMmxA9uH7K4rT1aGslYnF8bMniNHVN8keEsgIy9rsR5nO9OJK9apJ0o+2G/b7o/7g8bXiYkDlyv8uDr99RjNFLNzq/q7ZzDc++3eO5sbh8gF39tCKSLWMuX+dfGmzqJ0t6uYZPunwDDGnzT0SfiGy3lVOcbi44gbVU0Na+F3wcYbzfNZWvIQRi98rE1ZyiqTKkCTEhm+7DER2kh3xjgCK1GEkSxNeKU64A8g2U1XbDRgHGzyumiJ8pXnAXuHL1bHAFur/HeBOGZ6fs0aSNJ4HKBmgPAk4oNpSnDHb1Ek5kYhfo276w2RLL1UsoKVB5s2pPtI2H8XPcyzCO5r3wpuK5lgzTs7ueoWnUi5+lto8jIXpk010S0UFarrAjuKP2sluUJIhPxr4hxno23ZSPMwG0NYPQANRaFBAb2XynP2ZvyycWyfICTlVBe2+FjZ0ar8A2XHd/04UpLBkrq60X+KCzNoDNKcs+9AO/L9p6ZbcZx9K8Fx5QPBeOp7YfI054O2OINIVgUYC1qt6BZFtGNt7FER0krz/kdW5ixwhjr4+9dr0o0vvfjDAf32aPQBugfVOAqeMToWXj9TnpmTE819QLMACWTudYN21WXxlw+lA2iP+eCu0FuxU2lyljgLi3yptWDwFp9Np6Zar6ch1ofua+/R6BtvgkhPdzZ9Vzzd8NA7RJNWRxT5C8rg1abur40GO3XOPy2GvXCxn7vEhr6ftS1HbDhk4NMHWMaykcd58b7hxYrlnGA8zJwpOe9nVKVS8sIBZnri3NFUxIcFqhrb3TFk456tbcVFOXqC1L/I32vdB9BTYMSzZb5+mxpg4UC0SSapCN956IDtJFnjZ8O/C4vxEH6V/HXrs+c7kjxlrKfOZ4mqDthr25+J4QzFaOC/nUMxkVBwlxXNqrhpZoXgJbAa7cNK0dupXiNGYHl8e+vWewt3tTrgN4R2rsR3bmFw3jaN8L2hgfS6/Eqzq+X1PiwbfUCSHlkM13fSwHSTb1oWmiL7lvxajHtCFzDWvFZjMtN314Fqf20YtoOOxpBoojajbpkLWidlSM29ZKN7xe0Sg4SMguvNpgJ64LvEphRALXbY/2sMtH/yqBvWAX0fc9bezWBQnsHYQ2/gjZo5b6XrOc//Uk3h+WulErlXPB793Hiu993vN73izmQkhcxIHZP5ZzJFrb8miqKo7M78nXPhd47FWe6fDBkDE/kUUKzpZ11MQDzHe6l9StIddBOXZMB+mEgHPy4ctOH6j+fvF9qcHppCXIPuVpDK7KtM2AoYtTGNsHS72yu93w4o29OEsxxpPG+VyinMuroj90+QcE3+/BKVioE29C+iOb71cjOki3Nl3j0x42HCN6P/TYVaxfJ+LEfCWLVFNK1lFz3K09xVgUcBk0qbpt/dgN/7RqcZC+Gm5aQ8GJhiW1H4GtdWiXgL/Tn7nRcpBg86197BoVB+n3Rb9yOvuv6vmk4TQUY8wYxzhEMUbn36nmeg7vC4uDSIgO2Xxvi+UgicNwoU9T1VbeODfw+I1Kg/hkvN1l3B9HWsunFaZgvRH0nGqTO1g5NrTU47kWB8m3Z10IcJVs6UpvzUYKDRxb7fUIlLKuEGxe3MeuQQrR7y4U2npl0HnGsTRVqi80jgG0p3o3O12geqqEBrIt0XJTh8ZyjnIHyS8GSL52MsL4lRYJlPEWRlrHt2UdNZsQaoPAodK8oCwVefthyYry+UR/s+G5VZV5QLVhS3NY3yKZVbCn6Amnn0OqXncANs/0sGmY6tRyRFuvDOUgjjKMg3exJg3/ROuEnP4EGzFVmgDtKutvkRAggFY2swnRT7Mt8S/TF/q22EiB2DcmWhHRQfKq2YMTJvna+yKM/6Y4FpXUwZFxEJjdjLSO9/r2sivAVRyqzGpeuKEYc/qO7Pj07OMAalKAOzVWfloDwc/mB0bbynxKDw2cZO0n/yyJpR8Cmx92OpvrVoFZW4sKxRsP7PmkwSBlf5NinDJ71yzFOFrVsUwDGYZsZCeJ3uj85C/6gejPZIPbIbV9ncAesWtRFifbqi2v+kfNvGfZE5FseEGcl7GYaylO8C6i70Zcx28qTdLWVHk42GI49++czjmDuovF9UObCt3W14LMrDfIKvyvorcMdqGXnaa1S2zQCwwB45o53JvE0g/5U6f/fXtB9NkUxvYAcTTauLXrXR7YrWXC+Tf/fc44nzZoQ2Stqj9M6CNXeXYyKUHmGtjk7++zwb0l+p+yUVu8/uBsdJM4sfkPhV2xNnXEHx3qY4987WGiVyLa8oDYYulZNBSc7LTy+k3vRbL9eZG2zow2iyRU09Exp6+kCyFV2yfgco7h2RB6VsVIoYdzZD3Vwqbue02CtUEQd8wyAHg2Ws1o5zEofgo27xHP5C21kL6ntBe60+kqlmMeqDk07vJiqvOK/z3blQ+ut9Qrs14v3aEY4zvGMTq5STGeRsj4qzQ7mZREnJ9Ts+GnMWtFDdlQQ8Z7KO2c3lFsPT/77ZOuGPpHf5sacyPbAt0R2kkqrlSviWy3NoAXAdqaFyF0boDlQBzKncpxoXdcfgrgA478LUHQUMgsvbYtlnpHbTUUY33d5Y4nimkimN5Sm2YYi5xtHv0+yc8qbH7c5fFlMT6goDSC5eTO18FALB+C/DGP13s85+3iv2HtrHFkmrpEbVmvBzd4Ph+nTCcZx+jEUh3cRwzQHjVkI7tRsem9KJt1kiyKzDWuziKloXfKpzhkh00XVOAgQUGbVMrP8PLI9v5K1ub3lWYhWFhbU6VsPAachR8qx2zrJ6KdFGNp403agmN1sn2Kv8UXnC21vC1cKfrGd8DxfKZrHtggQtaAme1sjucTA57ZGXD7gcuvkULajGf9P4PNmuuZexXP/TvjPE43zMHiIO+leD6quv+BcT6d7KwYU6NzAthGqgIxLpkthgad6y9uusko1z9dNh4hYz1QkSOiqsosX7+0Iru2rDnWosxaitOyN0oIVGCrJUUdToA20LZMMCYCP9cox2sLn5zPVI5n6fPWFoLRcZphnS82JsQzZSVsgDQ9tE7r8wwE22ItdjfOpc24szUXhvqdxOw5wGY4d2Wz9mCzteo3WqoMKzuCn/N1yuf6xtF1c4VyHGts0ImKMULW5bpKMa6vou+XJCCykS3Iyp3KoOv7kpabPjNk1hviY+S5uL6K2Yi2W8jk8q6p87JbBBsfqdC+9npfjrpFmvVEtp04V2dmW1qYRLfxnpY+9ghoX7hemYYd4OWEjDNkX61VjtUtnKJqPw3vX3JMCO0MEKflu6HhGgRXYpY0/k4haFVboHBYjR8880aXO8a+cTX4ZI+TC0tdqbbWDBhvnsf3o+4V3hN7etoMELOlbcnRbfORnuNor72smVWaukSbi/lbuFAxxjLjGL3AeocM1i4bPE6qRjazmwNv3ijcuEA24/Gmm/L2lmUD/2hR1+hc0U1Z/DijXlqoXLuDRC8msLMtOI9nbHSTfV/U6OcmX3NhVqEjh5+jZh07wMajeeFgI/i5p7TZQoN0m3F+oMwm2S2cBuH6Z3GX4HSscPbTlW7hCkvbGV3beR22Yl0RG4WMv3kdgjOKgHL8foTYsMYH2KwJXMe6rChsnuiyGbFxiwqbLe1EfG3uxhp47/v8Njil0SY1WMtCaP5mQhbYhTP+kGLsYQoaJkEqQDa0xyNskjiRWpvl13AoFbBYdDEkjtPZ8s958s/ziv/vsizv/4VaQk+LXk/kbKzWptTL9xyXhW8xohVOvR4S/Uh0ZXuds7x4Ja7/VoveqdCeZT7Vx/tQ9pSjCmGzK5Omi2w236aWdRBicOB0aU+HLRlObSFdP+tQKOcWz/0b1//kDzZrkwQ61Wlzr8Boq24fYHMniIfTxB51rssxHs/vBH8DvoHTbVkLXD6pGOMs4xj9sDqcvTQR2DYSE2SFZXFrCY2KUJTxVP36NebXwPY6aVOJuk2WHmhV6yVnqwLczV+J3qvBfIYJNk45W9wTYuVCnWCF0v9yH3Ze72fz2hrY2SmUedhn4Ep/yJjRfvxea2taIVPMty5RW/spxwBwDH1bmeBEeZZhjEEcrxh/mOpUAZ0MA7V+arCpphZOu/4aae/a9ZPvu74G9tdJ2muYThADkXoz6id8wkbm1+El5tcJGsN+twbzGiScDpxT2GphvAZz6BTKOAxzNOpmM1ruHDLE5k5wCqQtlgmhnIG25tN3lGNsUD6/zWzFGDixDJltCCxXif1kcRBJKmRDO60Gm2pStfIrvkGfKnuyzk3g9C1Wc9dR1J0lrtaAtdJ0FcK1jPp3ZAhIgdf2nKtK2MzKOoPjNZhHW4gD8slsqpPNCEL3PTlqY0m7h25VjgO0ToO1avm5ijF+7PyKtmrRtlPppU0R7CIxyeI1KB0VPYTgcMvaFQHlT9dgDnXQPQFaoqA5b+pNqddLDS9o0++IBwhmt9TDiSUEHWNjDtGAFll262swJ03QLmx+oAY2I1jdkqruk4HXS9rq1pbr8CsN83FOFwMUqwjjGQob+umBSLaRWGRxutCPih7a6CZ3LrF2ZcsjbC1a03LTITbUMmnboYVA7PMCzMmXyUjz0Gi5CxNf1QlONDQNRkNqjXE+Bzl7bawQNpdxyC0OkiX+SFOXqC3r9bvGYbW2MRkGsrGfUtjRS3Vq7Ex8yPKsp9Qb7Mg5R6DlGtfWYB6ptaFs4coOtDVVQgtO0TVOVwgxJAguRaXtUAGhvkKGFOoQlbkeHcSYy09xtLV5rEJpATgKZU79di5srsq5w+/e+SVtBpbWH9raVkBTl6gta+an73ystZx8QSyYNekAjm+wGoGkIrI8HTz1Jlul3mu56f8eaO1W1GA+KdWUtfw3IdayACc2VToG7V5Uf+/i9QizgN5u2ORjZbkh86jp8rgcSzFPKwcUY8bIbMPVIAKNkR0YMgYFgcvI4otxVYjyCYhBQ9XrUL97CKjXnMRa6/JoU9+bxnE0LUZwVR06QLsbVKLXlpzACVjZdkgkBfLp/+gabLRV6Z+yLXWYpq1ZOf8MgpGzbft6Dc7RnKZr7BDi97AAn55xDH+9y697Qupml9fymXC5I4ZTohDdzGOBjflPRJeJ7nd53SRro1sIQddwIGZEf+nyT8Ox4qoGgTFx4jhf9H2XO6ivOP18kKm11uVF/HDSc6zTZ2H5gpO1AwubESe30uUbvuXn8GJhM34X8TuoDcL2ASc16K2GU4vu3xk4x+hV9pgr14QX2Viozo4ipU8VY3UK2WT4fbvb5VXfywT842TtvmKcX3SN80Tx39C2xqfKeAiQ9o/fA7xXcOK7sofQmBmOKgoPM3NtVCk2+ttF79Vg040pFFL8c9nUg3y6bLrJsQg2olBmswZrNUxrxLGu6mVEcqcCpy+Ip8FJ1wUur9yMTbaXM/gD99vO4LjLN81YDoSV7VzuoB7mcmcBmwk2npvc784JQcvtOcGJPs7lV3elrsmN4KoEDibqAGHzxmlKL5tRVgDO/kTxdYjbQXxTVTYjLvCoYlxcOZ7i8nVDI9eyPfDa4H26VzFWp3CSs4cLd5q3fTHOZ7rG2dPFuxr2AR+2d+uhXV3++01GHXEa9pJN73/XYOONpUnMMeSaZXHKI1wujsfJNVivQVofKCCbEEIIqT9FY1h0eN+aro3WZIrGsxqKtQpt75bg4MJJquNJ0vWZa9A5IoQQsu3RctOzsrwvWurNuIyeknnMtdY38iHLe5wFtbvppv7Z+RAn6agsbRPcTm0Qx4gl8gkhhJBm3gF+1Byl28UxOsXSMkSLjJUFtj3rMcY+opmE64k5Lgx9PUkIIYSMPOIoHSCb5OWi50W/qYET1K03REthZ1VrstFN7RNhHnf3G0/+26lZtadJaF58V5VrSgghhIwc69zEdq3cUfpL0Y2ip7J0sUpw0taJftRy0+fKP4+s4sSoE1mL8QjzumbwmNMHZfmJ3posnqMKJ2yxjHUqYtKqWk9CCCFkq0AcBGS9zZZ/oo8broBWZVviVKJs3K9neb+zO1pbahg1ThB9rmqnqBOx5ZII8/yqz9gy9/3la/8tHETRC1l+2mMd813RM6L/C2cTTpisa8qUWUIIIWTrIXONj2d5zNJxrbz5LQKY1xs3bfm+xg/lOZfK//5z0Rdbbmqfkl3igyI23RTaQZL5qiqtwkGU7/ksTrNEVynW+/Xi54P1ParppvaNtU6EEEII6UG+iTf2EQfnoGxLVlZPzZaN/gDRyGzUxYlZaAepdJ8eecaOorFe69x0jYMYbE0IIYSQKKDBbQTn6N7U8yKEEEIIMdNyjVmhHSTRRannRQghhBBiJssz50I6Rx+Ijk09L0IIIYQQE003tYs4M9cEdpBeRPZY6rkRQgghhJhoucaYODQrAjtIK0MEaBNCCCGEJEGcmS9l4QtkLkk9L0IIIYQQMy03fXb4AO3GFannRQghhBBiRhyaKyNksM1NPS9CCCGEEBMoeinOzP2BnaNNosNTz40QQgghxETTNT4tzszPAjtIz2SuMTIVxAkhhBBCfguc9BQnPiEdpHtabvojqedGCCGEEGJCHJnTI8QfXZt6XoQQQgghZsSZmQjtILVcY37qeRFCCCGEmBGHZmkEB+nE1PMihBBCCDHRdFO7i0PzWGAH6cWMLUYIIYQQMqqII/N50UuBHaRHXnaLdk09N0IIIYQQE+LMnBghQPtHqedFCCGEEGKm5abPj+AgXZJ6XoQQQgghZsSZuSFCgPZpqedFCCGEEGKi6ab2Eofm4cAO0pqMLUYIIYQQMqq0XGOWODPPBnaQlslz90s9N0IIIYQQE+LMLBC9HdhBmkTz29RzI4QQQggxESP+SDQ39bwIIYQQQsyIM7MqtIPUdFP7p54XIYQQQogZcWg2BXaQMl6vEUIIIWSkEYfmFtF7oZyjlptmej8hhBBCRhtxaJDm/xXRnaLnlCdKr2V5Sv8/ii4VHZp6PoQQQgghwdjoJndoucYh4jCdIo7O1zwlX9s4DN+b2n5CCCGEEEIIIYQQQgghhBBCCCGEEFI7/j/SXNO5jJTNlAAAAABJRU5ErkJggg==" alt="logo of spboss.in" height="73" width="292">
</a></div>
<div class="ftr-sm" style="font-size: 12px;text-align: left;font-size: 12px;
text-align: left;
font-style: normal;
font-weight: lighter;
padding: 5px 25px;">
<div data-custom-class="body" style="text-align: left">
<h1>Terms Of Service- spboss.in</h1>
<div align="center" style="text-align: left; line-height: 1;">
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div align="center" class="MsoNormal" style="text-align:center;line-height:150%;">
<a name="_2cipo4yr3w5d"></a>
<div align="center" class="MsoNormal" style="line-height: 22.5px;">
<div align="center" class="MsoNormal" style="line-height: 150%;">
<a name="_gm5sejt4p02f"></a>
<div align="center" class="MsoNormal" data-custom-class="title" style="text-align: left; line-height: 1.5;"><strong><span style="line-height: 22.5px; font-size: 26px;">TERMS OF USE</span></strong></div>
<div align="center" class="MsoNormal" style="line-height: 22.5px; text-align: left;"><a name="_7m5b3xg56u7y"></a></div>
<div align="center" class="MsoNormal" data-custom-class="subtitle" style="text-align: left; line-height: 22.5px;"><br></div>
<div align="center" class="MsoNormal" data-custom-class="subtitle" style="text-align: left; line-height: 1.5;">
<span style="color: rgb(89, 89, 89); font-size: 14.6667px; text-align: justify;">
<strong>
Last updated
<bdt class="block-container question question-in-editor" data-id="e2088df5-25ea-aec9-83d4-6284f5a7e043" data-type="question">Aug 01, 2022</bdt>
</strong>
</span>
</div>
</div>
</div>
<div align="center" class="MsoNormal" style="line-height: 17.25px; text-align: left;"><br></div>
<div align="center" class="MsoNormal" style="line-height: 17.25px; text-align: left;"><br></div>
<div align="center" class="MsoNormal" style="line-height: 17.25px; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px;"><br></span></div>
</div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><a name="_a7mwfgcrtsqn"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">AGREEMENT TO TERMS</span></strong></div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;
               Arial;mso-fareast-font-family:Calibri;mso-themecolor:text1;
               mso-themetint:166;">
These Terms of Use constitute a legally binding agreement made between you, whether personally or on behalf of an entity (you) and
<bdt class="block-container question question-in-editor" data-id="4ab94aa9-19d1-61e0-711e-42c7d186232b" data-type="question">Satta Matka</bdt>
<bdt class="block-component"></bdt>
("
<bdt class="block-component"></bdt>
<strong>Company</strong>
<bdt class="statement-end-if-in-editor"></bdt>
", <strong>we</strong>, <strong>us</strong>”, or <strong>our</strong>), concerning your access to and use of the
<bdt class="block-container question question-in-editor" data-id="92c3b320-1d8b-c74c-db68-d12810736807" data-type="question"><a href="https://spboss.in" target="_blank" data-custom-class="link">https://spboss.in</a></bdt>
website as well as any other media form, media channel, mobile website or mobile application related, linked, or otherwise connected thereto (collectively, the Site”). You agree that by accessing the Site, you have read, understood, and agreed to be bound by all of these Terms of Use. IF YOU DO NOT AGREE WITH ALL OF THESE TERMS OF USE, THEN YOU ARE EXPRESSLY PROHIBITED FROM USING THE SITE AND YOU MUST DISCONTINUE USE IMMEDIATELY.
</span>
</div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;
            Arial;mso-fareast-font-family:Calibri;mso-themecolor:text1;
            mso-themetint:166;">Supplemental terms and conditions or documents that may be posted on the Site from time to time are hereby expressly incorporated herein by reference. We reserve the right, in our sole discretion, to make changes or modifications to these Terms of Use at any time and for any reason. We will alert you about any changes by updating the Last updated date of these Terms of Use, and you waive any right to receive specific notice of each such change. It is your responsibility to periodically review these Terms of Use to stay informed of updates. You will be subject to, and will be deemed to have been made aware of and to have accepted, the changes in any revised Terms of Use by your continued use of the Site after the date such revised Terms of Use are posted.</span></div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;
            Arial;mso-fareast-font-family:Calibri;mso-themecolor:text1;
            mso-themetint:166;">The information provided on the Site is not intended for distribution to or use by any person or entity in any jurisdiction or country where such distribution or use would be contrary to law or regulation or which would subject us to any registration requirement within such jurisdiction or country. Accordingly, those persons who choose to access the Site from other locations do so on their own initiative and are solely responsible for compliance with local laws, if and to the extent local laws are applicable.</span></div>
<div class="MsoNormal" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;
               Arial;mso-fareast-font-family:Calibri;mso-themecolor:text1;
               mso-themetint:166;">
<span style="font-size:11.0pt;line-height:115%;
                  Arial;mso-fareast-font-family:Calibri;mso-themecolor:text1;
                  mso-themetint:166;">
<bdt class="block-component"></bdt>
</span>
</span>
</div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_o18_option" data-type="statement"><span style="font-size: 15px;"></span></bdt>
<span style="font-size: 15px;">
<bdt data-type="body"><span style="line-height: 16.8667px; ">The Site is intended for users who are at least 18 years old. Persons under the age of 18 are not permitted to use or register for the Site.</span></bdt>
</span>
&nbsp;
</bdt>
<span style="font-size: 15px;">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_o18_option" data-type="statement"></bdt>
</bdt>
</span>
</div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_4rd71iod99ud"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">INTELLECTUAL PROPERTY RIGHTS</span></strong></div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;
            Arial;mso-fareast-font-family:Calibri;mso-themecolor:text1;
            mso-themetint:166;">Unless otherwise indicated, the Site is our proprietary
property and all source code, databases, functionality, software, website
designs, audio, video, text, photographs, and graphics on the Site
(collectively, the “Content) and the trademarks, service marks, and logos
contained therein (the Marks”) are owned or controlled by us or licensed to
us, and are protected by copyright and trademark laws and various other
intellectual property rights and unfair competition laws of the United States, international copyright laws, and international conventions. The Content and the Marks are provided on the
Site “AS IS” for your information and personal use only. Except as expressly provided in these Terms
of Use, no part of the Site and no Content or Marks may be copied, reproduced,
aggregated, republished, uploaded, posted, publicly displayed, encoded,
translated, transmitted, distributed, sold, licensed, or otherwise exploited
for any commercial purpose whatsoever, without our express prior written
permission.</span>
</div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;
            Arial;mso-fareast-font-family:Calibri;mso-themecolor:text1;
            mso-themetint:166;">Provided that you are eligible to use the Site, you are
granted a limited license to access and use the Site and to download or print a
copy of any portion of the Content to which you have properly gained access
solely for your personal, non-commercial use. We reserve all rights not
expressly granted to you in and to the Site, the Content and the Marks.</span>
</div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_vhkegautf00d"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">USER REPRESENTATIONS</span></strong></div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" style="text-align:justify;text-justify:inter-ideograph;
            line-height:115%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;">
<span style="font-size: 11pt; line-height: 16.8667px; ">By using the Site, you represent and warrant that: </span>
<bdt class="block-container if" data-type="if" id="d2d82ca8-275f-3f86-8149-8a5ef8054af6">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_account_option" data-type="statement"></bdt>
<bdt data-type="body">
<span style=" font-size: 11pt;">(</span><span style=" font-size: 14.6667px;">1</span><span style=" font-size: 11pt;">) all registration information you submit will be true, accurate, current, and complete; (</span><span style=" font-size: 14.6667px;">2</span>
<span style=" font-size: 11pt;">
) you will maintain the accuracy of such information and promptly update such registration information as necessary
<bdt class="block-container if" data-type="if" id="d2d82ca8-275f-3f86-8149-8a5ef8054af6">
<bdt data-type="conditional-block">
<bdt data-type="body"><span style=" font-size: 11pt;">;</span></bdt>
</bdt>
<bdt class="statement-end-if-in-editor" data-type="close"></bdt>
</bdt>
<span style=" font-size: 11pt;">(</span><span style=" font-size: 14.6667px;">3</span><span style=" font-size: 11pt;">) you have the legal capacity and you agree to comply with these Terms of Use;</span>
<bdt class="block-container if" data-type="if" id="8d4c883b-bc2c-f0b4-da3e-6d0ee51aca13">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_u13_option" data-type="statement"></bdt>
</bdt>
</bdt>
</span>
</bdt>
</bdt>
</bdt>
<span style=" font-size: 11pt;">(</span><span style=" font-size: 14.6667px;">4</span>
<span style=" font-size: 11pt;">
) you are not a minor in the jurisdiction in which you reside
<bdt class="block-container if" data-type="if" id="76948fab-ec9e-266a-bb91-948929c050c9">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_o18_option" data-type="statement"></bdt>
</bdt>
; (
</bdt>
</span>
<span style=" font-size: 14.6667px;">5</span><span style=" font-size: 11pt;">) you will not access the Site through automated or non-human means, whether through a bot, script, or otherwise; (</span><span style=" font-size: 14.6667px;">6</span><span style=" font-size: 11pt;">) you will not use the Site for any illegal or unauthorized purpose; and (</span><span style=" font-size: 14.6667px;">7</span><span style=" font-size: 11pt;">) your use of the Site will not violate any applicable law or regulation.</span><span style=" font-size: 14.6667px;"></span>
</div>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align:justify;text-justify:inter-ideograph;
            line-height:115%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px; ">If you provide any information that is untrue, inaccurate, not current, or incomplete, we have the right to suspend or terminate your account and refuse any and all current or future use of the Site (or any portion thereof).</span></div>
</div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1;">
<a name="_esuoutkhaf53"></a>
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_account_option" data-type="statement"><span style="font-size: 15px;"></span></bdt>
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 17.25px;"><strong><span style="line-height: 24.5333px; font-size: 19px;">USER REGISTRATION</span></strong></div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
<div class="MsoNormal" style="line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size: 11pt; line-height: 16.8667px; ">You may be required to register with the Site. You agree to keep your password confidential and will be responsible for all use of your account and password. We reserve the right to remove, reclaim, or change a username you select if we determine, in our sole discretion, that such username is inappropriate, obscene, or otherwise objectionable.</span></div>
</bdt>
</bdt>
</div>
</div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" class="MsoNormal" style="text-align: left; line-height: 150%;">
<div class="MsoNormal" style="line-height: 1.5;">
<bdt class="statement-end-if-in-editor" data-type="close"><span style="font-size: 15px;"></span></bdt>
</div>
<div class="MsoNormal" style="line-height:115%;">
<a name="_1voziltdxegg"></a>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 17.25px;"><strong><span style="line-height: 24.5333px; font-size: 19px;">PROHIBITED ACTIVITIES</span></strong></div>
</div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
<div class="MsoNormal" style="line-height:115%;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size: 11pt; line-height: 16.8667px; ">You may not access or use the Site for any purpose other than that for which we make the Site available. The Site may not be used in connection with any commercial endeavors except those that are specifically endorsed or approved by us.</span></div>
</div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
<div class="MsoNormal" style="line-height:115%;">
<div class="MsoNormal" style="text-align: justify; line-height: 17.25px;">
<div class="MsoNormal" style="line-height: 17.25px;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px; ">As a user of the Site, you agree not to:</span></div>
<div class="MsoNormal" style="line-height: 17.25px;">
<span style="font-size: 15px; line-height: 16.8667px; ">
<div class="MsoNormal" style="color: rgb(10, 54, 90); font-size: 15px; line-height: 1; text-align: left;"><br></div>
</span>
</div>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-size: 15px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">1</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">.&nbsp;</span>
</span>
Systematically retrieve data or other content from the Site to create or compile, directly or indirectly, a collection, compilation, database, or directory without written permission from us.
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">2</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Trick, defraud, or mislead us and other users, especially in any attempt to learn sensitive account information such as user passwords.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">3</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Circumvent, disable, or otherwise interfere with security-related features of the Site, including features that prevent or restrict the use or copying of any Content or enforce limitations on the use of the Site and/or the Content contained therein.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">4</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Disparage, tarnish, or otherwise harm, in our opinion, us and/or the Site.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">5</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Use any information obtained from the Site in order to harass, abuse, or harm another person.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">6</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Make improper use of our support services or submit false reports of abuse or misconduct.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">7</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Use the Site in a manner inconsistent with any applicable laws or regulations.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">8</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Use the Site to advertise or offer to sell goods and services.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">9</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Engage in unauthorized framing of or linking to the Site.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">10</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Attempt to impersonate another user or person or use the username of another user.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">11</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Sell or otherwise transfer your profile.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">12</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Harass, annoy, intimidate, or threaten any of our employees or agents engaged in providing any portion of the Site to you.</span>
</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"><span style="font-size: 15px;"></span></bdt>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">13</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Attempt to bypass any measures of the Site designed to prevent or restrict access to the Site, or any portion of the Site.</span>
</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"><span style="font-size: 15px;"></span></bdt>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">14</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Copy or adapt the Site’s software, including but not limited to Flash, PHP, HTML, JavaScript, or other code.</span>
</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"><span style="font-size: 15px;"></span></bdt>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">15</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Use a buying agent or purchasing agent to make purchases on the Site.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">16</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Make any unauthorized use of the Site, including collecting usernames and/or email addresses of users by electronic or other means for the purpose of sending unsolicited email, or creating user accounts by automated means or under false pretenses.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<span style="line-height: 16.8667px; ">
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -22.05pt; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">
<bdt class="block-container forloop" data-type="forloop" id="19beb913-5a5e-2b51-51f9-8600a8eb26c3" style="display: inline;">
<bdt data-type="conditional-block" style="display: inline;">
<bdt data-type="body" style="display: inline;">17</bdt>
</bdt>
</bdt>
</span>
<span style="font-family: sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: -29.4px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px;  text-decoration-style: initial; text-decoration-color: initial; ">. Use the Site as part of any effort to compete with us or otherwise use the Site and/or the Content for any revenue-generating endeavor or commercial enterprise.</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;">
<span style="font-size: 15px;">
<bdt class="forloop-component"></bdt>
</span>
</div>
<div class="MsoNormal" style="text-align: left; line-height: 1.5;"><a name="_zbbv9tgty199"></a></div>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1.5;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1.5;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 17.25px; text-align: left;"><strong><span style="line-height: 24.5333px; font-size: 19px;">USER GENERATED CONTRIBUTIONS</span></strong></div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
The Site may invite you to chat, contribute to, or participate in blogs, message boards, online forums, and other functionality, and may provide you with the opportunity to create, submit, post, display, transmit, perform, publish, distribute, or broadcast content and materials to us or on the Site, including but not limited to text, writings, video, audio, photographs, graphics, comments, suggestions, or personal information or other material (collectively, "Contributions"). Contributions may be viewable by other users of the Site and through third-party websites. As such, any Contributions you transmit may be treated as non-confidential and non-proprietary. When you create or make available any Contributions, you thereby represent and warrant that:
<bdt class="else-block"></bdt>
</span>
</div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" style="line-height: 1; text-align: left;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 17.25px;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; margin-left: 20px; text-align: left;"><span style="font-size: 14px; "><span data-custom-class="body_text">1. &nbsp;The creation, distribution, transmission, public display, or performance, and the accessing, downloading, or copying of your Contributions do not and will not infringe the proprietary rights, including but not limited to the copyright, patent, trademark, trade secret, or moral rights of any third party.<br>2. You are the creator and owner of or have the necessary licenses, rights, consents, releases, and permissions to use and to authorize us, the Site, and other users of the Site to use your Contributions in any manner contemplated by the Site and these Terms of Use.<br>3. You have the written consent, release, and/or permission of each and every identifiable individual person in your Contributions to use the name or likeness of each and every such identifiable individual person to enable inclusion and use of your Contributions in any manner contemplated by the Site and these Terms of Use.<br>4. Your Contributions are not false, inaccurate, or misleading.<br>5. &nbsp;Your Contributions are not unsolicited or unauthorized advertising, promotional materials, pyramid schemes, chain letters, spam, mass mailings, or other forms of solicitation.<br>6. &nbsp;Your Contributions are not obscene, lewd, lascivious, filthy, violent, harassing, libelous, slanderous, or otherwise objectionable (as determined by us).<br>7. &nbsp;Your Contributions do not ridicule, mock, disparage, intimidate, or abuse anyone.<br>8. &nbsp;Your Contributions are not used to harass or threaten (in the legal sense of those terms) tos any other person and to promote violence against a specific person or class of people.<br>9. &nbsp;Your Contributions do not violate any applicable law, regulation, or rule.<br>10. &nbsp;Your Contributions do not violate the privacy or publicity rights of any third party.<br>11. Your Contributions do not contain any material that solicits personal information from anyone under the age of 18 or exploits people under the age of 18 in a sexual or violent manner.<br>12. &nbsp;Your Contributions do not violate any applicable law concerning child pornography, or otherwise intended to protect the health or well-being of minors.<br>13. &nbsp;Your Contributions do not include any offensive comments that are connected to race, national origin, gender, sexual preference, or physical handicap.<br>14. &nbsp;Your Contributions do not otherwise violate, or link to material that violates, any provision of these Terms of Use, or any applicable law or regulation.</span></span></div>
<div class="MsoNormal" style="line-height: 1; margin-left: 20px; text-align: left;"><br></div>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px; ">Any use of the Site in violation of the foregoing violates these Terms tos of Use and may result in, among other things, termination or suspension of your rights to use the Site.</span></div>
</bdt>
</bdt>
</div>
</div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height:115%;">
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5; text-align: left;"><strong><span style="line-height: 24.5333px; font-size: 19px;">CONTRIBUTION LICENSE</span></strong></div>
</bdt>
</bdt>
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" style="line-height: 17.25px; text-align: left;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
</span>
</div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
By posting your Contributions to any part of the Site
<bdt class="block-container if" data-type="if" id="19652acc-9a2a-5ffe-6189-9474402fa6cc">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="socialnetwork_link_option" data-type="statement"></bdt>
</bdt>
, you automatically grant, and you represent and warrant that you have the right to grant, to us an unrestricted, unlimited, irrevocable, perpetual, non-exclusive, transferable, royalty-free, fully-paid, worldwide right, and license to host, use, copy, reproduce, disclose, sell, resell, publish, broadcast, retitle, archive, store, cache, publicly perform, publicly display, reformat, translate, transmit, excerpt (in whole or in part), and distribute such Contributions (including, without limitation, your image and voice) for any purpose, commercial, advertising, or otherwise, and to prepare derivative works of, or incorporate into other works, such Contributions, and grant and authorize sublicenses of the foregoing. The use and distribution may occur in any media formats and through any media channels.
</bdt>
</span>
</div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px; ">This license will apply to any form, media, or technology now known or hereafter developed, and includes our use of your name, company name, and franchise name, as applicable, and any of the trademarks, service marks, trade names, logos, and personal and commercial images you provide. You waive all moral rights in your Contributions, and you warrant that moral rights have not otherwise been asserted in your Contributions.</span></div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px; ">We do not assert any ownership over your Contributions. You retain full ownership of all of your Contributions and any intellectual property rights or other proprietary rights associated with your Contributions. We are not liable for any statements or representations in your Contributions provided by you in any area on the Site. You are solely responsible for your Contributions to the Site and you expressly agree to exonerate us from any and all responsibility and to refrain from any legal action against us regarding your Contributions. </span></div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
We have the right, in our sole and absolute discretion, (1) to edit, redact, or otherwise change any Contributions; (2) to re-categorize any Contributions to place them in more appropriate locations on the Site; and (3) to pre-screen or delete any Contributions at any time and for any reason, without notice. We have no obligation to monitor your Contributions.
<bdt class="else-block"></bdt>
</span>
</div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1;">
<bdt class="block-container if" data-type="if" id="a378120a-96b1-6fa3-279f-63d5b96341d3">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="review_option" data-type="statement"><span style="font-size: 15px;"></span></bdt>
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">GUIDELINES FOR REVIEWS</span></strong></div>
</bdt>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px; ">We may provide you areas on the Site to leave reviews or ratings. When posting a review, you must comply with the following criteria: (1) you should have firsthand experience with the person/entity being reviewed; (2) your reviews should not contain offensive profanity, or abusive, racist, offensive, or hate language; (3) your reviews should not contain discriminatory references based on religion, race, gender, national origin, age, marital status, sexual orientation, or disability; (4) your reviews should not contain references to illegal activity; (5) you should not be affiliated with competitors if posting negative reviews; (6) you should not make any conclusions as to the legality of conduct; (7) you may not post any false or misleading statements; and (8) you may not organize a campaign encouraging others to post reviews, whether positive or negative.</span></div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5; text-align: left;"><span style="font-size: 11pt; line-height: 16.8667px; ">We may accept, reject, or remove reviews in our sole discretion. We have absolutely no obligation to screen reviews or to delete reviews, even if anyone considers reviews objectionable or inaccurate. Reviews are not endorsed by us, and do not necessarily represent our opinions or the views of any of our affiliates or partners. We do not assume liability for any review or for any claims, liabilities, or losses resulting from any review. By posting a review, you hereby grant to us a perpetual, non-exclusive, worldwide, royalty-free, fully-paid, assignable, and sublicensable right and license to reproduce, modify, translate, transmit by any means, display, perform, and/or distribute all content relating to reviews.</span></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;">
<bdt class="block-container if" data-type="if">
<bdt class="statement-end-if-in-editor" data-type="close"><span style="font-size: 15px;"></span></bdt>
</bdt>
</div>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="line-height: 115%;"><span style="font-size: 15px;"><a name="_6nl7u6ag6use"></a></span></div>
<bdt class="block-container if" data-type="if" id="c954892f-02b9-c743-d1e8-faf0d59a4b70">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="mobile_app_option" data-type="statement"><span style="font-size: 15px;"></span></bdt>
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">MOBILE APPLICATION LICENSE</span></strong></div>
</bdt>
</bdt>
</bdt>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" style="line-height: 115%;"><a name="_4p0l96wt8fhj"></a></div>
<div class="MsoNormal" data-custom-class="heading_2" style="line-height: 115%;"><strong><span style="line-height: 115%; font-family: Arial;">Use
License</span></strong>
</div>
</bdt>
</bdt>
</bdt>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                        Calibri;mso-themecolor:text1;mso-themetint:166;">If you access the
Site via a mobile application, then we grant you a revocable, non-exclusive,
non-transferable, limited right to install and use the mobile application on
wireless electronic devices owned or controlled by you, and to access and use
the mobile application on such devices strictly in accordance with the terms tos
and conditions of this mobile application license contained in these Terms of Use.
You shall not: (1) decompile, reverse engineer, disassemble, attempt to derive
the source code of, or decrypt the application; (2) make any modification,
adaptation, improvement, enhancement, translation, or derivative work from the
application; (3) violate any applicable laws, rules, or regulations in
connection with your access or use of the application; (4) remove, alter, or
obscure any proprietary notice (including any notice of copyright or trademark)
posted by us or the licensors of the application; (5) use the application for
any revenue generating endeavor, commercial enterprise, or other purpose for
which it is not designed or intended; (6) make the application available over a
network or other environment permitting access or use by multiple devices or
users at the same time; (7) use the application for creating a product,
service, or software that is, directly or indirectly, competitive with or in
any way a substitute for the application; (8) use the application to send
automated queries to any website or to send any unsolicited commercial e-mail;
or (9) use any proprietary information or any of our interfaces or our other
intellectual property in the design, development, manufacture, licensing, or
distribution of any applications, accessories, or devices for use with the
application.</span>
</div>
</bdt>
</bdt>
</bdt>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_2" style="line-height: 115%;"><a name="_vzf0b5xscg"></a><strong><span style="line-height: 115%; font-family: Arial;">Apple and Android Devices</span></strong></div>
</bdt>
</bdt>
</bdt>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                        Calibri;mso-themecolor:text1;mso-themetint:166;">The following terms apply when you use a mobile application obtained from either the Apple Store or Google Play (each an App Distributor) to access the Site: (1) the license granted to you for our mobile application is limited to a non-transferable license to use the application on a device that utilizes the Apple iOS or Android operating systems, as applicable, and in accordance with the usage rules set forth in the applicable App Distributors terms of service; (2) we are responsible for providing any maintenance and support services with respect to the mobile application as specified in the terms and conditions of this mobile application license contained in these Terms of Use or as otherwise required under applicable law, and you acknowledge that each App Distributor has no obligation whatsoever to furnish any maintenance and support services with respect to the mobile application; (3) in the event of any failure of the mobile application to conform to any applicable warranty, you may notify the applicable App Distributor, and the App Distributor, in accordance with its terms and policies, may refund the purchase price, if any, paid for the mobile application, and to the maximum extent permitted by applicable law, the App Distributor will have no other warranty obligation whatsoever with respect to the mobile application; (4) you represent and warrant that (i) you are not located in a country that is subject to a U.S. government embargo, or that has been designated by the U.S. government as a terrorist supporting country and (ii) you are not listed on any U.S. government list of prohibited or restricted parties; (5) you must comply with applicable third-party terms of agreement when using the mobile application, e.g., if you have a VoIP application, then you must not be in violation of their wireless data service agreement when using the mobile application; and (6) you acknowledge and agree that the App Distributors are third-party beneficiaries of the terms and conditions in this mobile application license contained in these Terms of Use, and that each App Distributor will have the right (and will be deemed to have accepted the right) to enforce the terms and conditions in this mobile application license contained in these Terms of Use against you as a third-party beneficiary thereof.</span></div>
</bdt>
</bdt>
</bdt>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center">
<bdt class="block-container if" data-type="if">
<bdt class="statement-end-if-in-editor" data-type="close"><span style="font-size: 15px;"></span></bdt>
</bdt>
</div>
<div align="center">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">SUBMISSIONS</span></strong></div>
<div style="line-height: 1;"><br></div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
            Calibri;mso-themecolor:text1;mso-themetint:166;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
            Calibri;mso-themecolor:text1;mso-themetint:166;">You acknowledge and agree that any questions, comments, suggestions, ideas, feedback, or other information regarding the Site ("Submissions") provided by you to us are non-confidential and shall become our sole property. We shall own exclusive rights, including all intellectual property rights, and shall be entitled to the unrestricted use and dissemination of these Submissions for any lawful purpose, commercial or otherwise, without acknowledgment or compensation to you. You hereby waive all moral rights to any such Submissions, and you hereby warrant that any such Submissions are original with you or that you have the right to submit such Submissions. You agree there shall be no recourse against us for any alleged or actual infringement or misappropriation of any proprietary right in your Submissions.</span></span></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><br></div>
<div align="center">
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</div>
<div align="center" style="text-align: left; line-height: 1;">
<div class="MsoNormal" style="line-height: 115%;"><span style="font-size: 15px;"><a name="_29ce8o9pbtmi"></a></span></div>
<bdt class="block-container if" data-type="if" id="14038561-dad7-be9d-370f-f8aa487b2570">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="advertiser_option" data-type="statement"><span style="font-size: 15px;"></span></bdt>
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">ADVERTISERS</span></strong></div>
</bdt>
</bdt>
</bdt>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                           Calibri;mso-themecolor:text1;mso-themetint:166;">
We allow advertisers to display their advertisements and other information in certain areas of the Site, such as sidebar advertisements or banner advertisements. If you are an advertiser, you shall take full responsibility for any advertisements you place on the Site and any services provided on the Site or products sold through those advertisements. Further, as an advertiser, you warrant and represent that you possess all rights and authority to place advertisements on the Site, including, but not limited to, intellectual property rights, publicity rights, and contractual rights.
<bdt class="block-component"></bdt>
We simply provide the space to place such advertisements, and we have no other relationship with advertisers.
</span>
</div>
</bdt>
</bdt>
</bdt>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><br></div>
<div align="center" style="text-align: left; line-height: 1.5;">
<bdt class="block-container if" data-type="if">
<bdt class="statement-end-if-in-editor" data-type="close"><span style="font-size: 15px;"></span></bdt>
</bdt>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><a name="_wj13r09u8u3u"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">SITE MANAGEMENT</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left; line-height: 1.5;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
               Calibri;mso-themecolor:text1;mso-themetint:166;">We reserve the
right, but not the obligation, to: (1) monitor the Site for violations of
these Terms of Use; (2) take appropriate legal action against anyone who, in
our sole discretion, violates the law or these Terms of Use, including without
limitation, reporting such user to law enforcement authorities; (3) in our sole
discretion and without limitation, refuse, restrict access to, limit the
availability of, or disable (to the extent technologically feasible) any of
your Contributions or any portion thereof; (4) in our sole discretion and
without limitation, notice, or liability, to remove from the Site or otherwise
disable all files and content that are excessive in size or are in any way
burdensome to our systems; and (5) otherwise manage the Site in a manner
designed to protect our rights and property and to facilitate the proper
functioning of the Site.</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left; line-height: 1.5;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;"><a name="_jugvcvcw0oj9"></a></div>
<bdt class="block-container if" data-type="if" id="bdd90fa9-e664-7d0b-c352-2b8e77dd3bb4">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="privacy_policy_option" data-type="statement"><span style="font-size: 15px;"></span></bdt>
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">PRIVACY POLICY</span></strong></div>
<div class="MsoNormal" style="line-height: 1;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                        Calibri;mso-themecolor:text1;mso-themetint:166;"><br></span></div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                           Calibri;mso-themecolor:text1;mso-themetint:166;">We care about data privacy and security.</span><span style=" font-size: 14.6667px;">Please review our Privacy Policy:</span>
<b style=" font-size: 14.6667px;">
<bdt class="block-container question question-in-editor" data-id="d10c7fd7-0685-12ac-c717-cbc45ff916d1" data-type="question"><a href="https://spboss.in/privacy.php" target="_blank" data-custom-class="link">https://spboss.in/privacy.php</a></bdt>
</b>
<span style=" font-size: 14.6667px;">.&nbsp;</span>
<span style=" font-size: 11pt;">
By using the Site, you agree to be bound by our Privacy Policy, which is incorporated into these Terms of Use. Please be advised the Site is hosted in
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<bdt class="question">Canada</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
. If you access the Site from any other region of the world with laws or other requirements governing personal data collection, use, or disclosure that differ from applicable laws in
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<bdt class="question">Canada</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
, then through your continued use of the Site, you are transferring your data to
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<bdt class="question">Canada</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
, and you agree to have your data transferred to and processed in
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<bdt class="question">Canada</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
.
<bdt class="block-component"></bdt>
</span>
</div>
</bdt>
</bdt>
</bdt>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left; line-height: 1.5;"><span style="font-size: 15px;"><br></span></div>
<div align="center" style="text-align: left; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt class="statement-end-if-in-editor" data-type="close"><span style="font-size: 15px;"></span></bdt>
</bdt>
<div style="text-align: justify; line-height: 1.5;">
<bdt class="block-container if" data-type="if" id="87a7471d-cf82-1032-fdf8-601d37d7b017">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="privacy_policy_followup" data-type="statement" style="font-size: 14.6667px;"><span style="font-size: 15px;"></span></bdt>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="line-height: 115%;"><span style="font-size: 15px;"><a name="_n081pott8yce"></a></span></div>
<bdt class="block-component">
<bdt class="block-component"></bdt>
</bdt>
<div class="MsoNormal" style="line-height: 1;">
<span style="font-size: 15px;"><a name="_sg28ikxq3swh"></a></span>
<bdt class="block-component">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
</bdt>
</div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">COPYRIGHT INFRINGEMENTS</span></strong></div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" data-custom-class="body_text" style="text-align: left; line-height: 1.5;"><span style="font-size: 15px;">We respect the intellectual property rights of others. If you believe that any material available on or through the Site infringes upon any copyright you own or control, please immediately notify us using the contact information provided below (a “Notification). A copy of your Notification will be sent to the person who posted or stored the material addressed in the Notification. Please be advised that pursuant to applicable law you may be held liable for damages if you make material misrepresentations in a Notification. Thus, if you are not sure that material located on or linked to by the Site infringes your copyright, you should consider first contacting an attorney.</span></div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left; line-height: 1.5;">
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><a name="_k3mndam4w6w1"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">TERM AND
TERMINATION</span></strong>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size: 15px; line-height: 115%; font-family: Arial; ">
These Terms of Use shall remain in full force and effect while you use the Site. WITHOUT LIMITING ANY OTHER PROVISION OF THESE TERMS OF USE, WE RESERVE THE RIGHT TO, IN OUR SOLE DISCRETION AND WITHOUT NOTICE OR LIABILITY, DENY ACCESS TO AND USE OF THE SITE (INCLUDING BLOCKING CERTAIN IP ADDRESSES), TO ANY PERSON FOR ANY REASON OR FOR NO REASON, INCLUDING WITHOUT LIMITATION FOR BREACH OF ANY REPRESENTATION, WARRANTY, OR COVENANT CONTAINED IN THESE TERMS OF USE OR OF ANY APPLICABLE LAW OR REGULATION. WE MAY TERMINATE YOUR USE OR PARTICIPATION IN THE SITE OR DELETE
<bdt class="block-container if" data-type="if" id="a6e121c2-36b4-5066-bf9f-a0a33512e768">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_account_option" data-type="statement"></bdt>
<bdt data-type="body">YOUR ACCOUNT AND&nbsp;</bdt>
</bdt>
<bdt class="statement-end-if-in-editor" data-type="close"></bdt>
</bdt>
ANY CONTENT OR INFORMATION THAT YOU POSTED AT ANY TIME,
WITHOUT WARNING, IN OUR SOLE DISCRETION.
</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                  Calibri;mso-themecolor:text1;mso-themetint:166;">If we terminate
or suspend your account for any reason, you are prohibited from registering and
creating a new account under your name, a fake or borrowed name, or the name of
any third party, even if you may be acting on behalf of the third party. In
addition to terminating or suspending your account, we reserve the right to
take appropriate legal action, including without limitation pursuing civil,
criminal, and injunctive redress.</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_e2dep1hfgltt"></a><strong><span style="line-height: 115%; font-family: Arial;"><span style="font-size: 19px;">MODIFICATIONS AND INTERRUPTIONS</span></span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                  Calibri;mso-themecolor:text1;mso-themetint:166;">We reserve the right to change, modify, or remove the contents of the Site at any time or for any reason at our sole discretion without notice. However, we have no obligation to update any information on our Site. We also reserve the right to modify or discontinue all or part of the Site without notice at any time. We will not be liable to you or any third party for any modification, price change, suspension, or discontinuance of the Site. &nbsp;</span></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                  Calibri;mso-themecolor:text1;mso-themetint:166;">We cannot guarantee
the Site will be available at all times. We may experience hardware, software,
or other problems or need to perform maintenance related to the Site, resulting
in interruptions, delays, or errors. We
reserve the right to change, revise, update, suspend, discontinue, or otherwise
modify the Site at any time or for any reason without notice to you. You agree that we have no liability
whatsoever for any loss, damage, or inconvenience caused by your inability to
access or use the Site during any downtime or discontinuance of the Site. Nothing in these Terms of Use will be
construed to obligate us to maintain and support the Site or to supply any
corrections, updates, or releases in connection therewith.</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_p6vbf8atcwhs"></a><strong><span style="line-height: 115%; font-family: Arial;"><span style="font-size: 19px;">GOVERNING LAW</span></span></strong></div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
<div class="MsoNormal" style="line-height: 115%;">
<bdt class="block-component"><span style="font-size: 15px;"></span></bdt>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
These Terms shall be governed by and defined following the laws of
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="question">India</bdt>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
.
<bdt class="question">Satta Matka</bdt>
and yourself irrevocably consent that the courts of
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="question">India</bdt>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
&nbsp;
</span>
shall have exclusive jurisdiction to resolve any dispute which may arise in connection with these terms.
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_v5i5tjw62cyw"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">DISPUTE RESOLUTION</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 115%;">
<bdt class="block-container if" data-type="if" id="4de367b8-a92e-8bf8-bc2e-013cba6337f8">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="dispute_option" data-type="statement"></bdt>
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_2" style="line-height: 17.25px; text-align: left;"><strong>Binding Arbitration</strong></div>
</bdt>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" style="text-align: left; line-height: 17.25px;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="text-align: left; line-height: 1.5;">
<span style="font-size: 11pt; line-height: 16.8667px; ">
Any dispute
<span style="font-size: 11pt; line-height: 16.8667px; ">
arising out of or in connection with this contract, including any question regarding its existence, validity or termination, shall be referred to and finally resolved by the International Commercial Arbitration Court under the European Arbitration Chamber (Belgium, Brussels, Avenue Louise, 146) according to the Rules of this ICAC, which, as a result of referring to it, is considered as the part of this clause. The number of arbitrators shall be
<bdt class="question">__________</bdt>
.
<span style="font-size: 11pt; line-height: 16.8667px; ">
The seat, or legal place, of arbitration shall be
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<bdt class="question">__________</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
.
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
The language of the proceedings shall be
<bdt class="question">__________</bdt>
.
</span>
</span>
The governing law of the contract shall be the substantive law of
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<span style="font-size: 11pt; line-height: 16.8667px; ">
<span style="font-size: 11pt; line-height: 16.8667px; ">
<bdt class="block-component"></bdt>
<bdt class="question">__________</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
.
<bdt class="statement-end-if-in-editor"></bdt>
</div>
</bdt>
</bdt>
</bdt>
</div>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_2" style="line-height: 17.25px; text-align: left;"><a name="_inlv5c77dhih"></a><strong>Restrictions</strong></div>
</bdt>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="text-align: left; line-height: 1.5;"><span style="font-size: 11pt; line-height: 16.8667px; ">The Parties agree that any arbitration shall be limited to the Dispute between the Parties individually. To the full extent permitted by law, (a) no arbitration shall be joined with any other proceeding; (b) there is no right or authority for any Dispute to be arbitrated on a class-action basis or to utilize class action procedures; and (c) there is no right or authority for any Dispute to be brought in a purported representative capacity on behalf of the general public or any other persons.</span></div>
</bdt>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="heading_2" style="line-height: 17.25px; text-align: left;"><a name="_mdjlt1af25uq"></a><strong>Exceptions to Arbitration</strong></div>
</bdt>
</bdt>
</bdt>
</div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;"><br></div>
<div class="MsoNormal" style="text-align: justify; line-height: 1;">
<bdt class="block-container if" data-type="if">
<bdt data-type="conditional-block">
<bdt data-type="body">
<div class="MsoNormal" data-custom-class="body_text" style="text-align: left; line-height: 1.5;"><span style="font-size: 11pt; line-height: 16.8667px; ">The Parties agree that the following Disputes are not subject to the above provisions concerning binding arbitration: (a) any Disputes seeking to enforce or protect, or concerning the validity of, any of the intellectual property rights of a Party; (b) any Dispute related to, or arising from, allegations of theft, piracy, invasion of privacy, or unauthorized use; and (c) any claim for injunctive relief. If this provision is found to be illegal or unenforceable, then neither Party will elect to arbitrate any Dispute falling within that portion of this provision found to be illegal or unenforceable and such Dispute shall be decided by a court of competent jurisdiction within the courts listed for jurisdiction above, and the Parties agree to submit to the personal jurisdiction of that court.</span></div>
</bdt>
</bdt>
<bdt class="statement-end-if-in-editor" data-type="close"><span style="font-size: 15px;"></span></bdt>
</bdt>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_mjgzo07ttzx5"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">CORRECTIONS</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
               Calibri;mso-themecolor:text1;mso-themetint:166;">There may be
information on the Site that contains typographical errors, inaccuracies, or
omissions, including descriptions, pricing, availability, and various other
information. We reserve the right to
correct any errors, inaccuracies, or omissions and to change or update the
information on the Site at any time, without prior notice.</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_gvi74blrahf9"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">DISCLAIMER</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
               Calibri;mso-themecolor:text1;mso-themetint:166;">THE SITE IS PROVIDED
ON AN AS-IS AND AS-AVAILABLE BASIS. YOU
AGREE THAT YOUR USE OF THE SITE AND OUR SERVICES WILL BE AT YOUR SOLE RISK. TO THE
FULLEST EXTENT PERMITTED BY LAW, WE DISCLAIM ALL WARRANTIES, EXPRESS OR
IMPLIED, IN CONNECTION WITH THE SITE AND YOUR USE THEREOF, INCLUDING, WITHOUT
LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE, AND NON-INFRINGEMENT. WE MAKE NO WARRANTIES OR REPRESENTATIONS ABOUT
THE ACCURACY OR COMPLETENESS OF THE SITES CONTENT OR THE CONTENT OF ANY
WEBSITES LINKED TO THE SITE AND WE WILL ASSUME NO LIABILITY OR RESPONSIBILITY
FOR ANY (1) ERRORS, MISTAKES, OR INACCURACIES OF CONTENT AND MATERIALS, (2)
PERSONAL INJURY OR PROPERTY DAMAGE, OF ANY NATURE WHATSOEVER, RESULTING FROM
YOUR ACCESS TO AND USE OF THE SITE, (3) ANY UNAUTHORIZED ACCESS TO OR USE OF
OUR SECURE SERVERS AND/OR ANY AND ALL PERSONAL INFORMATION AND/OR FINANCIAL
INFORMATION STORED THEREIN, (4) ANY INTERRUPTION OR CESSATION OF TRANSMISSION
TO OR FROM THE SITE, (5) ANY BUGS, VIRUSES, TROJAN HORSES, OR THE LIKE WHICH
MAY BE TRANSMITTED TO OR THROUGH THE SITE BY ANY THIRD PARTY, AND/OR (6) ANY
ERRORS OR OMISSIONS IN ANY CONTENT AND MATERIALS OR FOR ANY LOSS OR DAMAGE OF
ANY KIND INCURRED AS A RESULT OF THE USE OF ANY CONTENT POSTED, TRANSMITTED, OR
OTHERWISE MADE AVAILABLE VIA THE SITE. WE DO NOT WARRANT, ENDORSE, GUARANTEE,
OR ASSUME RESPONSIBILITY FOR ANY PRODUCT OR SERVICE ADVERTISED OR OFFERED BY A
THIRD PARTY THROUGH THE SITE, ANY HYPERLINKED WEBSITE, OR ANY WEBSITE OR MOBILE
APPLICATION FEATURED IN ANY BANNER OR OTHER ADVERTISING, AND WE WILL NOT BE A
PARTY TO OR IN ANY WAY BE RESPONSIBLE FOR MONITORING ANY TRANSACTION BETWEEN YOU
AND ANY THIRD-PARTY PROVIDERS OF PRODUCTS OR SERVICES. AS WITH THE
PURCHASE OF A PRODUCT OR SERVICE THROUGH ANY MEDIUM OR IN ANY ENVIRONMENT, YOU
SHOULD USE YOUR BEST JUDGMENT AND EXERCISE CAUTION WHERE APPROPRIATE.</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_4pjah3d0455q"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">LIMITATIONS OF LIABILITY</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                  Calibri;mso-themecolor:text1;mso-themetint:166;">
IN NO EVENT WILL WE OR OUR DIRECTORS, EMPLOYEES, OR AGENTS BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, EXEMPLARY, INCIDENTAL, SPECIAL, OR PUNITIVE DAMAGES, INCLUDING LOST PROFIT, LOST REVENUE, LOSS OF DATA, OR OTHER DAMAGES ARISING FROM YOUR USE OF THE SITE, EVEN IF WE HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
<bdt class="block-container if" data-type="if" id="3c3071ce-c603-4812-b8ca-ac40b91b9943">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="limitations_liability_option" data-type="statement"></bdt>
</bdt>
</bdt>
</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_k5ap68aj1dd4"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">INDEMNIFICATION</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                  Calibri;mso-themecolor:text1;mso-themetint:166;">
You agree to
defend, indemnify, and hold us harmless, including our subsidiaries,
affiliates, and all of our respective officers, agents, partners, and
employees, from and against any loss, damage, liability, claim, or demand, including
reasonable attorneys fees and expenses, made by any third party due to or
arising out of:
<bdt class="block-container if" data-type="if" id="475fffa5-05ca-def8-ac88-f426b238903c">
<bdt data-type="conditional-block">
<bdt class="block-component" data-record-question-key="user_post_content_option" data-type="statement"></bdt>
<bdt data-type="body">(1) your Contributions;&nbsp;</bdt>
</bdt>
<bdt class="statement-end-if-in-editor" data-type="close"></bdt>
</bdt>
(<span style="font-size: 14.6667px;">2</span>) use of the Site; (<span style="font-size: 14.6667px;">3</span>) breach of these Terms of Use; (<span style="font-size: 14.6667px;">4</span>) any breach of your representations and warranties set forth in these Terms of Use; (<span style="font-size: 14.6667px;">5</span>) your violation of the rights of a third party, including but not limited to intellectual property rights; or (<span style="font-size: 14.6667px;">6</span>) any overt harmful act toward any other user of the Site with whom you connected via the Site. Notwithstanding the foregoing, we reserve the right, at your expense, to assume the exclusive defense and control of any matter for which you are required to indemnify us, and you agree to cooperate, at your expense, with our defense of such claims. We will use reasonable efforts to notify you of any such claim, action, or proceeding which is subject to this indemnification upon becoming aware of it.
</span>
<span style=" font-size: 14.6667px;"></span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_ftgg17oha0ep"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">USER DATA</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
               Calibri;mso-themecolor:text1;mso-themetint:166;">We will maintain
certain data that you transmit to the Site for the purpose of managing the
performance of the Site, as well as data relating to your use of the Site. Although we perform regular routine backups
of data, you are solely responsible for all data that you transmit or that
relates to any activity you have undertaken using the Site. You agree
that we shall have no liability to you for any loss or corruption of any such
data, and you hereby waive any right of action against us arising from any such
loss or corruption of such data.</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_dkovrslqodui"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">ELECTRONIC COMMUNICATIONS, TRANSACTIONS, AND SIGNATURES</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
               Calibri;mso-themecolor:text1;mso-themetint:166;">Visiting the Site, sending us emails, and completing online forms constitute electronic communications. You consent to receive electronic communications, and you agree that all agreements, notices, disclosures, and other communications we provide to you electronically, via email and on the Site, satisfy any legal requirement that such communication be in writing. YOU HEREBY AGREE TO THE USE OF ELECTRONIC SIGNATURES, CONTRACTS, ORDERS, AND OTHER RECORDS, AND TO ELECTRONIC DELIVERY OF NOTICES, POLICIES, AND RECORDS OF TRANSACTIONS INITIATED OR COMPLETED BY US OR VIA THE SITE. You hereby waive any rights or requirements under any statutes, regulations, rules, ordinances, or other laws in any jurisdiction which require an original signature or delivery or retention of non-electronic records, or to payments or the granting of credits by any means other than electronic means.</span></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                  Calibri;mso-themecolor:text1;mso-themetint:166;">
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 115%;"><a name="_d4jvmcnxg0wt"></a><strong><span style="line-height: 115%; font-family: Arial; font-size: 19px;">MISCELLANEOUS</span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size:11.0pt;line-height:115%;font-family:Arial;
                  Calibri;mso-themecolor:text1;mso-themetint:166;">
These Terms of Use and any policies or operating rules posted by us on the Site or in respect to the Site constitute the entire agreement and understanding between you and us. Our failure to exercise or enforce any right or provision of these Terms of Use shall not operate as a waiver of such right or provision. These Terms of Use operate to the fullest extent permissible by law. We may assign any or all of our rights and obligations to others at any time. We shall not be responsible or liable for any loss, damage, delay, or failure to act caused by any cause beyond our reasonable control. If any provision or part of a provision of these Terms of Use is determined to be unlawful, void, or unenforceable, that provision or part of the provision is deemed severable from these Terms of Use and does not affect the validity and enforceability of any remaining provisions. There is no joint venture, partnership, employment or agency relationship created between you and us as a result of these Terms of Use or use of the Site. You agree that these Terms of Use will not be construed against us by virtue of having drafted them. You hereby waive any and all defenses you may have based on the electronic form of these Terms of Use and the lack of signing by the parties hereto to execute these Terms of Use.
<bdt class="block-component"></bdt>
</span>
</div>
<div class="MsoNormal" style="line-height: 1;"><br></div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size: 15px;">
<bdt class="question">This is not matka gambling website all information are collected from internet sources.
Matka Betting may ban in your area so please use this website on your own risk.
We do not associated with any criminal activity this website is only for informational purpose.
</bdt>
</span>
<span style="font-size: 15px; line-height: 115%; font-family: Arial; ">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</div>
</div>
<div align="center" style="text-align: left; line-height: 1.5;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" style="line-height: 1.5;"><br></div>
<div class="MsoNormal" data-custom-class="heading_1" style="line-height: 1.5;"><a name="_t4pq5cwn486q"></a><strong><span style="line-height: 115%; font-family: Arial;"><span style="font-size: 19px;">CONTACT US</span></span></strong></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;"><span style="font-size:11.0pt;line-height:115%;font-family:Arial;
               Calibri;mso-themecolor:text1;mso-themetint:166;">In order to resolve a complaint regarding the Site or to receive further information regarding use of the Site, please contact us at:</span></div>
</div>
<div align="center" style="text-align: left; line-height: 1;"><br></div>
<div align="center" style="text-align: left;">
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size: 15px; line-height: 115%; font-family: Arial; ">
<bdt class="block-container question question-in-editor" data-id="8a6919c4-2010-e7d6-2305-d74dfb08909d" data-type="question"><strong>Matka HeadOffice</strong></bdt>
</span>
<span style>
<strong>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</strong>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style>
<strong>
<span style="font-size: 15px;">
<bdt class="question">Kalyan, Mumbai</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</strong>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style>
<strong>
<span style="font-size: 15px;">
<bdt class="question">Mumbai</bdt>
<bdt class="block-component"></bdt>
,
<bdt class="question">Maharashtra</bdt>
</span>
</strong>
<strong>
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</strong>
<strong>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</strong>
</span>
<span style>
<strong>
<span style="font-size: 15px;">
<bdt class="question">420002</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
</span>
</strong>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style>
<strong>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<bdt class="question">India</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</strong>
</span>
</div>
<div class="MsoNormal" data-custom-class="body_text" style="line-height: 1.5;">
<span style="font-size: 15px; line-height: 115%; font-family: Arial; ">
<bdt class="block-container question question-in-editor" data-id="fdc2b5b8-c95f-244b-23a7-287f82541348" data-type="question"><strong>support@spboss.in</strong></bdt>
</span>
</div>
<br>
</div>
<style>
            ul {
            list-style-type: square;
            }
            ul > li > ul {
            list-style-type: circle;
            }
            ul > li > ul > li > ul {
            list-style-type: square;
            }
            ol li {
            font-family: Arial ;
            }
         </style>
</div>
</div>
</div>
</div>
<style>
.button2 {
  background-color: #a0d5ff;
  color: #220c82;
  padding: 10px 30px;
  font-size: 16px;
  margin: 20px auto;
  border-radius: 10px;
  border: 2px solid #0000005c;
  font-weight: 800;
  text-shadow: 1px 1px #00bcd4;
  box-shadow: 0 8px 10px 0 rgba(0,0,0,.2) , 0 6px 8px 0 rgba(0,0,0,.19);
  display: inline-block;
  transition: all .3s;
}

.chart-list.ab1 {
  border-color: #003c6c;
}

.chart-list {
  border: 2px solid #eb008b;
    border-top-color: rgb(235, 0, 139);
    border-right-color: rgb(235, 0, 139);
    border-bottom-color: rgb(235, 0, 139);
    border-left-color: rgb(235, 0, 139);
  border-radius: 10px 0 10px 10px;
  margin-bottom: 2px;
  width: 50%;
  margin: 0 auto 10px;
  text-align: center;
  font-weight: 600;
}

footer {
  background-color: #fff;
  color: red;
  font-weight: bold;
  font-size: 25px;
  text-decoration: none;
  border: 4px groove purple;
  border-radius: 10px 0 0 0;
  text-shadow: 1px 1px gold;
  margin: 3px;
}
footer > div {
  border-bottom: 2px solid #b2ddff;
  padding: 10px 0;
  margin-bottom: 10px;
}
footer > div a {
  text-decoration: none;
}
footer p {
  margin: 10px 0 10px;
  line-height: 35px;
  color: red;
font-weight: bold;
font-size: 25px;
text-shadow: 1px 1px gold;
}
footer .ftr-icon {
  text-decoration: none;
  font-size: 35px;
  text-transform: uppercase;
  color: #007bff;
}
.chart-list.ab1 h4 {
  background-color: #024c88;
} 
.chart-list h4 {
  color: #fff;
  padding: 5px 10px 3px;
  font-size: 24px;
  border-top-left-radius: 7px;
  margin: 0;
}
.chart-list {
  text-align: center;
  font-weight: 600;
}
.chart-list a {
  display: block;
  font-size: 22px;
  padding: 5px 7px 4px;
  text-decoration: none;
}
.chart-list.ab1 a {
  border-bottom: 2px solid #024c88;
  color: #003c6c;
}
.chart-list.ab1 h4 {
  background-color: #024c88;
  border-radius: 7px 0px 0px;
  border: none;
}
footer p span {
  color: #36f;
}.chart-list.ab1 h4::before {
  content: none;
}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
.mp-btn {
  position: fixed;
  bottom: 9px;
  left: 5px;
  padding: 5px 8px;
  font-size: 15px;
  border: 1px solid #fff;
  text-decoration: none;
  background-color: #039;
  color: #fff;
  border-radius: 5px;
}
</style>
<center>
<div id="bottom"></div>
<a href="#top" class="button2"> Go to Top </a>
</center>
<p>
69</p>


<footer style="font-style: normal;">
<div>
<a style="color: red;" href="https://spboss.in" title="SATTA MATKA">Home</a> |
<a style="color: green;" href="https://spboss.in/guessing-forum.php" title="Satta matka guessing">Guessing Forum</a> |
<a style="color: purple;" href="https://spboss.in/ever-green-tricks/satta-matka-tricks-zone-tips.php" title="Satta matka tricks">100% Fix Jodi Tricks</a> |
<a style="color: blue;" href="https://spboss.in/satta-matka-fix-game.php" title="SATTA MATKA">Date Fix Game</a> |
<br>
<a style="color: purple;" href="https://spboss.in/about.php" title="About">About Us</a> |
<a style="color: purple;" href="https://spboss.in/contact.php" title="Contact">Contact Us</a> |
<a style="color: purple;" href="https://spboss.in/tos.php" title="Term and Conditions">T&C</a> |
<a style="color: purple;" href="https://spboss.in/privacy.php" title="Privacy Policy">Privacy Policy</a> |
</div>
<a class="ftr-icon" href="https://spboss.in">spboss.in</a>
</footer>

<a class="mp-btn" href="https://sachin99.com" rel="nofollow" target="_blank"><i>Matka Play</i></a>
</body></html>
