<!DOCTYPE html>
<html lang="en-in">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>BAAZI BAAR BAAR LIVE STAR LINE PANEL CHART RECORD OLD HISTORY DPBOSS MATKA SATTA</title>
<meta name="description" content="BAAZI BAAR BAAR LIVE starline Chart BAAZI BAAR BAAR LIVE Star Line Panel penal chart jodii chart record old data dpboss BAAZI BAAR BAAR LIVE star line history by dpboss net satta matka BAAZI BAAR BAAR LIVE mp up bihar main star line" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="canonical" href="https://spboss.in/baazi-baar-baar-live-starline-chart.php" />
<link rel="stylesheet" href="https://spboss.in/starline/bootstrap.min.css" />
<style type="text/css">
body {
    font-size: 30px;
    padding-top: 0!important;
    background: #fc9;
    background-color: #fc9 !important;
    color: #000;
    font-fAMily: sans-serif;
}
p {
    margin-bottom: 0;
}
.B1 {
    background-color: #fc9;
    color: #000;
    border-width: 3px;
    border-color: #ff006c;
    border-style: solid;
    border-top-left-radius: 10px;
    border-top-right-radius: 2px;
    border-bottom-left-radius: 2px;
    margin-top: 1px;
    margin-bottom: 1px;
    font-weight: bold;
    font-size: x-large;
    text-shadow: 1px 1px navy;
    padding-top: 1px;
    padding-bottom: 1px;
    padding-left: 2px;
    padding-right: 2px;
    margin-left: 10px;
    margin-right: 10px;
}
.satta-matka-jodi-subtitle {
    border:4px solid #ff006c;
    margin-top: 10px;
    background-color: white !important;
    border-top-left-radius: 10px;
    padding: 15px 0;
    margin-left: 10px;
    margin-right: 10px;
}
.satta-matka-jodi-subtitle big {
    color: #ff006c;
    font-weight: 700;
    font-size: 32px;
}
.tops, .bottoms {
    box-shadow: 0 8px 10px 0 rgba(0,0,0,.2), 0 6px 8px 0 rgba(0,0,0,.19);
    background-color: #fff0;
    border: none;
    color: navy;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    -webkit-transition-duration: .4s;
    transition-duration: .4s;
    border-radius: 5px;
    border: #0f0 2px solid;
    font-weight: 800;
    text-shadow: 1px 1px cyan;
    cursor: pointer;
}
.d-f.jcc {
    display: flex;
    justify-content: center;
}
.tops:focus, .tops:hover {
    color: #23527c !important;
    text-decoration: underline !important;
}
.headera{
    border: none !important;
    background: transparent !important;
    padding-bottom: 0;
    margin: 0 !important;
    display: -webkit-flex;
    display: -moz-flex;
    display: -ms-flex;
    display: -o-flex;
    display: flex;
}
.timebazar {
    background: #3f51b5 !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    color: #fff;
    width: 100%;

}
.headera font{
    width: 100%;
}
.headera font span {
}
.date {
    border: none !important;
    background: transparent !important;
    border: 2px solid #2196f3 !important;
}
.table-pc {
    width: 100%;
    background-color: transparent;
}
.date {
    margin-bottom: 10px;
}
table, td, th {
    border: 1px solid #666;
}
table {
    border-spacing: 0;
    border-collapse: collapse;
    text-align: center;
}
thead tr {
    background: #e1e1e1;
    color: #000;
    font-size: 14px;
}
thead td {
    padding: 15PX 0PX;
    font-weight: 700;
}
tbody tr span, 
tbody tr td,
tbody tr p {
    font-weight: 600;
    text-shadow: 1px 1px 2px #adadad;
}
tbody tr td {
    padding: 5px;
}
tbody tr td span {
        font-size: 22px;
    line-height: 1.5;
}
tbody tr td:first-child p {

    line-height: 1.5;
}

/*footer*/
.footer {
    text-align: center;
    margin-top: 10px
;}
.ftr-div {
    background-color: white;
    color: red;
    font-weight: bold;
    font-style: none;
    font-size: x-large;
    text-decoration: none;
    border-width: 4px;
    border-color: purple;
    border-style: groove solid;
    text-shadow: 1px 1px gold;
    padding: 15px 0;
}
@media only screen and (max-width: 1440px) {
.date {
    width: 80%;
}
} /*end media*/
@media only screen and (max-width: 1024px) {
.date {
    width: 100%;
}
} /*end media*/
@media only screen and (max-width: 500px) {
	
body {
    padding-left: 2px;
    padding-right: 2px;
	
}
.timebazar {
    font-size: 18px;
    padding-top: 5px !important;
    padding-bottom: 5px !important;
}
thead td {
    font-size: 12px;
}
tbody tr td:first-child p {
    font-size: 12px;
}
tbody tr td {
    padding: 1px;
    font-size: 12px;
}
tbody tr td span {
        font-size: 14px;
    line-height: 1.2;
}
} /*end media*/
/**/
/**/
</style>
</head>
<body id="fcontent">
<div class="satta-matka-jodi-subtitle" align="center"><h1 style="color: #ff006c;font-weight: 700;font-size: 32px;">BAAZI BAAR BAAR LIVE STARLINE PENAL CHART </h1></div>
<div style="text-align:center;padding:25px;">
<a href="#bottom" class="tops" onclick="bottomFunction()">Go To Bottom</a>
</div>
<div align="center">
</div>
<div class="date " style="float:none;margin-left:auto;margin-right:auto;overflow:auto;border-top: none;" align="center">
<div class="headera">
<span class="timebazar">BAAZI BAAR BAAR LIVE STARLINE PENAL CHART</span>
</div>
<table class="table-pc" cellspacing="0" style="overflow:auto;">
<thead>
<tr>
<td>DATE</td>
<td>12 PM</td>
<td>01 PM</td>
<td>02 PM</td>
<td>03 PM</td>
<td>04 PM</td>
<td>05 PM</td>
<td>06 PM</td>
<td>07 PM</td>
<td>08 PM</td>
<td>09 PM</td>
</tr>
</thead>
<tbody>
<tr>
<td><p>03-12-2023<br>Sunday</p></td>
<td style="color: black">230<br><span class="normal">5</span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
</tr>
<tr>
<td><p>12-10-2023<br>Thursday</p></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: "><br><span class="normal"></span></td>
<td style="color: black">578<br><span class="normal">0</span></td>
</tr>
<tr>
<td><p>06-10-2023<br>Friday</p></td>
<td style="color: black">160<br><span class="normal">7</span></td>
<td style="color: black">157<br><span class="normal">3</span></td>
<td style="color: black">136<br><span class="normal">0</span></td>
<td style="color: black">570<br><span class="normal">2</span></td>
<td style="color: black">550<br><span class="normal">0</span></td>
<td style="color: black">146<br><span class="normal">1</span></td>
<td style="color: black">567<br><span class="normal">8</span></td>
<td style="color: black">290<br><span class="normal">1</span></td>
<td style="color: black">112<br><span class="normal">4</span></td>
<td style="color: black">456<br><span class="normal">5</span></td>
</tr>
<tr>
<td><p>07-10-2023<br>Saturday</p></td>
<td style="color: black">230<br><span class="normal">5</span></td>
<td style="color: black">157<br><span class="normal">3</span></td>
<td style="color: black">269<br><span class="normal">7</span></td>
<td style="color: black">200<br><span class="normal">2</span></td>
<td style="color: black">250<br><span class="normal">7</span></td>
<td style="color: black">170<br><span class="normal">8</span></td>
<td style="color: black">399<br><span class="normal">1</span></td>
<td style="color: black">289<br><span class="normal">9</span></td>
<td style="color: black">233<br><span class="normal">8</span></td>
<td style="color: black">578<br><span class="normal">0</span></td>
</tr>
<tr>
<td><p>02-10-2023<br>Monday</p></td>
<td style="color: black">470<br><span class="normal">1</span></td>
<td style="color: black">270<br><span class="normal">9</span></td>
<td style="color: black">123<br><span class="normal">6</span></td>
<td style="color: black">234<br><span class="normal">9</span></td>
<td style="color: black">380<br><span class="normal">1</span></td>
<td style="color: black">456<br><span class="normal">5</span></td>
<td style="color: black">169<br><span class="normal">6</span></td>
<td style="color: black">134<br><span class="normal">8</span></td>
<td style="color: black">166<br><span class="normal">3</span></td>
<td style="color: black">570<br><span class="normal">2</span></td>
</tr>
<tr>
<td><p>03-10-2023<br>Tuesday</p></td>
<td style="color: black">450<br><span class="normal">9</span></td>
<td style="color: black">389<br><span class="normal">0</span></td>
<td style="color: black">490<br><span class="normal">3</span></td>
<td style="color: black">359<br><span class="normal">7</span></td>
<td style="color: black">789<br><span class="normal">4</span></td>
<td style="color: black">299<br><span class="normal">0</span></td>
<td style="color: black">480<br><span class="normal">2</span></td>
<td style="color: black">150<br><span class="normal">6</span></td>
<td style="color: black">249<br><span class="normal">5</span></td>
<td style="color: black">160<br><span class="normal">7</span></td>
</tr>
<tr>
<td><p>04-10-2023<br>Wednesday</p></td>
<td style="color: black">123<br><span class="normal">6</span></td>
<td style="color: black">478<br><span class="normal">9</span></td>
<td style="color: black">140<br><span class="normal">5</span></td>
<td style="color: black">689<br><span class="normal">3</span></td>
<td style="color: black">120<br><span class="normal">3</span></td>
<td style="color: black">790<br><span class="normal">6</span></td>
<td style="color: black">578<br><span class="normal">0</span></td>
<td style="color: black">144<br><span class="normal">9</span></td>
<td style="color: black">457<br><span class="normal">6</span></td>
<td style="color: black">220<br><span class="normal">4</span></td>
</tr>
<tr>
<td><p>05-10-2023<br>Thursday</p></td>
<td style="color: black">337<br><span class="normal">3</span></td>
<td style="color: black">190<br><span class="normal">0</span></td>
<td style="color: black">189<br><span class="normal">8</span></td>
<td style="color: black">230<br><span class="normal">5</span></td>
<td style="color: black">578<br><span class="normal">0</span></td>
<td style="color: black">250<br><span class="normal">7</span></td>
<td style="color: black">360<br><span class="normal">9</span></td>
<td style="color: black">125<br><span class="normal">8</span></td>
<td style="color: black">134<br><span class="normal">8</span></td>
<td style="color: black">445<br><span class="normal">3</span></td>
</tr>
</table>
</div>
<center>
<div id="bottom"></div>
<a href="#top" class="button2"> Go to Top </a>
</center>
<style>

html{overflow-x:hidden;scroll-behavior:smooth}body{background-color:#fc9;color:#000;font-weight:700;text-align:center!important;margin-bottom:0;margin-top:4px;font-family:Helvetica,sans-serif!important}*{transition:all .3s}a{text-decoration:none!important;color:inherit}.my-header{border-radius:10px 0 10px 10px;margin-bottom:3px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:1px 2px}.my-header img{height:160px;width:auto;margin:-28px 0 -34px}.open-close{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:20px 5px 22px}.open-close h2{color:#fff;font-size:32px;background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);display:inline-block;padding:10px 20px 10px;margin:0;border-radius:10px}.open-close h3{color:#1a237e;font-size:29px;margin:0 0 20px}.my-card{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #9c27b0;box-shadow:0 0 9px -1px #ffeddc;padding:0 0 2px;overflow:hidden}.my-card h3{color:#fff;font-size:32px;margin:0;padding:2px 0 1px}.headering-1 h3{background-color:#50005b}.headering-2 h3{background-color:#ff0;color:#000}.headering-3 h3{background-color:#0f005b}.my-card h2{color:#232323;margin:10px 0;font-size:22px}.my-footer{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:0 5px 22px}.my-footer .top-div{z-index:81}.my-footer .top-div a{z-index:41;cursor:pointer}.my-footer .my-img{z-index:-10}.my-footer .my-img img{height:160px;width:auto;margin:-28px 0 -34px;z-index:-9}.my-footer .two-btn a{border:2px solid #e91e63;padding:3px 8px 4px;border-radius:5px;font-size:18px;color:#fff;background-color:#e91e63;font-weight:500;display:inline-block}.my-footer .last-para{margin:20px 0 0}.my-footer .last-para p{margin:6px 0 0;font-size:20px;font-weight:400;color:#151515}@media only screen and (max-width:500px){.my-header img{height:90px;width:auto;margin:-16px 0 -19px}.open-close{padding:8px 0 10px}.open-close h3{font-size:20px;margin-bottom:10px}.open-close h2{font-size:22px}.my-card h3{font-size:24px}.my-card h2{font-size:17px}.my-footer{padding-bottom:10px}.my-footer .my-img img{height:100px;width:auto;margin:-16px 0 -19px}.my-footer .two-btn a{font-size:14px;padding:5px 5px 6px}.my-footer .last-para p{font-size:16px}}@media only screen and (max-width:320px){.my-footer .two-btn a{font-size:12px;padding:3px}}


.logo {
border: 2px solid #eb008b;
border-radius: 10px 0 10px 10px;
margin: 2px;
overflow: hidden;
}
.logo amp-img {
width: 220px;
height: auto;
padding: 6px 0 0;
}
.button2 {
background-color: #a0d5ff;
color: #220c82;
padding: 10px 30px;
font-size: 16px;
margin: 20px auto;
border-radius: 10px;
border: 2px solid #0000005c;
font-weight: 800;
text-shadow: 1px 1px #00bcd4;
box-shadow: 0 8px 10px 0 rgb(0 0 0 / 20%), 0 6px 8px 0 rgb(0 0 0 / 19%);
display: inline-block;
transition: all .3s;
}.ad-div11 {
text-align: center;
margin: 0 0 10px;
}
.chart-list {
border: 2px solid #eb008b;
border-radius: 10px 0 10px 10px;
margin-bottom: 2px;
width: 50%;
margin: 0 auto 10px;
text-align: center;
font-weight: 600;
}
.chart-list.ab1 {
border-color: #003c6c;
}
.chart-list h4 {
color: #fff;
padding: 5px 10px 3px;
font-size: 24px;
border-top-left-radius: 7px;
margin: 0;
}
.chart-list.ab1 h4 {
background-color: #024c88;
}
.chart-list a {
display: block;
font-size: 22px;
padding: 5px 7px 4px;
text-decoration: none;
}
.chart-list.ab1 a {
border-bottom: 2px solid #024c88;
color: #003c6c;
}
footer {
background-color: #fff;
color: red;
font-weight: bold;
font-size: 25px;
text-decoration: none;
border: 4px groove purple;
border-radius: 10px 0 0 0;
text-shadow: 1px 1px gold;
margin: 3px;
}
footer > div {
border-bottom: 2px solid #b2ddff;
padding: 10px 0;
margin-bottom: 10px;
}
footer > div a {
text-decoration: none;
}
footer > div a:hover {
text-decoration: none;
}
footer .ftr-icon {
text-decoration: none;
font-size: 35px;
text-transform: uppercase;
color: #007bff;
}
footer p {
margin: 10px 0 10px;
line-height: 35px;
}
footer p span {
color: #36f;
}

body {
  background-color: #fc9;
  text-align: center;
  padding-left: 10px;
  padding-right: 10px;
  font-family: 'Roboto',sans-serif;
}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
</style>
<div class="chart-list ab1">
<h4>SPECIAL DAILY GAME ZONE</h4>
<a href="https://spboss.in/guessing-forum.php"> Dpboss Guessing Forum </a>
<a href="https://spboss.in/satta-matka-fix-game.php"> 100% Date Fix Free Game Open TO Close </a>
<a href="https://spboss.in/khatris-favourite-panna-chart.php"> Ratan Khatri Fix Panel Chart </a>
<a href="https://spboss.in/matka-final-number-chart.php"> Matka Final Number Trick Chart </a>
<a href="https://spboss.in/matka-jodi-count-chart.php">Matka Jodi Count Chart</a>
<a href="https://spboss.in/fix-open-to-close-by-date.php">Dhanvarsha Daily Fix Open To Close</a>
<a href="https://spboss.in/jodi-chart-family-matka.php">Matka Jodi Family Chart</a>
<a href="https://spboss.in/penal-count-chart.php">Penal Count Chart</a>
<a href="https://spboss.in/penal-total-chart.php">Penal Total Chart</a>
<a href="https://spboss.in/all-22-card-panna-penal-patti-chart.php">All 220 Card List</a>
</div>


<footer>
<div>
<a style="color: red;" href="https://spboss.in" title="SATTA MATKA">Home</a> |
<a style="color: green;" href="https://spboss.in/guessing-forum.php" title="Satta matka guessing">Guessing Forum</a> |
<a style="color: purple;" href="https://spboss.in/ever-green-tricks/satta-matka-tricks-zone-tips.php" title="Satta matka tricks">100% Fix Jodi Tricks</a> |
<a style="color: blue;" href="https://spboss.in/satta-matka-fix-game.php" title="SATTA MATKA">Date Fix Game</a>
</div>
<a class="ftr-icon" href="https://spboss.in">spboss.in</a>
<p>
All Rights Reseved®
<br>
(1980-2022)
<br>
Contact (Astrologer-<span>Dpboss</span>)
</p>
</footer>
</html>