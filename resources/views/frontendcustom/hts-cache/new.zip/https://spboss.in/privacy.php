<!DOCTYPE html><html lang="en-in"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SPBOSS PRIVACY POLICY CHECKOUT NOW</title>
<meta name="Description" content="We only share information with your consent, to comply with laws, to provide you with services, to protect your rights SPBOSS app SPBOSS netSPBOSS final anksatta matta matkaSPBOSS 143 guessing SPBOSS whatsapp group" />
<link rel="canonical" href="https://spboss.in/privacy.php" />
<meta http-equiv="refresh" content="900" />
<meta name="google" content="notranslate" />
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="yes" name="apple-touch-fullscreen">
<meta name="Robots" content="index, follow">
<meta name="author" content="SPBOSS">
<meta name="copyright" content="SPBOSS net satta matka" />
<meta property="og:type" content="website">
<meta property="og:title" content="Satta Matka">
<meta property="og:description" content="SattaMatka">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="https://spboss.in/fav/favicon.ico">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html{overflow-x:hidden;scroll-behavior:smooth}.dp-topbox{border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px}.dp-topbox h1{font-size:16px;color:#1a237e;padding-bottom:3px}.dp-topbox p{color:#444;font-size:14px}body{background-color:#fc9;text-align:center;padding:3px 10px;margin:0;scroll-behavior:smooth;font-style:italic;font-family:Helvetica,sans-serif;font-weight:700}*{margin:0;padding:0;box-sizing:border-box}a,a:hover{text-decoration:none}.about-us a,.about-us b,.about-us p,.disclamer h2,.disclamer p,.faq a,.faq h4,.faq p,.ftr-sm h2,.ftr-sm p,.pby-us{font-style:normal}.about-us,.blue-div,.cm-patti,.conta,.disclamer,.faq,.ftr-sm,.matka-result,.mrque-div,.paid-gm,.pby-us,.purpel-header,.red-list>div,.satta-result,.satta-text,.slash-text{color:#000;text-align:center;margin-bottom:8px;margin-top:-2px;display:block;font-size:20px;outline:4px #fff;outline-offset:-9px;border:2px solid #ff182c!important;border-style:outset;border-radius:10px;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}.logo{background:#fc9;padding:0 10px;display:block;color:#fff8f8!important;margin-bottom:20px;letter-spacing:1px;font-weight:700;border:3px solid #ff0016;border-radius:.75em;transform-style:preserve-3d;transition:transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1)}

.para1{margin-bottom:5px;display:flex;padding:5px;align-items:center;justify-content:space-between;border-radius:10px;border:2px solid #ff182c;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}p{color:#000b65;text-shadow:1px 1px 2px #fff}.para2{border-width:3px;border:2px solid #0014e2;margin-bottom:5px;border-style:outset;border-radius:10px;border:2px solid #ff182c;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}.para2 h1{background:-webkit-linear-gradient(#ff019c,#72000a);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.para2 h5{color:#061699!important;text-shadow:1px 1px 2px #fff}.para3{background:linear-gradient(187deg,#fc9 50%,#ffc387 50%);border:2px solid #ff0016;border-style:outset;border-radius:10px;margin-bottom:5px;line-height:1.4;font-size:14px;padding:4px 10px;color:#00094d;text-shadow:1px 1px 2px #fff;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}table{box-shadow:0 0 20px 0 rgb(0 0 0 / 40%);margin:5px 0}.paid-gm p,.satta-result div{border-bottom:1px solid #ff0018}.logo img{height:73px;padding:6px 0 0}.mrque-div{display:flex;padding:5px;align-items:center}.mrque-div img{width:90px;height:auto;border-radius:5px}.mrque-div marquee{color:red;font-size:15px;height:21px;display:inline-block}.mrque-div p{padding:0 20px;color:red}.satta-text{padding:5px;height:100px}@media only screen and (max-width:500px){.satta-text{height:150px}}.satta-text h1{font-size:16px;color:#1a237e;padding-bottom:3px}.satta-text p{color:#444;font-size:14px}.cm-patti{border-color:#ff0016}.cm-patti .row{display:-webkit-flex;display:-moz-flex;display:-ms-flex;display:-o-flex;display:flex}.cm-patti .row>div{width:50%}.cm-patti h4{font-size:24px;color:#001699;text-shadow:1px 1px 2px #fff}.cm-patti p{font-size:22px;text-shadow:none}.cm-patti .aa55{border-right:1px solid #ff0016}.cm-patti .bb55{border-left:1px solid #000ff4}.a-27-title,.banner,.cm-patti h3,.fg-div h4,.matka-result h4,.my-table.mumraj-sl h4{background:#ff00a2;padding:5px 10px;text-shadow:1px 1px 2px #000;display:block;color:#fff8f8!important;margin-bottom:20px;letter-spacing:1px;font-weight:700;border:2px solid #fff;border-radius:.75em;transform-style:preserve-3d;transition:transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1)}.a-27-title::before,.banner::before,.cm-patti h3::before,.fg-div h4::before,.matka-result h4::before,.my-table.mumraj-sl h4::before{position:absolute;content:"";width:100%;height:100%;top:0;left:0;right:0;bottom:0;background:#ff182c;border-radius:inherit;transform:translate3d(0,.75em,-1em);transition:transform 150ms cubic-bezier(0,0,.58,1),box-shadow 150ms cubic-bezier(0,0,.58,1)}.matka-card h6{font-size:22px;color:#00094d;text-shadow:1px 1px 2px #fff}.matka-card h6:not(:first-child){border-top:1px solid #ff0020;margin-top:5px}.matka-card h5{color:#880e4f;text-shadow:1px 1px 2px #ffe2c6;font-size:21px;line-height:1;margin:3px 0}.matka-card a,.refresh-btn{border:1px solid #e6e6e6;background:#522f92;color:#fff;padding:5px 7px;border-radius:8px;font-size:12px;margin:2px 0 -1px;display:inline-block;transition:all .3s}.matka-card a:hover,.refresh-btn:hover{box-shadow:0 0 13px 3px #00000033;cursor:pointer}.conta{padding-top:4px;padding-bottom:7px;background-color:#fbe7ff;display:-webkit-flex;display:-moz-flex;display:-ms-flex;display:-o-flex;display:flex;-ms-align-items:center;align-items:center;justify-content:center}.conta p{font-size:22px;color:#ed143d;display:flex;flex-direction:column;justify-content:center;margin-right:12px}.conta a:hover{box-shadow:0 0 10px 0 #000}.slash-text{color:#000;line-height:1.4;font-size:14px;padding:4px 10px;text-shadow:1px 1px #f4e1e1}.satta-result h4{font-size:22px;color:#00094d;text-shadow:1px 1px 2px #fff}.satta-result h5{margin:0;font-size:22px;line-height:1;background:-webkit-linear-gradient(#4500bf,#670009);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.satta-result h6{font-size:15px;padding:2px 0;margin-bottom:0;color:#000;text-shadow:1px 1px 2px #ffd9d9}.satta-result div{padding:3px}.satta-result div:last-child{border-bottom-width:0}.yellowbg{background-color:#ff0;border-bottom:1px solid #ff9800!important}.paid-gm{border-color:#085e58}.paid-gm h4{background-color:#085e58;color:#fff;font-size:28px;padding:3px 0 4px}.paid-gm img{border:2px solid #085e58;border-radius:10px 0 10px 10px;width:250px;height:auto;margin-top:4px}.paid-gm p{padding:6px 20px;text-shadow:1px 1px 2px #eee}.paid-gm .aa,.paid-gm .bb{color:#000;font-size:18px}.paid-gm .bb,.paid-gm .cc,.paid-gm .dd{color:#085e58}.paid-gm .cc{font-size:19px}.paid-gm .dd{font-size:20px}.paid-gm .ee{color:#e91e63;padding-bottom:3px;font-size:21px}.paid-gm .ff{color:#e91e63;font-size:15px}.paid-gm .telegram1{border:2px solid #ff006c;background-color:#ff006c;color:#fff;padding:3px 7px;border-radius:8px 0;box-shadow:0 0 1px #000000d6;font-size:12px;margin:2px 0 -1px;display:inline-block;transition:all .3s;top:auto;position:fixed;left:10px;right:auto}.btn-hide{display:none!important}.gg{color:#000;font-size:32px}.paid-gm span{display:block}.my-table{margin-bottom:2px}.my-table h4{border:solid 2px #ff002b;border-bottom-width:0;padding:3px 5px 2px;font-size:24px}.my-table table{border-collapse:collapse;width:100%}.my-table thead{background-color:#fff;font-size:16px}.my-table tbody{font-size:16px}.my-table td,.my-table th{border:1px solid #ff0016}.my-table td,.my-table th{padding:2px 0;font-size:15px;text-shadow:1px 1px 2px #fff}.my-table th{color:#e91e63}.my-table tr td:nth-child(2),.my-table tr td:nth-child(4){color:#0808b2}.my-table.cm-sl h4,.my-table.mr-sl h4{background:#ffd902;padding:5px 10px;text-shadow:1px 1px 2px #fff;display:block;color:#000!important;margin-bottom:20px;margin-top:10px;letter-spacing:1px;font-weight:700;border:2px solid #000;border-radius:.75em;transform-style:preserve-3d;transition:transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1)}.my-table.cm-sl h4::before,.my-table.mr-sl h4::before{position:absolute;content:"";width:100%;height:100%;top:0;left:0;right:0;bottom:0;background:#ffb002;border-radius:inherit;transform:translate3d(0,.75em,-1em);transition:transform 150ms cubic-bezier(0,0,.58,1),box-shadow 150ms cubic-bezier(0,0,.58,1)}.blue-div{border:2px solid #1f3092}.blue-div h4{background:#ff1731;color:#fff;border-radius:10px;font-size:30px;padding:3px 5px;text-shadow:1px 1px 2px #000;clip-path:polygon(0 0,97% 0,100% 48%,100% 80%,100% 100%,3% 100%,0 46%,0 20%)}.blue-div a:last-child{border-bottom-width:0}.blue-div a{background-image:linear-gradient(-225deg,#231557 0,#44107a 29%,#ff1361 67%,#ff0025 100%);background-size:200% auto;color:#fff;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:textclip 2s linear infinite;font-size:22px;display:block;border-bottom:2px solid #ff0026;padding:5px}@keyframes textclip{to{background-position:200% center}}.red-list>div{border-color:#e71d36}.red-list h4{animation:changeBackgroundColor 5s infinite;border-radius:10px;color:#fff;line-height:1.1;padding:4px 10px 3px;text-shadow:1px 1px 2px #000;font-size:24px}.red-list p{font-size:18px;text-align:center;line-height:1.3}.purpel-header h4{color:#fff;padding:5px 10px 3px;font-size:24px}.purpel-header a{display:block;font-size:22px;padding:5px 7px 4px}.ab1 a{border-bottom:2px solid #00189f;color:#1a237e;text-shadow:1px 1px #d9d9d9}.purpel-header a:last-child{border-bottom-width:0}.ab1{border-color:#00189f!important}.ab2 a{border-bottom:2px solid #b9005e;color:#880e4f;text-shadow:1px 1px 2px #ffe2c6}.ab2{border-color:#b9005e!important}.faq h4{color:#d70544;font-size:22px;padding:5px 5px 6px;border-top:1.5px solid #e0557f;margin-top:5px}.faq h4:first-child{border-top-width:0;margin-top:0}.faq p{font-size:12px;padding:0 5px 15px;line-height:1.4;color:#1a1a1a}.faq a{color:#d70544;text-decoration:underline}.ftr-sm h2{color:#bb2833;text-shadow:1px 1px 2px #fff}@media only screen and (max-width:768px){.faq h4{font-size:15px}}.about-us span{border:1px solid #e6e6e6;background:#522f92;color:#fff;padding:5px 7px;border-radius:8px;font-size:12px;margin:2px 0 -1px;display:inline-block}.disclamer h4{font-size:18px;margin-bottom:15px;padding-top:4px;text-shadow:1px 1px 3px #000}.disclamer p{font-size:13px;color:#340d7a;padding:2px 5px 5px;line-height:1.2}.about-us{padding:5px}.about-us p{font-size:13px;margin-bottom:0;color:#000;padding-bottom:15px}.about-us b{color:#0013a5;text-transform:uppercase}.about-us a{background-color:#e91e63;color:#fff;padding:4px 6px;display:inline-block;text-shadow:1px 1px 2px #2f2f2f;border-radius:4px}.ftr-sm{padding:5px}.ftr-sm h4{font-size:18px;margin-bottom:4px;color:#d3003f}.ftr-sm p{color:#a50031;font-size:12px;line-height:1.4}.pby-us{text-shadow:1px 1px #f4e1e1;color:#000;padding-top:2px;padding-bottom:1px}.refresh-btn{position:fixed;bottom:10px;right:10px}.bdr-b-0{border-width:0!important}.p-0{padding:0!important}@media only screen and (max-width:500px){body{padding:2px 5px}.faq h4{font-size:15px}}.result_timing,.result_timing_right{position:absolute;color:#7a028d;font-size:15px;padding:2px 0;transform:translateY(-158%);border-bottom:none!important}.result_timing{left:14px;right:auto}.result_timing_right{right:14px;left:auto}.btn_chart{color:#fff;padding:5px 7px;border-radius:8px;font-size:12px;margin:2px -5px -1px;display:block;transition:all .3s;text-shadow:1px 1px 2px #222;margin-top:5px;border:1px solid #e6e6e6;background:#522f92}@media(max-width:500px){.btn_chart{margin:2px -9px -1px}}.mb-1{margin-bottom:5px}.p-1{padding:5px 10px 8px}.bdr{border:2px solid #ff001d;border-radius:10px;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%)}.fg-div h6{font-size:22px;background-color:transparent;color:#1a237e;text-shadow:1px 1px 2px #fff}.fg-div h5{font-size:22px;color:#000;text-shadow:1px 1px 2px #fff}.fg-div .fg-p1{font-size:22px}.fg-div .fg-c1>div{border:2px solid #008906;border-radius:10px;margin:5px 0;padding:5px}.fg-div .fg-c1 .fg-p2{text-shadow:1px 1px 0 #fff;letter-spacing:1px}.fg-div .fg-c1 .fg-p3{font-size:22px;color:#080808;text-shadow:1px 1px 2px #ffe2c6}.fg-div .fg-c1 .fg-p4{font-size:20px}.login-div{margin:0 0 0;padding:6px 30px;margin-bottom:10px}.login-div a{border-radius:5px;font-size:14px}.login-div a:nth-child(2),.nnb8{margin:0 10px}@media only screen and (max-width:500px){.login-div{display:block}.login-div a{display:block;margin:10px 0!important}.conta p{display:block;font-size:17px}.conta{display:block}.conta a{margin-top:5px}}.fg-c1{width:50%;display:inline-block;padding:5px;border-color:#009206;border-style:solid}.fg-div .fg-c1 .fg-p2{background:linear-gradient(#00d309,#004503);font-size:22px!important;margin-bottom:5px;padding:7px 0 7px;border-radius:10px;clip-path:polygon(0 0,97% 0,100% 48%,100% 80%,100% 100%,3% 100%,0 46%,0 20%);color:#fff;text-shadow:1px 1px 2px red}.fg-div .fg-c1 .fg-p4{font-size:20px!important;line-height:24px}p.time{text-align:left;color:#444;margin-left:10px}p.betting{color:#ff0;font-size:12px;text-shadow:1px 1px 2px #000}.paa3{border-radius:10px;border:2px solid #ff001e;border-style:outset;margin:10px 0;box-shadow:0 0 20px 0 rgb(0 0 0 / 40%);text-shadow:1px 1px 2px #fff;padding:10px}.btn{display:inline-block;font-weight:400;line-height:1.5;color:#212529;text-align:center;text-decoration:none;vertical-align:middle;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;user-select:none;background-color:transparent;border:1px solid transparent;padding:3px 10px;margin:4px 0 1px;font-size:1rem;border-radius:.25rem;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;cursor:pointer}.btn-primary{color:#fff;background-color:#0d6efd;border-color:#0d6efd}.btn-danger{color:#fff;background-color:#dc3545;border-color:#dc3545}.fg-main.para-1.bdr.mb-1.p-1{padding:0}.fg-main.para-1.bdr.mb-1.p-1 *{font-style:normal!important}.fgzoc-time{border:2px solid #ff019e;margin:5px 5px 0;border-radius:10px}@media only screen and (max-width:600px){.fg-div .fg-c1 .fg-p2{font-size:14px!important}.fg-div .fg-c1 .fg-p4{font-size:9px!important;line-height:20px}}.card-1212{display:flex;flex-wrap:wrap;margin:5px;border-radius:10px;overflow:hidden}.fg-c1:nth-child(odd){border-width:0 1px 2px 2px!important;margin:0;border-radius:0}.fg-c1:nth-child(even){border-width:0 2px 2px 1px!important;margin:0;border-radius:0}.card-1212 .fg-c1:nth-child(1),.card-1212 .fg-c1:nth-child(2){border-top-width:2px!important}.faq{border:2px solid #003db6;border-radius:10px;width:calc(100% - 8px);padding:3px 0;margin:5px auto 5px;width:auto;display:block}.faq p{color:#000;font-weight:700;text-transform:uppercase;margin:0;font-size:12px;font-style:normal;padding:0 10px 5px;text-transform:capitalize;opacity:.9}.faq a{color:#d70544;font-weight:700;text-transform:capitalize;text-decoration:none}.my-checkbox{position:fixed;top:0;left:-9999px;visibility:hidden}.faq label{cursor:pointer;text-transform:uppercase;color:#0013a5;text-shadow:1px 1px 2px #fff;font-weight:800;font-size:17px;padding:3px 0;display:block}.faq label+div{height:0;overflow:hidden;transition:all .3s;padding:0!important}.faq label+div{height:auto}.faq .faq-card{border-top:1.5px solid #e0557f}.faq .faq-card.aabbcc{border-top:0 solid #dc1f44}@media only screen and (max-width:500px){.faq label{font-size:15px}}@media only screen and (max-width:375px){.faq label{font-size:13px}}@media only screen and (max-width:320px){.faq label{font-size:11px}}.mp-btn{position:fixed;bottom:9px;left:5px;padding:5px 8px;font-size:15px;border:1px solid #fff;text-decoration:none;background-color:#039;color:#fff;border-radius:5px}.btm-btn-f{background:linear-gradient(45deg,navy,#005780);border:1px solid #fff;font-size:14px;border-radius:5px;padding:6px 11px 5px;transition:all .3s ease-in}.btm-btn-f:hover{border:1px solid #011481;background:#fff;box-shadow:0 0 13px 3px #00000033;cursor:pointer;color:navy;background:linear-gradient(45deg,#fff,#dbdbdb)}.let-rock{border:2px solid #ff0020;border-radius:10px;font-style:normal;padding:3px 0;margin:5px auto 5px;width:auto;display:block;font-weight:600;font-family:roboto,sans-serif;height:200px;overflow-y:scroll}.let-rock .t-rock{cursor:pointer;text-transform:uppercase;color:#0013a5;text-shadow:1px 1px 2px #fff;font-weight:800;font-size:17px;padding:4px 0 3px;border-top:1.5px solid #e0557f;margin-top:8px;font-style:italic;font-weight:700}.let-rock p{padding:0 10px;font-size:14px;margin-bottom:0;color:#000;padding-bottom:0}.let-rock a{color:#e91e63}.let-rock i{margin:5px 0;display:block;padding:0 10px;font-size:14px;margin-bottom:7px;color:#000;padding-bottom:0;text-shadow:1px 1px #f4e1e1}.let-rock ul{text-align:left;padding:0 10px;list-style:none;font-size:13px;margin-bottom:0;margin:0 10px 0;color:#000;text-shadow:1px 1px #f4e1e1;border:1px solid #e91e63;border-radius:5px;margin-bottom:12px}.let-rock li{margin:7px 0}.t-0{margin-top:0!important;border-top:0!important}@keyframes changeBackgroundColor{0%{background-color:#ff019e}25%{background-color:#ff001d}50%{background-color:#009a07}75%{background-color:#001fad}100%{background-color:#ff019e}}

.red-list-bg-change{
  animation: changeBackgroundColor 5s infinite;
  border-radius: 10px;
  color: #fff;
  line-height: 1.1;
  padding: 4px 10px 3px;
  text-shadow: 1px 1px 2px #000;
  font-size: 24px;
}

.red-list-bg-change h3{
  font-size: 22px;
}

.red-list-bg-change a{
  color:white; 
}

.form-group label {
  text-align: left !important;
  display: block;
  color: #373737;
  font-size: 15px;
}

.form-group {
  padding: 0px 9px;
}

.address div {
  text-align: left;
  font-size: 12px;
}
.address {
  margin-top: 34px;
  padding-left: 79px;
}

.conta h4 {
  background: #ff00a2;
  padding: 5px 10px;
    padding-top: 5px;
  padding-top: 5px;
  text-shadow: 1px 1px 2px #000;
  display: block;
  color: #fff8f8 !important;
  margin-bottom: 20px;
  letter-spacing: 1px;
  font-weight: 700;
  border: 2px solid #fff;
  border-radius: .75em;
  transform-style: preserve-3d;
  transition: transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1);
}

.conta h4::before {
  position: absolute;
  content: "";
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: #ff182c;
  border-radius: inherit;
  transform: translate3d(0,.75em,-1em);
  transition: transform 150ms cubic-bezier(0,0,.58,1),box-shadow 150ms cubic-bezier(0,0,.58,1);
}
</style>
</head>
<body>
<style>.B1{background-color:#FFCC99;color:black;border-width:3px;border-color:#FF006C;border-style:solid;border-top-left-radius:10px;border-top-right-radius:2px;border-bottom-left-radius:2px;margin-top:1px;margin-bottom:1px;font-weight:bold;font-size:x-large;font-style:none;text-shadow:1px 1px navy;padding-top:1px;padding-bottom:1px;padding-left:2px;padding-right:2px;}
.button2 {
  background-color: #fff0; /* Green */
  border: none;
  color: navy;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  border-radius:5px;
  border: lime 2px solid;
font-weight: 800;
text-shadow: 1px 1px aqua;
cursor: pointer;
}

.button2 {
  box-shadow: 0 8px 10px 0 rgba(0,0,0,0.2), 0 6px 8px 0 rgba(0,0,0,0.19);
}

</style>
<div class="B1" align="center" style="box-shadow: 0 8px 0px -3px #ff9628;">
<a href="https://spboss.in/">
<img src=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkgAAACSCAYAAAC+JDXPAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAALNNJREFUeJztnQuQXcWZ3xtsnsaAMcYUZvGYsDZhgcWUVsXykGeBZVmiJZiwlEzAUQixWUdxFIqiKEKxE4LlmTsUhQnLqjAhUxizKpeCCSsDy1JIGDAPiVdkjLEAScYg3XsQj+VpcJXy/XXOXa6v76O/73SfPlf6/6r+hTEzp7/umTn93e7v4RwhhBBCCCGEEEIIIaTGtNz0ji3XODhzjRMzNz1fNCFaLLpedLvori7dVvz3q0QXiebJ9x8hz9kt9VwIIYQQQkxkW5yh6QWiGdGTol+LNgfSc6I7RJeJ0zSHThMhhBBCaknTNXYQp+hfirPyVXFclohWi94O6BT10geiF0QPii4VZ+lYsWPX1GtBCCGEkG0ccYgOLJwinOhsjOwQDdO7okdEDdEfwWlLvT6EEEII2YYQB+Rw0Q2i9Ymdon56VfQ9cd5OQfxT6vUihBBCyFZM5hq7i+PxTdGaGjhBPspEC1KvGyGEEEK2Qta5ie3F0Zgner4GTo9F92x0kzunXkdCCCGEbCW03PRRWR7bk9rJKatlov1SrychhBBCRhxxKC6tgWMTUrxuI4QQQoiNjW5yx5abvlAcijdq4NSE1HWp15YQQgghI0jLNQ4SR+KHNXBmYmhZ6vUlhBBCyIhROEf318CRiaUbUq8xIYQQQkaIpmvskeV90FI7MTF1Zep1JoQQQsiIgBR4cR6urYEDE1sLU681IYQQQkYEcRyW1sB5qUJzU681IYQQQkYAcRrOr4HjUoVQVXt26vUmhBBCSM1pucae4jQ8WwPnpQrdnbnG76Vec0IIIYTUHHEarqvYSXlX9IxoeZbHPKEQ5cIsb2MiaiyQf14sukb0I9FKUTPE2OIMLnrJfYuNawkhhBDSH3EazhD9ugKn6H3RKjg+4qQc23RT+/ra2HLTu8n3HSI6uXCoVlttlmedHHM9CSGEEDLiZK7xKXEaflqBc/SOOEWXiD4Zwm55zt7yzLmZoZBl0zV2DWEDIYQQQrZSxGE4uwLn6B5xxA6JOIcjRbeIXvOxJZYdhBBCCNkKKK6tVsZ0jmSMmYrng7ilNwfYdFpV9hBCCCFkBBFn4SRrHI+nbk4xr2Z+/Xa1aFOXPStS2EMIIYSQEUIchkZE5+hXLdc4MN3cGrvL+H8hdtyR5eULVrfc9NGp7CGEEELICNB0jU+I0/BkJOeoJRpPPUcg89xBnKX9RHuntoUQQgghNUccmONE70VykP625aY/knqOhBBCCCEqsnhtRd4RfSn1/AghhBBC1IgTsySSg/R0yzX2ST0/QgghhBAVG90k+q49FMlBWpp6ftsSL7tvIxh9XNb9ItGVWH/RXVlesRwFQO8p/n1J8d8XtNzUofI7sHNq2wkhhJBagTYfslE+H8lBujj1/Kqg5aZ3bG1pfdI4Mcv7x10omugS/r95WG/52r1Cjd10jVlZXsbg0cxepgG98G6HfU0GsBNCCCFbrtfOEr0SyUGal3p+MRFn53Pi7Exng4tR9hMcmjkb3eT2+nGn95CxzyhOg0L/zDa1tjhy02zgSwghZNsly6tNf0AHSYc4EKfJ/J4ouT7rRQf7jilfi6KX54geyOJlHUI4ibpVnLCDxYH7aMx1JIQQQmqJbIRXRNxoz0o9v1jI3NYGWqPxYWPhSi7Lr+hWi96P+PPq1gbRX4s+VsGSEkIIIfVBNr/r4m2wjQtSzy8GhcMSYo1eF31x0FhN1zhAvuapCp2ibr0v8/0fVa0tIYQQUgtkA1wccXPdKrPYimDsEOvzdMtN9SyDgMyylmtcLl+TJXSO2npXnKTzq15nQgghJBmRHaS1srGOpZ5jaLL8uivE+tzfK8ZHHKOxLE/JT+0Ydept0ddSrDchhBBSObLpTUbeWC9NPcfQZOEKa17Z/Wxxjk7K8tif1A5RT4l9p6VYc0IIIaRSsrxGT8xN9Veiw1PPMyQyn5+FcTamz+18Lv49tQPkoadZAoAQQshWT5Zvyq9H3lR/3nRT+6eeawjgHGT2goydQjbalzqee6b8+xs1cIB8HLv5CX8EhBBCSHxkw5sjeqGCjfVh2Vj3TT3fsmSuMTvQevxS1uNf4Jnyz+NHxTkq9HzTNXZN/bPYRtlJtJtoD9F+hXYrtFNCu0Kyi8vn8ynR/u7D+dUZnKrCRlTJh817Fv/+kZRGEUJKIJsz0sgfr+jkYcVGN1n3F91AsnDXYI+jIrasB0oGNGvg9Gh/lqen/llsI2DDPUPUEC0X/US0UvS46NlCKwvhv/296LLie4K1tIkMnIvj3YdzfNjl8/mpaI37cH74b9eJvuxyJyolsPkI0X9z+Zo/6HIbn3K5zU8U//5j0Q0iJDiMys+DENJGNrzbKtxcn8hc45DUc7aS5U1eQ6wD1nwf0dOpnR2jlrZco2eJAgOoJj4pWhxI1xXPm3C5o3Ckyz/RjwI4fUBs2hLRL0SbS+pJl68JqtrX6cMJfuZw5FaI3nT2uV0tmlWRzehTiHIXd5W0eUY0VzSKTaLPc/nv5irRz0XrXT6vN4t/h1N7m+gKUdn3w47FeNe64X/zSHjBh7YqTrbhGC8SoYzNAy6fd1tw7jF/vIP+rAJbSGxko1tY8eaKlPErRvGaJsvbfJReg5abvkz+eX0NHJ0yOqPkcuLnD0emrBPgK5y24MWFl26dnAXYgo0Xm07M+WMTw2ZyYjXT+h0wzwtFDw2w0arnRMiY3T2wzdikz4xkM5yLq1zuFNcd/Oy0f6vXlhhvvug15XjQapc7MLE4WGHLqoh2kKqQje7ILE0MzEOio1LPX0Nma0zbS9cUjmJqJ6eMbi65nHAKqnKOejkLeOHvXXIOZUB2JxwWy0ZQVjgFGYs+ww+BU5oFnkMvPSMK9U6BzY9VYDN+F88OZHMscOqP0yHNvC40jnWys5/QtXWocexhLFTYQAdpawBxQbLZPZhok0UG3VVo35F6HYYhNh4RaM7viF6qgYNTVk/ImlivrhC8iviMqh2Dbm0Q/UfRDsZ5WED8zALR6wHnYdEm0RyXn5LE4guieyue1yOunOOLU6iZim3eXNLm2Jzk9POZaxhne5dfUZVdyyWGsX24UWHD30aygVSNbHYXJd5s0W/sTNlwUwdf9iVzjYtr4JR0613RetGaQvjfVTW0fUV0mHE5P+PCxNiE0Fuiy101gb+43kKcwnsVzm+QcKqDXnsx5g7na3WCOcHptRY0Rabt3Qls3lzC5irQnJxAr4r+0DAO1v8Z5Vi99LboAMP4w3hYYcNXIoxPUoCUc9nsfpl4s0d9oXtbrvFlcUZqlbIs6/MRse0fauAQQSi++XeiBaKjZK0OFO1fSP739AmtvB3Ks7FtKZHNhsDassfoIQWH5WIX7zQF8VaX1mzOnXNHUG3IvzmcHrQDeKvWRpcH7Fpsjh0HNkh1zgy9yenmAifHUtYl5HvhEsP4g8C74V3Psd93eXII2RpY5ya2k83u2zXY/CFcQX1PHKUjevUqS4HYI87HlhOalOvyAn5Gsi5fgMPmYfN+oqWRbZowLulZLr1j0K1XXB4XFRqclv2gBvMbpHdEXw80X8TupHKOIATjazPbjk1s82aDzVWBAG2ULNDMBadwlhpQId8LKw3jD+IIxdhIGtgv8PgkJbLxIlh7Uw0cpLZQEuC81OsCxBYUiEwZVP2ArMUccWS319iN4pzyvS9GtGupcUlxYpFyM+qnNcb59AOpzktrMC8fPe3KB7ciI2tD4nk85nSZYYg5uiOxzZuVNlcJrqqed7q5WDPYQr8XQpb3OEMxLuLganULQgIgG978GjhGv+MctNxUrKwEL8R5PCPV/MXJubik7SdmeWxSDPseNPZmW+bSb0j9NG6YTy9wxaCJWaiDHig55xUBbPi1yz+Bt2vLaLPfblPaPBHAZmhdh83a06jXlDZXCbICfa+W2rJ+sA39Xgj1ARvvuCsV41o/OJK6Ixve1TVwinrp+qabSnJsKWNPJpjvilagMgjynCsi2bg6cw1t9g2+Xhu8i4KAEwOEwm0zLj8FKftSvVI5n14gKzNU9hZOZJYU80QRyXkdWljYu8LlgakhxjvZOOf5JcbEyR2uN1Fnpte1Oq55EPSN4pJPDXnWQoXNuNbaZLQZ34fgfly99Cr6iE11tsvT3e8Z8iytU1clcDI06wJnz/Lews8+dFD/MoMdvcAp2rCfYacWBBqX1I0i7X9DDRyiXsJJyOwq1wPxWXBWKp7nKnFqPhNqDvK8o7MwTXa79bw4SNpskT9w8Nl0LzrNKdUfu9yh+LVyjLbuUc6nGwRk/41x7Lbwif1Rlx/r+4L+bHAkXyk59h2GOSPexOqcLjaMhdYkqOXU/TNGwPkfez4H19X3lbBZG4R8RGHzqz2ed4HyWVWCYpaatUH5js8ZxkFBTu17wUchisLCkdZcHZ8UYExSV2RzHs/q20AVMTXntVyjkvYRTTe5Z7YlHqqy+a2W9Q8asIm2IFmctiboI6dtHYOXx2+c/8vmWcOU4VB9w+mvBqCfGsbrBCc6bxnGhbAuuOY6VfQxw9hwHo5x+qyjTmHNtKeC5xjG+SfRf3H2lhtwRLFOnfW0EBzsu25zDDZDV5W0GQ7c910eGI/n4cQlVNue0OD3SVv2AM6jxSmZcLr3gq9COJ/zFOPhfWUtf0JGBdmkz8y2XKEkd4h6CfV/VrQq6Osm4xyW5TV/qpjXqtDOEdjoJreXZ98ZwV4U+vyi0pzvON0L7sYSU79BORb08xLjoZaN9eSqKfrPok+WGL8NHMSrjXZA5yrG+oTLe4xpno+NEGUPQnS7R5A1UvRxzXq44vssTiRO10KUgkAA7wkud7YsBRWrwlKXSPO700msQHk0Di77YVrTZmUmwHhkFMBmXWMnCXoJQchx16Axt6K5PBryWq2bLFyj3W6NK01BAK7mBVcm9X62cqwyDhJOXawZXIjBCV03Bacc1k1HU4n4OKcvfPkz0afLTK4kiHN6o4ddw6RxwLYG8OFHW/Hd2gvN92/nPaf7fcPPuUxYhvYUDUk125UYj4wSsgGentUr/b9ba8WxOCje/BsLKprHsbHmkM9jOlYl8HGFGTh6125KZRzgvQ3jWa/YLjaMBaEwXqyehCcbbdKswXzD88v28SvLmNPb/GIKQxOD0y3tOlmu1zTvBZxWrlHaVOZDljapxJrkQEaVlmvgJGlVDZyhfnoRV4Ix5p7FL7ZYOpXfB/kZnl0DBwnOThUv3DYWh8ySUYSrXmsF4NgtJm432uUbZ2O5ytMEn8fgNKe3uUx3+lEF16CaNbJ+uNC8F65x+n5tCI63Fh3GqaEm07HOPfVITIoWFqmdoX56Q+wLmj3wslu0qzz3kch2l82a8kLGmVcDBwkpz5oX23Mlpz2mHA/SpvlbyhZAOPqvov/WuLPFRfnWHltuePZ42UmVZMLpbZ5IYGdqtI6I9WRQ815ACr2maCOE+D5rvKrmFC0zjkG2FlqucbJsilkNHKJeWtN0U2Oh5pq5xpg8c21Ee9/JKgg0z+dSCwdpxulebGXrw1iumE5VjnG+YQyLI2ZlTLTWYN+4x7MRn9GZRTYqDtIiRwdpGCgb8bjTrZH1JHxGMQZ61qG5sjZD9WyjbZcpxrjdOAbZmiiCt3+Yb/DJnaJu3RCqBIA86zjR+5HsfE9UWf2TSA7SW6I/UpihzXaaKDnty5Xj4aWr+d3B1z6oHANCKnC0uLkukPb+qMHGeR7PtvTpKrNZhWKx09t8QxJL04HfT8RdadbIGn/j+15AE9hjiu9ZobTtFpfXvtKyRDFGVR96SN3JXGMncUS+nFVbI8hHKAFwXYg5yvxitl5ZJo7mLiHs9CGSg4STRN+rGKRHa696ylxBYbxnleNpWwRY0vqR4v6f7NMycafSRl8HCb+/lnYqsMdaSygE1/Sxa5BQr2hbSt/+U9EHTrdG2uKZQPNeWOc+LEKpOdmBXhB9Vmnbx0WrFGOcpXw+2dpp5V3jL8q2VFVO7hy19Ws0dy07N3nO9ZHse1V0zHALwiHjLYwwDxTt9D0JsaTcl2ktc65yLNR70WQS4sVucTxw4vKpEvOycL3BTh8HCSw3PBsndSjkaflEH4KJIfb104yzB/uOGpraP9B64zia9wL+dnYzfB+EDyb/Xmkb2p9oSneMKZ9PthXEUTpWNstnauActaWp5fI7rHMTH5Vn3BfJtjuarrFrqLX3IYuT5r9GHFHfLuS4VtG80DaVmC5OJ7QF7q5QjvF50UvKMaAUfZosV0q+DtJSw7MhXN9Ya+aUZYGnjb1URWB9HdD2ErQmm2jeC8s7vm9npX2bizlpONrpToi3FeeZWClOKmJ1j1dJnJCDrfNoualDszjtOd4WHR9yzX3I4jQhfqLpH++l6YYN3WKcKo75b1aOhSw0bXruQuUY0JPGOZUlpoOkzUzsVpkaNVZmlbC3bfPulVtdHZbyGNb4G817oXuMuwx2avYETQLGw4rnkm0ZnI7I5okCi6kLTM5Y51DY/3YEm+7Y6CYrj7/I4tRzul/m4vupCT3GNC+y0w3THHf6kyOkAGsr7cKZekQ5DnSeYU4hiOkg4VrS0vOuU8hWtMSvWMHv7GslbX7M5ScMWyP4mWrXw1rbSvNemN/1vZaTwEsVtmlaFW2LdbJIGTa6KTRJvUL0WionSZw1U+GulmtcG8meA0Kv8/C5TO8oYz8YYT6aoGZNIUVN3RJsdog3m3H6gOnVxfdqOV85n83F16cK8rVcg417PtuaydYtOCy45qyqcavFaewWHEMkhJhPqmuK5XTUmpXp+3eEte6uOL+/wU7fYpaIMdRkqKa4OiejDjK1ZCM9I0sWn9SwnETgxOXuCPY8FHp9fWi5qb1k7KcizMf3WB3B1pqXWMvljVvnDRBOY7Chot8YMlS0ncARPwTnaAfDkloanWrjH0KyfIBd/aRpmvxXhuf3Enps4doECQwhGtkO4qSANsPRRiX/EI1s64DWeYTzYpn7FxRjvFx8fScI8l+rtBUfonxOK9EX8xeK526tp4mkClqusa9sqDNZ9bWTZppuSvXJfZ2b2D6LcL0mzuL8SMs7EBn7oCzPOAu9tr7xI5bWDjGFTdhaoBMnVpbg7G8YxyuLNRVfk0EIZ2a5YYx+ekX0fRe+gW8n2FxnAtqMjff2wuadItpdBdrfF2v8jaZ/IdLtP97jGZaSDT7vLXxA0JwSl2mJRAiu3CaRGfYXWbWnSWhmq8qWabrJsQh2vCvzT3LFImN/KQtf8PI3ohM8TZhw1Tg+g4RP+si0wcuxzMvsCOP4B5YYswy4snra08ZOaTNysC5l43q6hUxGbKKxAqJxkvBQBJu/69L9vMuCkyBtTNliwzhwqv9BMUa/rOQ5Slshn9Pcryue96zvpAkZijgsp8rm2qzQSZqrsU++/uQINqyKtZ7DaLlGjCKRiCvzdTw11WhjCJtWqPgWS2uRlD2aLBWRrfZqMxV9hefG+oSOq7G3I9i8zI1mXRz8vmjmCWdqoWEcbQ/DfmU4kPCiaSYLvemGFyq9RfE8bYFZQgYjTtKcCp0kTeYCHKQrItgwGWstPeZzZYT5PN1yU74OB5rOxnJ+fIXsNvTgGjcvZM61hrFL1eQqCQJbtScCK0qMN2MYz0dw2mLVIDo/os3nRrI5FtpGsM87XYHVNoc7nWMz6EPupUqbN7vhWXca27Q11AgZTuYaCN7eUIGDpOqjlEVJiW+MR1rGgYgjulsWJ4PtPsRqeZiwl4vn9Fi1wtkzjzStB9qyfMIOxTcG2NVPV5ccEwH02iw/H8GJiVU3CTZrqiZrNBPJ5hhoTwGR6WU53ZurGAMfsA4f8CzEEzaVdg/60HKo4jk4nbX2oCNkMLLRjlfgIC1X2pSFtiFF7aN8Lg2s79oIa+p7IvY1F2fTKSts4DiR0MbaWMayfMIOhaWYXoiUZRRD1fbC8xGcpIkA9vUCaeMrItgMzUSyOTSI09PMy1r/5wrFGHBmBpVrwd+w9vccf//9HLv5iuc8MsQ2QuxErNHTqRXr3MR2Pva85L61W4Tx18Rex37I2JdkW3rTBZ+Tb2NGTbG1qoVPf5oCd/sax6myCGInCLi1nOSESFlGEO6fuLDZbZ2bW6zrtjGXF64MbfO7hc11LwWAnmqaeVlPRzVxiRNueNkHbfNa6Jw+z5pQPANlRlL1FCTbAi3XODWyg/SIb++zzDWOjjB+shgUGfveCPN5VnSYx/DabtgphBgK35R/S8bM657PjoHFXmzkIU878Skd11drDbYMEuJ7yjQzHsTOhc2o8qytrzXM5jr3ctN+APjA5SeFWrTvBZ81QzX8N5T2I5ut1+/6MsUzLlHMmxA9uH7K4rT1aGslYnF8bMniNHVN8keEsgIy9rsR5nO9OJK9apJ0o+2G/b7o/7g8bXiYkDlyv8uDr99RjNFLNzq/q7ZzDc++3eO5sbh8gF39tCKSLWMuX+dfGmzqJ0t6uYZPunwDDGnzT0SfiGy3lVOcbi44gbVU0Na+F3wcYbzfNZWvIQRi98rE1ZyiqTKkCTEhm+7DER2kh3xjgCK1GEkSxNeKU64A8g2U1XbDRgHGzyumiJ8pXnAXuHL1bHAFur/HeBOGZ6fs0aSNJ4HKBmgPAk4oNpSnDHb1Ek5kYhfo276w2RLL1UsoKVB5s2pPtI2H8XPcyzCO5r3wpuK5lgzTs7ueoWnUi5+lto8jIXpk010S0UFarrAjuKP2sluUJIhPxr4hxno23ZSPMwG0NYPQANRaFBAb2XynP2ZvyycWyfICTlVBe2+FjZ0ar8A2XHd/04UpLBkrq60X+KCzNoDNKcs+9AO/L9p6ZbcZx9K8Fx5QPBeOp7YfI054O2OINIVgUYC1qt6BZFtGNt7FER0krz/kdW5ixwhjr4+9dr0o0vvfjDAf32aPQBugfVOAqeMToWXj9TnpmTE819QLMACWTudYN21WXxlw+lA2iP+eCu0FuxU2lyljgLi3yptWDwFp9Np6Zar6ch1ofua+/R6BtvgkhPdzZ9Vzzd8NA7RJNWRxT5C8rg1abur40GO3XOPy2GvXCxn7vEhr6ftS1HbDhk4NMHWMaykcd58b7hxYrlnGA8zJwpOe9nVKVS8sIBZnri3NFUxIcFqhrb3TFk456tbcVFOXqC1L/I32vdB9BTYMSzZb5+mxpg4UC0SSapCN956IDtJFnjZ8O/C4vxEH6V/HXrs+c7kjxlrKfOZ4mqDthr25+J4QzFaOC/nUMxkVBwlxXNqrhpZoXgJbAa7cNK0dupXiNGYHl8e+vWewt3tTrgN4R2rsR3bmFw3jaN8L2hgfS6/Eqzq+X1PiwbfUCSHlkM13fSwHSTb1oWmiL7lvxajHtCFzDWvFZjMtN314Fqf20YtoOOxpBoojajbpkLWidlSM29ZKN7xe0Sg4SMguvNpgJ64LvEphRALXbY/2sMtH/yqBvWAX0fc9bezWBQnsHYQ2/gjZo5b6XrOc//Uk3h+WulErlXPB793Hiu993vN73izmQkhcxIHZP5ZzJFrb8miqKo7M78nXPhd47FWe6fDBkDE/kUUKzpZ11MQDzHe6l9StIddBOXZMB+mEgHPy4ctOH6j+fvF9qcHppCXIPuVpDK7KtM2AoYtTGNsHS72yu93w4o29OEsxxpPG+VyinMuroj90+QcE3+/BKVioE29C+iOb71cjOki3Nl3j0x42HCN6P/TYVaxfJ+LEfCWLVFNK1lFz3K09xVgUcBk0qbpt/dgN/7RqcZC+Gm5aQ8GJhiW1H4GtdWiXgL/Tn7nRcpBg86197BoVB+n3Rb9yOvuv6vmk4TQUY8wYxzhEMUbn36nmeg7vC4uDSIgO2Xxvi+UgicNwoU9T1VbeODfw+I1Kg/hkvN1l3B9HWsunFaZgvRH0nGqTO1g5NrTU47kWB8m3Z10IcJVs6UpvzUYKDRxb7fUIlLKuEGxe3MeuQQrR7y4U2npl0HnGsTRVqi80jgG0p3o3O12geqqEBrIt0XJTh8ZyjnIHyS8GSL52MsL4lRYJlPEWRlrHt2UdNZsQaoPAodK8oCwVefthyYry+UR/s+G5VZV5QLVhS3NY3yKZVbCn6Amnn0OqXncANs/0sGmY6tRyRFuvDOUgjjKMg3exJg3/ROuEnP4EGzFVmgDtKutvkRAggFY2swnRT7Mt8S/TF/q22EiB2DcmWhHRQfKq2YMTJvna+yKM/6Y4FpXUwZFxEJjdjLSO9/r2sivAVRyqzGpeuKEYc/qO7Pj07OMAalKAOzVWfloDwc/mB0bbynxKDw2cZO0n/yyJpR8Cmx92OpvrVoFZW4sKxRsP7PmkwSBlf5NinDJ71yzFOFrVsUwDGYZsZCeJ3uj85C/6gejPZIPbIbV9ncAesWtRFifbqi2v+kfNvGfZE5FseEGcl7GYaylO8C6i70Zcx28qTdLWVHk42GI49++czjmDuovF9UObCt3W14LMrDfIKvyvorcMdqGXnaa1S2zQCwwB45o53JvE0g/5U6f/fXtB9NkUxvYAcTTauLXrXR7YrWXC+Tf/fc44nzZoQ2Stqj9M6CNXeXYyKUHmGtjk7++zwb0l+p+yUVu8/uBsdJM4sfkPhV2xNnXEHx3qY4987WGiVyLa8oDYYulZNBSc7LTy+k3vRbL9eZG2zow2iyRU09Exp6+kCyFV2yfgco7h2RB6VsVIoYdzZD3Vwqbue02CtUEQd8wyAHg2Ws1o5zEofgo27xHP5C21kL6ntBe60+kqlmMeqDk07vJiqvOK/z3blQ+ut9Qrs14v3aEY4zvGMTq5STGeRsj4qzQ7mZREnJ9Ts+GnMWtFDdlQQ8Z7KO2c3lFsPT/77ZOuGPpHf5sacyPbAt0R2kkqrlSviWy3NoAXAdqaFyF0boDlQBzKncpxoXdcfgrgA478LUHQUMgsvbYtlnpHbTUUY33d5Y4nimkimN5Sm2YYi5xtHv0+yc8qbH7c5fFlMT6goDSC5eTO18FALB+C/DGP13s85+3iv2HtrHFkmrpEbVmvBzd4Ph+nTCcZx+jEUh3cRwzQHjVkI7tRsem9KJt1kiyKzDWuziKloXfKpzhkh00XVOAgQUGbVMrP8PLI9v5K1ub3lWYhWFhbU6VsPAachR8qx2zrJ6KdFGNp403agmN1sn2Kv8UXnC21vC1cKfrGd8DxfKZrHtggQtaAme1sjucTA57ZGXD7gcuvkULajGf9P4PNmuuZexXP/TvjPE43zMHiIO+leD6quv+BcT6d7KwYU6NzAthGqgIxLpkthgad6y9uusko1z9dNh4hYz1QkSOiqsosX7+0Iru2rDnWosxaitOyN0oIVGCrJUUdToA20LZMMCYCP9cox2sLn5zPVI5n6fPWFoLRcZphnS82JsQzZSVsgDQ9tE7r8wwE22ItdjfOpc24szUXhvqdxOw5wGY4d2Wz9mCzteo3WqoMKzuCn/N1yuf6xtF1c4VyHGts0ImKMULW5bpKMa6vou+XJCCykS3Iyp3KoOv7kpabPjNk1hviY+S5uL6K2Yi2W8jk8q6p87JbBBsfqdC+9npfjrpFmvVEtp04V2dmW1qYRLfxnpY+9ghoX7hemYYd4OWEjDNkX61VjtUtnKJqPw3vX3JMCO0MEKflu6HhGgRXYpY0/k4haFVboHBYjR8880aXO8a+cTX4ZI+TC0tdqbbWDBhvnsf3o+4V3hN7etoMELOlbcnRbfORnuNor72smVWaukSbi/lbuFAxxjLjGL3AeocM1i4bPE6qRjazmwNv3ijcuEA24/Gmm/L2lmUD/2hR1+hc0U1Z/DijXlqoXLuDRC8msLMtOI9nbHSTfV/U6OcmX3NhVqEjh5+jZh07wMajeeFgI/i5p7TZQoN0m3F+oMwm2S2cBuH6Z3GX4HSscPbTlW7hCkvbGV3beR22Yl0RG4WMv3kdgjOKgHL8foTYsMYH2KwJXMe6rChsnuiyGbFxiwqbLe1EfG3uxhp47/v8Njil0SY1WMtCaP5mQhbYhTP+kGLsYQoaJkEqQDa0xyNskjiRWpvl13AoFbBYdDEkjtPZ8s958s/ziv/vsizv/4VaQk+LXk/kbKzWptTL9xyXhW8xohVOvR4S/Uh0ZXuds7x4Ja7/VoveqdCeZT7Vx/tQ9pSjCmGzK5Omi2w236aWdRBicOB0aU+HLRlObSFdP+tQKOcWz/0b1//kDzZrkwQ61Wlzr8Boq24fYHMniIfTxB51rssxHs/vBH8DvoHTbVkLXD6pGOMs4xj9sDqcvTQR2DYSE2SFZXFrCY2KUJTxVP36NebXwPY6aVOJuk2WHmhV6yVnqwLczV+J3qvBfIYJNk45W9wTYuVCnWCF0v9yH3Ze72fz2hrY2SmUedhn4Ep/yJjRfvxea2taIVPMty5RW/spxwBwDH1bmeBEeZZhjEEcrxh/mOpUAZ0MA7V+arCpphZOu/4aae/a9ZPvu74G9tdJ2muYThADkXoz6id8wkbm1+El5tcJGsN+twbzGiScDpxT2GphvAZz6BTKOAxzNOpmM1ruHDLE5k5wCqQtlgmhnIG25tN3lGNsUD6/zWzFGDixDJltCCxXif1kcRBJKmRDO60Gm2pStfIrvkGfKnuyzk3g9C1Wc9dR1J0lrtaAtdJ0FcK1jPp3ZAhIgdf2nKtK2MzKOoPjNZhHW4gD8slsqpPNCEL3PTlqY0m7h25VjgO0ToO1avm5ijF+7PyKtmrRtlPppU0R7CIxyeI1KB0VPYTgcMvaFQHlT9dgDnXQPQFaoqA5b+pNqddLDS9o0++IBwhmt9TDiSUEHWNjDtGAFll262swJ03QLmx+oAY2I1jdkqruk4HXS9rq1pbr8CsN83FOFwMUqwjjGQob+umBSLaRWGRxutCPih7a6CZ3LrF2ZcsjbC1a03LTITbUMmnboYVA7PMCzMmXyUjz0Gi5CxNf1QlONDQNRkNqjXE+Bzl7bawQNpdxyC0OkiX+SFOXqC3r9bvGYbW2MRkGsrGfUtjRS3Vq7Ex8yPKsp9Qb7Mg5R6DlGtfWYB6ptaFs4coOtDVVQgtO0TVOVwgxJAguRaXtUAGhvkKGFOoQlbkeHcSYy09xtLV5rEJpATgKZU79di5srsq5w+/e+SVtBpbWH9raVkBTl6gta+an73ystZx8QSyYNekAjm+wGoGkIrI8HTz1Jlul3mu56f8eaO1W1GA+KdWUtfw3IdayACc2VToG7V5Uf+/i9QizgN5u2ORjZbkh86jp8rgcSzFPKwcUY8bIbMPVIAKNkR0YMgYFgcvI4otxVYjyCYhBQ9XrUL97CKjXnMRa6/JoU9+bxnE0LUZwVR06QLsbVKLXlpzACVjZdkgkBfLp/+gabLRV6Z+yLXWYpq1ZOf8MgpGzbft6Dc7RnKZr7BDi97AAn55xDH+9y697Qupml9fymXC5I4ZTohDdzGOBjflPRJeJ7nd53SRro1sIQddwIGZEf+nyT8Ox4qoGgTFx4jhf9H2XO6ivOP18kKm11uVF/HDSc6zTZ2H5gpO1AwubESe30uUbvuXn8GJhM34X8TuoDcL2ASc16K2GU4vu3xk4x+hV9pgr14QX2Viozo4ipU8VY3UK2WT4fbvb5VXfywT842TtvmKcX3SN80Tx39C2xqfKeAiQ9o/fA7xXcOK7sofQmBmOKgoPM3NtVCk2+ttF79Vg040pFFL8c9nUg3y6bLrJsQg2olBmswZrNUxrxLGu6mVEcqcCpy+Ip8FJ1wUur9yMTbaXM/gD99vO4LjLN81YDoSV7VzuoB7mcmcBmwk2npvc784JQcvtOcGJPs7lV3elrsmN4KoEDibqAGHzxmlKL5tRVgDO/kTxdYjbQXxTVTYjLvCoYlxcOZ7i8nVDI9eyPfDa4H26VzFWp3CSs4cLd5q3fTHOZ7rG2dPFuxr2AR+2d+uhXV3++01GHXEa9pJN73/XYOONpUnMMeSaZXHKI1wujsfJNVivQVofKCCbEEIIqT9FY1h0eN+aro3WZIrGsxqKtQpt75bg4MJJquNJ0vWZa9A5IoQQsu3RctOzsrwvWurNuIyeknnMtdY38iHLe5wFtbvppv7Z+RAn6agsbRPcTm0Qx4gl8gkhhJBm3gF+1Byl28UxOsXSMkSLjJUFtj3rMcY+opmE64k5Lgx9PUkIIYSMPOIoHSCb5OWi50W/qYET1K03REthZ1VrstFN7RNhHnf3G0/+26lZtadJaF58V5VrSgghhIwc69zEdq3cUfpL0Y2ip7J0sUpw0taJftRy0+fKP4+s4sSoE1mL8QjzumbwmNMHZfmJ3posnqMKJ2yxjHUqYtKqWk9CCCFkq0AcBGS9zZZ/oo8broBWZVviVKJs3K9neb+zO1pbahg1ThB9rmqnqBOx5ZII8/yqz9gy9/3la/8tHETRC1l+2mMd813RM6L/C2cTTpisa8qUWUIIIWTrIXONj2d5zNJxrbz5LQKY1xs3bfm+xg/lOZfK//5z0Rdbbmqfkl3igyI23RTaQZL5qiqtwkGU7/ksTrNEVynW+/Xi54P1ParppvaNtU6EEEII6UG+iTf2EQfnoGxLVlZPzZaN/gDRyGzUxYlZaAepdJ8eecaOorFe69x0jYMYbE0IIYSQKKDBbQTn6N7U8yKEEEIIMdNyjVmhHSTRRannRQghhBBiJssz50I6Rx+Ijk09L0IIIYQQE003tYs4M9cEdpBeRPZY6rkRQgghhJhoucaYODQrAjtIK0MEaBNCCCGEJEGcmS9l4QtkLkk9L0IIIYQQMy03fXb4AO3GFannRQghhBBiRhyaKyNksM1NPS9CCCGEEBMoeinOzP2BnaNNosNTz40QQgghxETTNT4tzszPAjtIz2SuMTIVxAkhhBBCfguc9BQnPiEdpHtabvojqedGCCGEEGJCHJnTI8QfXZt6XoQQQgghZsSZmQjtILVcY37qeRFCCCGEmBGHZmkEB+nE1PMihBBCCDHRdFO7i0PzWGAH6cWMLUYIIYQQMqqII/N50UuBHaRHXnaLdk09N0IIIYQQE+LMnBghQPtHqedFCCGEEGKm5abPj+AgXZJ6XoQQQgghZsSZuSFCgPZpqedFCCGEEGKi6ab2Eofm4cAO0pqMLUYIIYQQMqq0XGOWODPPBnaQlslz90s9N0IIIYQQE+LMLBC9HdhBmkTz29RzI4QQQggxESP+SDQ39bwIIYQQQsyIM7MqtIPUdFP7p54XIYQQQogZcWg2BXaQMl6vEUIIIWSkEYfmFtF7oZyjlptmej8hhBBCRhtxaJDm/xXRnaLnlCdKr2V5Sv8/ii4VHZp6PoQQQgghwdjoJndoucYh4jCdIo7O1zwlX9s4DN+b2n5CCCGEEEIIIYQQQgghhBBCCCGEEFI7/j/SXNO5jJTNlAAAAABJRU5ErkJggg==" alt="logo of spboss.in" height="73" width="292">
</a></div>
<div class="ftr-sm" style="font-size: 12px;text-align: left;font-size: 12px;
text-align: left;
font-style: normal;
font-weight: lighter;
padding: 5px 25px;">
<div data-custom-class="body">
<div>
<strong>
<span style="font-size: 26px;">
<span data-custom-class="title">
<h1>PRIVACY NOTICE</h1>
</span>
</span>
</strong>
</div>
<div><br></div>
<div>
<span>
<strong>
<span style="font-size: 15px;">
<span data-custom-class="subtitle">
Last updated
<bdt class="question">Aug 01, 2022</bdt>
</span>
</span>
</strong>
</span>
</div>
<div><br></div>
<div><br></div>
<div><br></div>
<div style="line-height: 1.5;">
<span>
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
Thank you for choosing to be part of our community at
<bdt class="question">Satta Matka</bdt>
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
("
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
<strong>Company</strong>
</span>
<span>
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"><span data-custom-class="body_text"></span></bdt>
</span>
</span>
</span>
</span>
</span>
<span data-custom-class="body_text">
", "<strong>we</strong>", "<strong>us</strong>", "<strong>our</strong>"). We are committed to protecting your personal information and your right to privacy. If you have any questions or concerns about this privacy notice, or our practices with regards to your personal information, please contact us at
<bdt class="question">support@spboss.in</bdt>
.
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><br></span></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
When you
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
visit our website
<bdt class="question"><a href="https://spboss.in" target="_blank" data-custom-class="link">https://spboss.in</a></bdt>
(the "<strong>Website</strong>"),
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
<bdt class="forloop-component"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
use our mobile application,
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
<bdt class="forloop-component"></bdt>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
as the case may be (the "<strong>App</strong>")
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
and more generally, use any of our services (the "<strong>Services</strong>", which include the&nbsp;
</span>
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"><span data-custom-class="body_text"></span></bdt>
Website
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
<bdt class="block-component"></bdt>
and
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
App
<bdt class="statement-end-if-in-editor"><span data-custom-class="body_text"></span></bdt>
</span>
</span>
</span>
</span>
<span data-custom-class="body_text">), we appreciate that you are trusting us with your personal information. We take your privacy very seriously. In this privacy notice, we seek to explain to you in the clearest way possible what information we collect, how we use it and what rights you have in relation to it. We hope you take some time to read through it carefully, as it is important. If there are any terms in this privacy notice that you do not agree with, please discontinue use of our Services immediately.</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><br></span></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<span>
<span>
<span data-custom-class="body_text">This privacy notice applies to all information collected through our Services (which, as described above, includes our&nbsp;</span>
<span>
<span data-custom-class="body_text">
<bdt class="block-component"><span data-custom-class="body_text"></span></bdt>
Website
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
<bdt class="block-component"></bdt>
and
<bdt class="statement-end-if-in-editor">
<bdt class="block-component"></bdt>
</bdt>
</span>
<span data-custom-class="body_text">
App
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"><span data-custom-class="body_text"></span></bdt>
</span>
</span>
</span>
</span>
<span data-custom-class="body_text">), as well as, any related services, sales, marketing or events.</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><br></span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><span><span><span data-custom-class="body_text"><strong>Please read this privacy notice carefully as it will help you understand what we do with the information that we collect.</strong></span></span></span></span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><br></span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><span><span style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">TABLE OF CONTENTS</span></strong></span></span></span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><br></span></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<a data-custom-class="link" href="#infocollect"><span>1. WHAT INFORMATION DO WE COLLECT?</span></a>
<span>
<span>
<span data-custom-class="body_text">
<span>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<a data-custom-class="link" href="#infouse"><span>2. HOW DO WE USE YOUR INFORMATION?</span></a>
<span>
<span>
<span data-custom-class="body_text">
<span>
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<span><a data-custom-class="link" href="#infoshare">3. WILL YOUR INFORMATION BE SHARED WITH ANYONE?</a></span>
<span>
<span>
<span data-custom-class="body_text">
<span>
<bdt class="block-component"></bdt>
</span>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<a data-custom-class="link" href="#cookies"><span>4. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?</span></a>
<span>
<span>
<span data-custom-class="body_text">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
<span>
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<a data-custom-class="link" href="#3pwebsites"><span>5. WHAT IS OUR STANCE ON THIRD-PARTY WEBSITES?</span></a>
<span>
<span>
<span data-custom-class="body_text">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<a data-custom-class="link" href="#inforetain"><span>6. HOW LONG DO WE KEEP YOUR INFORMATION?</span></a>
<span>
<span>
<span data-custom-class="body_text">
<span>
<span>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<a data-custom-class="link" href="#infosafe"><span>7. HOW DO WE KEEP YOUR INFORMATION SAFE?</span></a>
<span>
<span>
<span data-custom-class="body_text">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<a data-custom-class="link" href="#infominors"><span>8. DO WE COLLECT INFORMATION FROM MINORS?</span></a>
<span>
<span>
<span data-custom-class="body_text">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><span><a data-custom-class="link" href="#privacyrights">9. WHAT ARE YOUR PRIVACY RIGHTS?</a></span></span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><a data-custom-class="link" href="#DNT"><span>10. CONTROLS FOR DO-NOT-TRACK FEATURES</span></a></span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><a data-custom-class="link" href="#caresidents"><span>11. DO CALIFORNIA RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?</span></a></span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px;"><a data-custom-class="link" href="#policyupdates"><span>12. DO WE MAKE UPDATES TO THIS NOTICE?</span></a></span></div>
<div style="line-height: 1.5;"><a data-custom-class="link" href="#contact"><span style=" font-size: 15px;">13. HOW CAN YOU CONTACT US ABOUT THIS NOTICE?</span></a></div>
<div style="line-height: 1.5;"><a data-custom-class="link" href="#request"><span>14. HOW CAN YOU REVIEW, UPDATE OR DELETE THE DATA WE COLLECT FROM YOU?</span></a></div>
<div style="line-height: 1.5;"><br></div>
<div id="infocollect" style="line-height: 1.5;">
<span>
<span style=" font-size: 15px;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span id="control" style="color: rgb(0, 0, 0);">
<strong><span data-custom-class="heading_1">1. WHAT INFORMATION DO WE COLLECT?</span></strong>
<span data-custom-class="heading_1">
<bdt class="block-component"><span data-custom-class="body_text"></span></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span data-custom-class="heading_2" style="color: rgb(0, 0, 0);"><span style="font-size: 15px;"><strong><u><br></u></strong><strong>Personal information you disclose to us</strong></span></span></div>
<div>
<div><br></div>
<div style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span data-custom-class="body_text"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:&nbsp;</em></strong></span></span></span></span><span data-custom-class="body_text"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em></em></strong><em>We collect personal information that you provide to us.</em></span></span></span></span></span></span></div>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We collect personal information that you voluntarily provide to us when you
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
register on the&nbsp;
</span>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services,
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
<span data-custom-class="body_text">
express an interest in obtaining information about us or our products and Services, when you participate in activities on the
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
<bdt class="block-component"></bdt>
(such as by posting messages in our online forums or entering competitions, contests or giveaways)
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
<span data-custom-class="body_text">&nbsp;or otherwise when you contact us.</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
The personal information that we collect depends on the context of your interactions with us and the
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
, the choices you make and the products and features you use. The personal information we collect may include the following:
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Personal Information Provided by You.</strong> We collect
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">names</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">phone numbers</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">email addresses</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">mailing addresses</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">usernames</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">passwords</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">contact preferences</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">contact or authentication data</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<bdt class="question">debit/credit card numbers</bdt>
;&nbsp;
</span>
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
and other similar information.
</span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Payment Data.</strong> We may collect data necessary to process your payment if you make purchases, such as your payment instrument number (such as a credit card number), and the security code associated with your payment instrument. All payment data is stored by
<bdt class="forloop-component"></bdt>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
<bdt class="question">__________</bdt>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
. You may find their privacy notice link(s) here:
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
<bdt class="question">__________</bdt>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
<bdt class="forloop-component"></bdt>
<span style="font-size: 15px;">
<span data-custom-class="body_text">.</span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor">
<bdt class="block-component"></bdt>
</bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
All personal information that you provide to us must be true, complete and accurate, and you must notify us of any changes to such personal information.
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor">
<bdt class="statement-end-if-in-editor"></bdt>
</bdt>
</span>
<bdt class="block-component"></bdt>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor">
<bdt class="statement-end-if-in-editor">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor">
<bdt class="statement-end-if-in-editor">
<bdt class="block-component"></bdt>
</bdt>
</bdt>
</span>
</span>
</span>
</span>
</bdt>
</bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span data-custom-class="heading_2" style="color: rgb(0, 0, 0);"><span style="font-size: 15px;"><strong><u><br></u></strong><strong>Information collected through our App</strong></span></span></div>
<div>
<div><br></div>
<div style="line-height: 1.5;">
<span>
<span style=" font-size: 15px;">
<span data-custom-class="body_text"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:&nbsp;</em></strong></span></span></span></span>
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong><em>&nbsp;</em></strong>
<em>
We collect information regarding your
<span data-custom-class="body_text" style="font-size: 15px;">
<bdt class="block-component"></bdt>
geo-location,
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
mobile device,
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
push notifications,
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="forloop-component"></bdt>
<bdt class="block-component"></bdt>
<bdt class="forloop-component"></bdt>
</span>
when you use our App.
</em>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
If you use our App, we also collect the following information:
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<em>Geo-Location Information.</em> We may request access or permission to and track location-based information from your mobile device, either continuously or while you are using our App, to provide certain location-based services. If you wish to change our access or permissions, you may do so in your device's settings.
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"><span style="font-size: 15px;"></span></bdt>
<div>
<bdt class="block-component"><span style="font-size: 15px;"></span></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<em>Mobile Device Data.&nbsp;</em>We automatically collect device information (such as your mobile device ID, model and manufacturer), operating system, version information and system configuration information, device and application identification numbers, browser type and version, hardware model Internet service provider and/or mobile carrier, and Internet Protocol (IP) address (or proxy server). If you are using our App, we may also collect information about the phone network associated with your mobile device, your mobile device’s operating system or platform, the type of mobile device you use, your mobile device’s unique device ID and information about the features of our App you accessed.
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"><span style="font-size: 15px;"></span></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<em>Push Notifications.</em>We may request to send you push notifications regarding your account or certain features of the App. If you wish to opt-out from receiving these types of communications, you may turn them off in your device's settings.
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component">
<bdt class="forloop-component"><span style="font-size: 15px;"></span></bdt>
<span style="font-size: 15px;"></span>
</bdt>
<bdt class="forloop-component"></bdt>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
This information is primarily needed to maintain the security and operation of our App, for troubleshooting and for our internal analytics and reporting purposes.
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor">
<bdt class="statement-end-if-in-editor"></bdt>
</bdt>
</span>
</span>
</span>
</span>
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor">
<bdt class="block-component"></bdt>
</bdt>
</span>
</span>
</span>
</span>
</span>
</span>
<bdt class="block-component"></bdt>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="infouse" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">2. HOW DO WE USE YOUR INFORMATION?</span></strong></span></span></span></span></span></div>
<div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span data-custom-class="body_text"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short: </em></strong><em>We process your information for purposes based on legitimate business interests, the fulfillment of our contract with you, compliance with our legal obligations, and/or your consent.</em></span></span></span></span></span></span></div>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We use personal information collected via our
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
for a variety of business purposes described below. We process your personal information for these purposes in reliance on our legitimate business interests, in order to enter into or perform a contract with you, with your consent, and/or for compliance with our legal obligations. We indicate the specific processing grounds we rely on next to each purpose listed below.
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We use the information we collect or receive:
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>To facilitate account creation and logon process.</strong> If you choose to link your account with us to a third-party account (such as your Google or Facebook account), we use the information you allowed us to collect from those third parties to facilitate account creation and logon process for the performance of the contract.
<span style=" font-size: 15px;">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>To post testimonials.</strong> We post testimonials on our
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
that may contain personal information. Prior to posting a testimonial, we will obtain your consent to use your name and the content of the testimonial. If you wish to update, or delete your testimonial, please contact us at
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="question">__________</bdt>
<bdt class="else-block"></bdt>
</span>
</span>
</span>
and be sure to include your name, testimonial location, and contact information.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Request feedback.&nbsp;</strong>We may use your information to request feedback and to contact you about your use of our
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>To enable user-to-user communications.</strong> We may use your information in order to enable user-to-user communications with each user's consent.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>To manage user accounts.&nbsp;</strong>We may use your information for the purposes of managing our account and keeping it in working order.
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>To send administrative information to you.&nbsp;</strong>We may use your personal information to send you product, service and new feature information and/or information about changes to our terms, conditions, and policies. pp
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>To protect our Services.&nbsp;</strong>We may use your information as part of our efforts to keep our
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
safe and secure (for example, for fraud monitoring and prevention).
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>
To enforce our terms, conditions and policies for business purposes, to comply with legal and regulatory requirements or in connection with our contract.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</strong>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px;">
<span>
<span>
<span data-custom-class="body_text">
<strong>To respond to legal requests and prevent harm.</strong>If we receive a subpoena or other legal request, we may need to inspect the data we hold to determine how to respond.
<span>
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<p style="font-size: 15px;">
<bdt class="block-component"></bdt>
</p>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px;">
<span>
<span>
<span data-custom-class="body_text">
<strong>Fulfill and manage your orders.&nbsp;</strong>We may use your information to fulfill and manage your orders, payments, returns, and exchanges made through the
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component">.</bdt>
</span>
</span>
</span>
</span>
</span>
</span>
<span>
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<p style="font-size: 15px;">
<bdt class="block-component"></bdt>
</p>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px;">
<span>
<span>
<span data-custom-class="body_text">
<strong>Administer prize draws and competitions.</strong> We may use your information to administer prize draws and competitions when you elect to participate in our competitions.
<span>
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<p style="font-size: 15px;">
<bdt class="block-component"></bdt>
</p>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px;">
<span>
<span>
<span data-custom-class="body_text">
<strong>To deliver and facilitate delivery of services to the user.</strong> We may use your information to provide you with the requested service.
<span>
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<p style="font-size: 15px;">
<bdt class="block-component"></bdt>
</p>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px;">
<span>
<span>
<span data-custom-class="body_text">
<strong>To respond to user inquiries/offer support to users.</strong> We may use your information to respond to your inquiries and solve any potential issues you might have with the use of our Services.
<span>
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"><span style="font-size: 15px;"></span></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>To send you marketing and promotional communications.</strong> We and/or our third-party marketing partners may use the personal information you send to us for our marketing purposes, if this is in accordance with your marketing preferences. For example, when expressing an interest in obtaining information about us or our
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
, subscribing to marketing or otherwise contacting us, we will collect personal information from you. You can opt-out of our marketing emails at any time (see the "<a data-custom-class="link" href="#privacyrights"><span style="font-size: 15px;"><span>WHAT ARE YOUR PRIVACY RIGHTS</span></span></a>" below).
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"><span style="font-size: 15px;"></span></bdt>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text"><strong>Deliver targeted advertising to you.</strong></span>
<span data-custom-class="body_text">
&nbsp;We may use your information to develop and display personalized content and advertising (and work with third parties who do so) tailored to your interests and/or location and to measure its effectiveness.
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</li>
</ul>
<div>
<bdt class="block-component"><span style="font-size: 15px;"></span></bdt>
<div>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
<bdt class="statement-end-if-in-editor"><span style="font-size: 15px;"></span></bdt>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="infoshare" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">3. WILL YOUR INFORMATION BE SHARED WITH ANYONE?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:</em></strong><em>&nbsp; We only share information with your consent, to comply with laws, to provide you with services, to protect your rights, or to fulfill business obligations.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We may process or share your data that we hold based on the following legal basis:
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Consent:</strong> We may process your data if you have given us specific consent to use your personal information for a specific purpose.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Legitimate Interests:</strong> We may process your data when it is reasonably necessary to achieve our legitimate business interests.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Performance of a Contract:</strong> Where we have entered into a contract with you, we may process your personal information to fulfill the terms of our contract.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Legal Obligations:</strong> We may disclose your information where we are legally required to do so in order to comply with applicable law, governmental requests, a judicial proceeding, court order, or legal process, such as in response to a court order or a subpoena (including in response to public authorities to meet national security or law enforcement requirements).
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Vital Interests:</strong> We may disclose your information where we believe it is necessary to investigate, prevent, or take action regarding potential violations of our policies pp, suspected fraud, situations involving potential threats to the safety of any person and illegal activities, or as evidence in litigation in which we are involved.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text">More specifically, we may need to process your data or share your personal information in the following situations:</span></span></span></div>
<ul>
<li style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong>Business Transfers.</strong> We may share or transfer your information in connection with, or during negotiations of, any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company.</span></span></span></li>
</ul>
<div>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
<div>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
<div>
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
<div>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
<div>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
<div>
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
<span>
<bdt class="block-component"><span data-custom-class="body_text"></span></bdt>
</span>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong>Offer Wall.</strong> Our App may display a third-party hosted "offer wall." Such an offer wall allows third-party advertisers to offer virtual currency, gifts, or other items to users in return for the acceptance and completion of an advertisement offer. Such an offer wall may appear in our App and be displayed to you based on certain data, such as your geographic area or demographic information. When you click on an offer wall, you will be brought to an external website belonging to other persons and will leave our App. A unique identifier, such as your user ID, will be shared with the offer wall provider in order to prevent fraud and properly credit your account with the relevant reward. Please note that we do not control third-party websites and have no responsibility in relation to the content of such websites. The inclusion of a link towards a third-party website does not imply an endorsement by us of such website. Accordingly, we do not make any warranty regarding such third-party websites and we will not be liable for any loss or damage caused by the use of such websites. In addition, when you access any third-party website, please understand that your rights while accessing and using those websites will be governed by the privacy notice and terms of service relating to the use of those websites.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div style="line-height: 1.5;">
<span>
<bdt class="block-component"></bdt>
</span>
</div>
<div>
<span style=" font-size: 15px;">
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span>
<bdt class="block-component"><span data-custom-class="heading_1"></span></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="cookies" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">4. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:&nbsp;</em></strong><em>We may use cookies and other tracking technologies to collect and store your information.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We may use cookies and similar tracking technologies (like web beacons and pixels) to access or store information. Specific information about how we use such technologies and how you can refuse certain cookies is set out in our Cookie Notice
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
.
</span>
<span style=" font-size: 15px;">
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
</span>
<bdt class="block-component">
<span data-custom-class="body_text">
<bdt class="block-component">
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</bdt>
</span>
</bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; ">&nbsp;</span></span></div>
<div><span id="3pwebsites"><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">5. WHAT IS OUR STANCE ON THIRD-PARTY WEBSITES?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:</em></strong><em>&nbsp;We are not responsible for the safety of any information that you share with third-party providers who advertise, but are not affiliated with, our Website.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
The
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
may contain advertisements from third parties that are not affiliated with us and which may link to other websites, online services or mobile applications. We cannot guarantee the safety and privacy of data you provide to any third parties. Any data collected by third parties is not covered by this privacy notice. We are not responsible for the content or privacy and security practices and policies pp of any third parties, including other websites, services or applications that may be linked to or from the
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
. You should review the policies of such third parties and contact them directly to respond to your questions.
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span>
<span>
<span>
<bdt class="statement-end-if-in-editor"><span data-custom-class="body_text"></span></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="inforetain" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">6. HOW LONG DO WE KEEP YOUR INFORMATION?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:&nbsp;</em></strong><em>We keep your information for as long as necessary to fulfill the purposes outlined in this privacy notice unless otherwise required by law.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We will only keep your personal information for as long as it is necessary for the purposes set out in this privacy notice, unless a longer retention period is required or permitted by law (such as tax, accounting or other legal requirements). No purpose in this notice will require us keeping your personal information for longer than
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
<bdt class="block-component"></bdt>
the period of time in which users have an account with us
<bdt class="block-component"></bdt>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="else-block"></bdt>
</span>
</span>
</span>
.
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
When we have no ongoing legitimate business need to process your personal information, we will either delete or anonymize such information, or, if this is not possible (for example, because your personal information has been stored in backup archives), then we will securely store your personal information and isolate it from any further processing until deletion is possible.
<span>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="infosafe" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">7. HOW DO WE KEEP YOUR INFORMATION SAFE?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:&nbsp;</em></strong><em>&nbsp;We aim to protect your personal information through a system of organizational and technical security measures.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We have implemented appropriate technical and organizational security measures designed to protect the security of any personal information we process. However, despite our safeguards and efforts to secure your information, no electronic transmission over the Internet or information storage technology can be guaranteed to be 100% secure, so we cannot promise or guarantee that hackers, cybercriminals, or other unauthorized third parties will not be able to defeat our security, and improperly collect, access, steal, or modify your information. Although we will do our best to protect your personal information, transmission of personal information to and from our
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
is at your own risk. You should only access the
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
within a secure environment.
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="infominors" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">8. DO WE COLLECT INFORMATION FROM MINORS?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:</em></strong><em>&nbsp; We do not knowingly collect data from or market to children under 18 years of age.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
We do not knowingly solicit data from or market to children under 18 years of age. By using the
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
, you represent that you are at least 18 or that you are the parent or guardian of such a minor and consent to such minor dependents use of the
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
. If we learn that personal information from users less than 18 years of age has been collected, we will deactivate the account and take reasonable measures to promptly delete such data from our records. If you become aware of any data we may have collected from children under age 18, please contact us at
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="question">__________</bdt>
<bdt class="else-block"></bdt>
</span>
</span>
.
<span style=" font-size: 15px;">
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="privacyrights" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">9. WHAT ARE YOUR PRIVACY RIGHTS?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong><em>In Short:</em></strong>
<em>
&nbsp;
<span>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<em>
<bdt class="block-component"></bdt>
</em>
</span>
</span>
</span>
You may review, change, or terminate your account at any time.
</em>
<span>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span style="font-size: 15px; ">&nbsp;</span></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text">If you are a resident in the European Economic Area and you believe we are unlawfully processing your personal information, you also have the right to complain to your local data protection supervisory authority. You can find their contact details here: <span style="font-size: 15px;"><span><span data-custom-class="body_text"><span style="color: rgb(48, 48, 241);"><span data-custom-class="body_text">
</span></span></span></span></span>.</span></span></span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
If you are a resident in Switzerland, the contact details for the data protection authorities are available here: <span style="font-size: 15px;"><span><span data-custom-class="body_text"><span style="color: rgb(48, 48, 241);"><span data-custom-class="body_text"><span style="font-size: 15px;"> </span></span></span></span></span></span>.
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
If you have questions or comments about your privacy rights, you may email us at
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="question">support@spboss.in</bdt>
</span>
</span>
</span>
.
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span>
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><span data-custom-class="heading_2" style="color: rgb(0, 0, 0);"><span style="font-size: 15px;"><strong><u><br></u></strong><strong>Account Information</strong></span></span></div>
<div>
<div><br></div>
<div style="line-height: 1.5;">
<span>
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
If you would at any time like to review or change the information in your account or terminate your account, you can:
<bdt class="forloop-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<span>
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="question">Log in to your account settings and update your user account.</bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</li>
</ul>
<div>
<span>
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
Upon your request to terminate your account, we will deactivate or delete your account and information from our active databases. However, we may retain some information in our files to prevent fraud, troubleshoot problems, assist with any investigations, enforce our Terms of Use and/or comply with applicable legal requirements.
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong><u>Cookies and similar technologies:</u></strong> Most Web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove cookies and to reject cookies. If you choose to remove cookies or reject cookies, this could affect certain features or services of our
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
. To opt-out of interest-based advertising by advertisers on our
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
visit <span style="color: rgb(48, 48, 241);"><span data-custom-class="body_text">
</span></span>.
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span>
<span style="font-size: 15px;">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<strong><u>Opting out of email marketing:</u></strong> You can unsubscribe from our marketing email list at any time by clicking on the unsubscribe link in the emails that we send or by contacting us using the details provided below. You will then be removed from the marketing email list however, we may still communicate with you, for example to send you service-related emails that are necessary for the administration and use of your account, to respond to service requests, or for other non-marketing purposes. To otherwise opt-out, you may:
<span>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="forloop-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</div>
<ul>
<li style="line-height: 1.5;">
<bdt class="question"><span data-custom-class="body_text">Access your account settings and update your preferences.</span></bdt>
</li>
</ul>
<div>
<bdt class="forloop-component">
<span data-custom-class="body_text">
<span>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
</bdt>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="DNT" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">10. CONTROLS FOR DO-NOT-TRACK FEATURES</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text">Most web browsers and some mobile operating systems and mobile applications include a Do-Not-Track ("DNT") feature or setting you can activate to signal your privacy preference not to have data about your online browsing activities monitored and collected. At this stage no uniform technology standard for recognizing and implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser signals or any other mechanism that automatically communicates your choice not to be tracked online. If a standard for online tracking is adopted that we must follow in the future, we will inform you about that practice in a revised version of this privacy notice.</span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div id="caresidents" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">11. DO CALIFORNIA RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?</span></strong></span></span></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><strong><em>In Short:&nbsp;</em></strong><em>&nbsp;Yes, if you are a resident of California, you are granted specific rights regarding access to your personal information.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text">California Civil Code Section 1798.83, also known as the "Shine The Light" law, permits our users who are California residents to request and obtain from us, once a year and free of charge, information about categories of personal information (if any) we disclosed to third parties for direct marketing purposes and the names and addresses of all third parties with which we shared personal information in the immediately preceding calendar year. If you are a California resident and would like to make such a request, please submit your request in writing to us using the contact information provided below.</span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
If you are under 18 years of age, reside in California, and have a registered account with
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
a Service
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
, you have the right to request removal of unwanted data that you publicly post on the
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
. To request removal of such data, please contact us using the contact information provided below, and include the email address associated with your account and a statement that you reside in California. We will make sure the data is not publicly displayed on the
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
Services
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</span>
</span>
, but please be aware that the data may not be completely or comprehensively removed from all our systems (e.g. backups, etc.).
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="policyupdates" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">12. DO WE MAKE UPDATES TO THIS NOTICE?</span></strong></span>&nbsp;</span>&nbsp;</span></span>&nbsp;</span></div>
<div style="line-height: 1.5;"><em><br></em></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text"><em><strong>In Short:&nbsp;</strong> Yes, we will update this notice as necessary to stay compliant with relevant laws.</em></span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text">We may update this privacy notice from time to time. The updated version will be indicated by an updated "Revised" date and the updated version will be effective as soon as it is accessible. If we make material changes to this privacy notice, we may notify you either by prominently posting a notice of such changes or by directly sending you a notification. We encourage you to review this privacy notice frequently to be informed of how we are protecting your information.</span></span></span></div>
<div style="line-height: 1.5;"><br></div>
<div id="contact" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">13. HOW CAN YOU CONTACT US ABOUT THIS NOTICE?</span></strong>&nbsp;</span></span>&nbsp;</span>&nbsp;</span>&nbsp;</span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
If you have questions or comments about this notice, you may
<span style=" font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
email us at
<bdt class="question">__________</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
<span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text">or by post to:</span></span></span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;">
<span style="font-size: 15px; ">
<span style="font-size: 15px; ">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span>
<span>
<span data-custom-class="body_text">
<bdt class="question">Matka HeadOffice</bdt>
</span>
</span>
</span>
</span>
</span>
<span data-custom-class="body_text">
<span>
<span data-custom-class="body_text">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="question">Kalyan,Mumbai,</bdt>
<span>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="question">Mumbai</bdt>
<span>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
,
<bdt class="question">Maharashtra</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
<bdt class="block-component"></bdt>
<bdt class="question">420002</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
<span style="font-size: 15px;">
<bdt class="block-component"></bdt>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span>
<bdt class="block-component"></bdt>
</span>
</span>
</span>
<bdt class="question">India</bdt>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span>
<bdt class="statement-end-if-in-editor">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span>
<bdt class="statement-end-if-in-editor">
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<span>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
</bdt>
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
<span data-custom-class="body_text">
<span>
<span style="font-size: 15px;">
<bdt class="statement-end-if-in-editor"></bdt>
</span>
</span>
</span>
<span>
<span style="font-size: 15px;">
<span data-custom-class="body_text">
<bdt class="block-component">
<bdt class="block-component"></bdt>
</bdt>
</span>
</span>
</span>
</bdt>
</span>
</span>
</span>
</span>
</span>
</div>
<div style="line-height: 1.5;"><br></div>
<div id="request" style="line-height: 1.5;"><span><span style=" font-size: 15px;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span id="control" style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">14. HOW CAN YOU REVIEW, UPDATE, OR DELETE THE DATA WE COLLECT FROM YOU?</span></strong>&nbsp;</span></span>&nbsp;</span>&nbsp;</span></span></div>
<div style="line-height: 1.5;"><br></div>
<div style="line-height: 1.5;"><span style="font-size: 15px; "><span style="font-size: 15px; "><span data-custom-class="body_text">Based on the applicable laws of your country, you may have the right to request access to the personal information we collect from you, change that information, or delete it in some circumstances. </span></span></span></div>
<style>
                              ul {
                              list-style: none;
                              }
                              ul > li > ul {
                              list-style: none;
                              }
                              ul > li > ul > li > ul {
                              list-style: none;
                              }
                              ol li {
                              font-family: Arial ;
                              }
                           </style>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<style>
.button2 {
  background-color: #a0d5ff;
  color: #220c82;
  padding: 10px 30px;
  font-size: 16px;
  margin: 20px auto;
  border-radius: 10px;
  border: 2px solid #0000005c;
  font-weight: 800;
  text-shadow: 1px 1px #00bcd4;
  box-shadow: 0 8px 10px 0 rgba(0,0,0,.2) , 0 6px 8px 0 rgba(0,0,0,.19);
  display: inline-block;
  transition: all .3s;
}

.chart-list.ab1 {
  border-color: #003c6c;
}

.chart-list {
  border: 2px solid #eb008b;
    border-top-color: rgb(235, 0, 139);
    border-right-color: rgb(235, 0, 139);
    border-bottom-color: rgb(235, 0, 139);
    border-left-color: rgb(235, 0, 139);
  border-radius: 10px 0 10px 10px;
  margin-bottom: 2px;
  width: 50%;
  margin: 0 auto 10px;
  text-align: center;
  font-weight: 600;
}

footer {
  background-color: #fff;
  color: red;
  font-weight: bold;
  font-size: 25px;
  text-decoration: none;
  border: 4px groove purple;
  border-radius: 10px 0 0 0;
  text-shadow: 1px 1px gold;
  margin: 3px;
}
footer > div {
  border-bottom: 2px solid #b2ddff;
  padding: 10px 0;
  margin-bottom: 10px;
}
footer > div a {
  text-decoration: none;
}
footer p {
  margin: 10px 0 10px;
  line-height: 35px;
  color: red;
font-weight: bold;
font-size: 25px;
text-shadow: 1px 1px gold;
}
footer .ftr-icon {
  text-decoration: none;
  font-size: 35px;
  text-transform: uppercase;
  color: #007bff;
}
.chart-list.ab1 h4 {
  background-color: #024c88;
} 
.chart-list h4 {
  color: #fff;
  padding: 5px 10px 3px;
  font-size: 24px;
  border-top-left-radius: 7px;
  margin: 0;
}
.chart-list {
  text-align: center;
  font-weight: 600;
}
.chart-list a {
  display: block;
  font-size: 22px;
  padding: 5px 7px 4px;
  text-decoration: none;
}
.chart-list.ab1 a {
  border-bottom: 2px solid #024c88;
  color: #003c6c;
}
.chart-list.ab1 h4 {
  background-color: #024c88;
  border-radius: 7px 0px 0px;
  border: none;
}
footer p span {
  color: #36f;
}.chart-list.ab1 h4::before {
  content: none;
}


@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
.mp-btn {
  position: fixed;
  bottom: 9px;
  left: 5px;
  padding: 5px 8px;
  font-size: 15px;
  border: 1px solid #fff;
  text-decoration: none;
  background-color: #039;
  color: #fff;
  border-radius: 5px;
}
</style>
<center>
<div id="bottom"></div>
<a href="#top" class="button2"> Go to Top </a>
</center>
<style>

html{overflow-x:hidden;scroll-behavior:smooth}body{background-color:#fc9;color:#000;font-weight:700;text-align:center!important;margin-bottom:0;margin-top:4px;font-family:Helvetica,sans-serif!important}*{transition:all .3s}a{text-decoration:none!important;color:inherit}.my-header{border-radius:10px 0 10px 10px;margin-bottom:3px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:1px 2px}.my-header img{height:160px;width:auto;margin:-28px 0 -34px}.open-close{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:20px 5px 22px}.open-close h2{color:#fff;font-size:32px;background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);display:inline-block;padding:10px 20px 10px;margin:0;border-radius:10px}.open-close h3{color:#1a237e;font-size:29px;margin:0 0 20px}.my-card{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #9c27b0;box-shadow:0 0 9px -1px #ffeddc;padding:0 0 2px;overflow:hidden}.my-card h3{color:#fff;font-size:32px;margin:0;padding:2px 0 1px}.headering-1 h3{background-color:#50005b}.headering-2 h3{background-color:#ff0;color:#000}.headering-3 h3{background-color:#0f005b}.my-card h2{color:#232323;margin:10px 0;font-size:22px}.my-footer{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:0 5px 22px}.my-footer .top-div{z-index:81}.my-footer .top-div a{z-index:41;cursor:pointer}.my-footer .my-img{z-index:-10}.my-footer .my-img img{height:160px;width:auto;margin:-28px 0 -34px;z-index:-9}.my-footer .two-btn a{border:2px solid #e91e63;padding:3px 8px 4px;border-radius:5px;font-size:18px;color:#fff;background-color:#e91e63;font-weight:500;display:inline-block}.my-footer .last-para{margin:20px 0 0}.my-footer .last-para p{margin:6px 0 0;font-size:20px;font-weight:400;color:#151515}@media only screen and (max-width:500px){.my-header img{height:90px;width:auto;margin:-16px 0 -19px}.open-close{padding:8px 0 10px}.open-close h3{font-size:20px;margin-bottom:10px}.open-close h2{font-size:22px}.my-card h3{font-size:24px}.my-card h2{font-size:17px}.my-footer{padding-bottom:10px}.my-footer .my-img img{height:100px;width:auto;margin:-16px 0 -19px}.my-footer .two-btn a{font-size:14px;padding:5px 5px 6px}.my-footer .last-para p{font-size:16px}}@media only screen and (max-width:320px){.my-footer .two-btn a{font-size:12px;padding:3px}}


.logo {
border: 2px solid #eb008b;
border-radius: 10px 0 10px 10px;
margin: 2px;
overflow: hidden;
}
.logo amp-img {
width: 220px;
height: auto;
padding: 6px 0 0;
}
.button2 {
background-color: #a0d5ff;
color: #220c82;
padding: 10px 30px;
font-size: 16px;
margin: 20px auto;
border-radius: 10px;
border: 2px solid #0000005c;
font-weight: 800;
text-shadow: 1px 1px #00bcd4;
box-shadow: 0 8px 10px 0 rgb(0 0 0 / 20%), 0 6px 8px 0 rgb(0 0 0 / 19%);
display: inline-block;
transition: all .3s;
}.ad-div11 {
text-align: center;
margin: 0 0 10px;
}
.chart-list {
border: 2px solid #eb008b;
border-radius: 10px 0 10px 10px;
margin-bottom: 2px;
width: 50%;
margin: 0 auto 10px;
text-align: center;
font-weight: 600;
}
.chart-list.ab1 {
border-color: #003c6c;
}
.chart-list h4 {
color: #fff;
padding: 5px 10px 3px;
font-size: 24px;
border-top-left-radius: 7px;
margin: 0;
}
.chart-list.ab1 h4 {
background-color: #024c88;
}
.chart-list a {
display: block;
font-size: 22px;
padding: 5px 7px 4px;
text-decoration: none;
}
.chart-list.ab1 a {
border-bottom: 2px solid #024c88;
color: #003c6c;
}
footer {
background-color: #fff;
color: red;
font-weight: bold;
font-size: 25px;
text-decoration: none;
border: 4px groove purple;
border-radius: 10px 0 0 0;
text-shadow: 1px 1px gold;
margin: 3px;
}
footer > div {
border-bottom: 2px solid #b2ddff;
padding: 10px 0;
margin-bottom: 10px;
}
footer > div a {
text-decoration: none;
}
footer > div a:hover {
text-decoration: none;
}
footer .ftr-icon {
text-decoration: none;
font-size: 35px;
text-transform: uppercase;
color: #007bff;
}
footer p {
margin: 10px 0 10px;
line-height: 35px;
}
footer p span {
color: #36f;
}

body {
  background-color: #fc9;
  text-align: center;
  padding-left: 10px;
  padding-right: 10px;
  font-family: 'Roboto',sans-serif;
}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
</style>
<div class="chart-list ab1">
<h4>SPECIAL DAILY GAME ZONE</h4>
<a href="https://spboss.in/guessing-forum.php"> Dpboss Guessing Forum </a>
<a href="https://spboss.in/satta-matka-fix-game.php"> 100% Date Fix Free Game Open TO Close </a>
<a href="https://spboss.in/khatris-favourite-panna-chart.php"> Ratan Khatri Fix Panel Chart </a>
<a href="https://spboss.in/matka-final-number-chart.php"> Matka Final Number Trick Chart </a>
<a href="https://spboss.in/matka-jodi-count-chart.php">Matka Jodi Count Chart</a>
<a href="https://spboss.in/fix-open-to-close-by-date.php">Dhanvarsha Daily Fix Open To Close</a>
<a href="https://spboss.in/jodi-chart-family-matka.php">Matka Jodi Family Chart</a>
<a href="https://spboss.in/penal-count-chart.php">Penal Count Chart</a>
<a href="https://spboss.in/penal-total-chart.php">Penal Total Chart</a>
<a href="https://spboss.in/all-22-card-panna-penal-patti-chart.php">All 220 Card List</a>
</div>


<footer>
<div>
<a style="color: red;" href="https://spboss.in" title="SATTA MATKA">Home</a> |
<a style="color: green;" href="https://spboss.in/guessing-forum.php" title="Satta matka guessing">Guessing Forum</a> |
<a style="color: purple;" href="https://spboss.in/ever-green-tricks/satta-matka-tricks-zone-tips.php" title="Satta matka tricks">100% Fix Jodi Tricks</a> |
<a style="color: blue;" href="https://spboss.in/satta-matka-fix-game.php" title="SATTA MATKA">Date Fix Game</a>
</div>
<a class="ftr-icon" href="https://spboss.in">spboss.in</a>
<p>
All Rights Reseved®
<br>
(1980-2022)
<br>
Contact (Astrologer-<span>Dpboss</span>)
</p>
</footer>
</body></html>
