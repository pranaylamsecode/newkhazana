<!DOCTYPE html>
<html amp lang="en-in">
<head>
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
<meta charset="UTF-8">
<title>All Comprehensive ANK 22 Card Panna Penal Patti Chart - SPBOSS</title>
<meta name="description" content="Access the complete ANK 22 Card Panna Penal Patti Chart on SPBOSS. Master the game with accurate insights on card numbers, panna, penal, and patti. Elevate your gameplay now!">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script type="application/ld+json">
	{
		"@context": "http://schema.org",
		"@type": "NewsArticle",
		"author": "spboss.in",
		"headline": "Open-source framework for publishing content",
		"datePublished": "2015-10-07T12:02:41Z",
		"image": [
			"logo.jpg"
		],
		"publisher": {
      "@type": "Organization",
      "name": "DPBOSS",
      "logo": {
        "@type": "ImageObject",
        "url": "https://spboss.in/logo.png"
      }
    }
	}
</script>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<link rel="canonical" href="https://spboss.in/all-22-card-panna-penal-patti-chart.php" />
<link rel="shortcut icon" href="img/favicon.ico">
<style amp-custom>
html {
  overflow-x: hidden;
  scroll-behavior: smooth;
}
body {
  background-color: #fc9;
  color: #000;
  font-weight: bold;
  text-align: center;
  margin-bottom: 0;
  margin-top: 4px;
  font-family: Helvetica, sans-serif;
  padding: 0 10px;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
a:hover,
a {
  text-decoration: none;
}
.logo-div {
  border-width: 2px;
  border-style: solid;
  margin-bottom: 5px;
  border-radius: 6px;
}
.logo-div {
  border-color: #eb008b;
  padding: 7px 0 4px;
  box-shadow: 0 0 10px -4px #000;
}
footer {
  background-color: #ffc285;
  border-radius: 10px 0 10px 10px;
  box-shadow: 0 0 10px -3px #000;
  border: 2px solid #a127ac;
  margin-top: 12px;
}
footer h4 {
  font-size: 32px;
  color: #e91e63;
  line-height: 2;
  font-style: normal;
  text-shadow: 1px 1px 2px #fff;
  padding-top: 10px;
}
footer .ftr-btn-div {
  display: flex;
  justify-content: center;
}
footer .btn-back {
  margin: 0 6px;
}
footer .btn {
  color: #fff;
  padding: 4px 14px 2px;
  font-size: 20px;
  border-radius: 50px;
  text-shadow: 1px 1px 2px #444;
  font-style: normal;
  transition: all 0.3s;
  transform: scale(1);
  border: 2px solid #950435;
  background: #e71e62;
}
footer .btn:hover {
  border: 2px solid #781182;
  background: #a127ac;
}
footer h1 {
  color: #e91e63;
  font-size: 20px;
  padding-top: 20px;
  padding-bottom: 6px;
  text-shadow: 1px 1px 2px #fff;
}
footer h6 {
  font-size: 22px;
  color: #e91e63;
  padding-bottom: 14px;
  text-shadow: 1px 1px 2px #fff;
}
.fav-cards h4 {
  border-radius: 4px;
  background: #aa00c0;
  color: #fff;
  text-shadow: 1px 1px 0 #444;
  letter-spacing: 1px;
  font-size: 32px;
  padding: 4px 4px 4px;
  box-shadow: 0 0 10px -4px #000;
  margin-bottom: 7px;
}
.fav-cards .aa {
  box-shadow: 0 0 10px -4px #000;
  border: 2px solid #aa00c0;
  border-radius: 10px 0 10px 10px;
  overflow: hidden;
}
.fav-cards .aa h1 {
  font-size: 28px;
  background-color: #41188b;
  color: #ffffff;
  text-shadow: 1px 1px #421a8b;
  line-height: 1.4;
}
.fav-cards .aa > div > div {
  padding: 10px;
}
.fav-cards .aa p {
  color: #7a028d;
  font-size: 22px;
  padding: 2px 0;
  text-shadow: 1px 1px 2px #c4c4c4;
  margin-bottom: 0;
}
.all-satta h4 {
  border-radius: 4px;
  background: #f44336;
  color: #fff;
  text-shadow: 1px 1px 0 #444;
  letter-spacing: 1px;
  font-size: 32px;
  padding: 4px 4px 4px;
  box-shadow: 0 0 10px -4px #000;
  margin-bottom: 7px;
  margin-top: 10px;
}
.all-satta .bb {
  box-shadow: 0 0 10px -4px #000;
  border: 2px solid #800d04;
  border-radius: 10px 0 10px 10px;
  overflow: hidden;
}
.all-satta .bb h1 {
  font-size: 28px;
  background-color: #800d04;
  color: #ffffff;
  text-shadow: 1px 1px #421a8b;
  line-height: 1.4;
}
.all-satta .bb > div > div {
  padding: 10px;
}
.all-satta .bb p {
  color: #800d04;
  font-size: 18px;
  padding: 2px 0;
  text-shadow: 1px 1px 2px #c4c4c4;
  margin-bottom: 0;
}

</style>
</head>
<body>
<!-- logo -->
<div class="logo-div" id="top">
	<amp-img src="img/logo.png" alt="spboss.in logo" width="220" height="82">
</div>
<!-- our fav cards -->
<div class="fav-cards">
	<h1>KHATRI FAVORITE CARDS</h1>
	<div class="aa">
		<div>
			<big><big>1</big></big>
			<div>
				<p>128 137 236 678</p>
				<p>245 290 470 579</p>
			</div>
		</div>
		<div>
			<big><big>2</big></big>
			<div>
				<p>129 147 246 679</p>
				<p>345 390 480 589</p>
			</div>
		</div>
		<div>
			<big><big>3</big></big>
			<div>
				<p>120 157 256 670</p>
				<p>139 148 346 689</p>
			</div>
		</div>
		<div>
			<big><big>4</big></big>
			<div>
				<p>130 158 356 680</p>
				<p>239 248 347 789</p>
			</div>
		</div>
		<div>
			<big><big>5</big></big>
			<div>
				<p>140 159 456 690</p>
				<p>230 258 357 780</p>
			</div>
		</div>
		<div>
			<big><big>6</big></big>
			<div>
				<p>123 178 268 367</p>
				<p>240 259 457 790</p>
			</div>
		</div>
		<div>
			<big><big>7</big></big>
			<div>
				<p>124 179 269 467</p>
				<p>340 359 458 890</p>
			</div>
		</div>
		<div>
			<big><big>8</big></big>
			<div>
				<p>125 170 260 567</p>
				<p>134 189 369 468</p>
			</div>
		</div>
		<div>
			<big><big>9</big></big>
			<div>
				<p>135 180 360 568</p>
				<p>234 289 379 478</p>
			</div>
		</div>
		<div>
			<big><big>0</big></big>
			<div>
				<p>145 190 460 569</p>
				<p>235 280 370 578</p>
			</div>
		</div>
	</div>
</div>
<!-- all 22 satta -->
<div class="all-satta">
	<h4>All 22 Satta Matka Card</h4>
	<div class="bb">
		<div>
			<big><big>777 !!-1-!! 100</big></big>
			<div>
				<p>128-137-146-236-245- 290-380-470-489-560</p>
				<p>678-579-119-155-227- 335-344-399-588-669</p>
			</div>
		</div>
		<div>
			<big><big>444 !!-2-!! 200</big></big>
			<div>
				<p>129-138-147-156-237- 246-345-390-480-570</p>
				<p>679-589-110-228-255- 336-499-660-688-778</p>
			</div>
		</div>
		<div>
			<big><big>111 !!-3-!! 300</big></big>
			<div>
				<p>120-139-148-157-238- 247-256-346-490-580</p>
				<p>670-689-166-229-337- 355-445-599-779-788</p>
			</div>
		</div>
		<div>
			<big><big>888 !!-4-!! 400</big></big>
			<div>
				<p>130-149-158-167-239- 248-257-347-356-590</p>
				<p>680-789-112-220-266- 338-446-455-699-770</p>
			</div>
		</div>
		<div>
			<big><big>555 !!-5-!! 500</big></big>
			<div>
				<p>140-159-168-230-249- 258-267-348-357-456</p>
				<p>690-780-113-122-177- 339-366-447-799-889</p>
			</div>
		</div>
		<div>
			<big><big>222 !!-6-!! 600</big></big>
			<div>
				<p>123-150-169-178-240- 259-268-349-358-457</p>
				<p>367-790-114-277-330- 448-466-556-880-899</p>
			</div>
		</div>
		<div>
			<big><big>999 !!-7-!! 700</big></big>
			<div>
				<p>124-160-179-250-269- 278-340-359-368-458</p>
				<p>467-890-115-133-188- 223-377-449-557-566</p>
			</div>
		</div>
		<div>
			<big><big>666 !!-8-!! 800</big></big>
			<div>
				<p>125-134-170-189-260- 279-350-369-378-459</p>
				<p>567-468-116-224-233- 288-440-477-558-990</p>
			</div>
		</div>
		<div>
			<big><big>333 !!-9-!! 900</big></big>
			<div>
				<p>126-135-180-234-270- 289-360-379-450-469</p>
				<p>117-478-568-144-199- 225-388-559-577-667</p>
			</div>
		</div>
		<div>
			<big><big>000 !!-0-!! 550</big></big>
			<div>
				<p>127-136-145-190-235-280 370-389-460-479</p>
				<p>569-578-118-226-244-299-334-488-668-677</p>
			</div>
		</div>
	</div>
</div>

<!-- footer -->
<footer>
	<p style="text-align: justify;">The All Comprehensive ANK 22 Card Panna Penal Patti Chart is a valuable resource for Indian number players of all levels at SPBoss. This chart includes all possible combinations of cards, as well as the point values for each combination. With this chart, you can easily calculate your chances of winning any hand, and make the best possible decisions when playing.</p>
<p style="text-align: justify;">The chart is easy to read and understand, even for beginners. It is also updated regularly to reflect the latest changes to the rules of Indin number games. The chart is available in both English and Hindi, With this chart, you will be able to improve your game and increase your chances of winning.</p>
  <h4>spboss.in</h4>
  <div class="ftr-btn-div">
  	<a href="#" class="btn btn-home">HOME</a>
  	<a href="#" class="btn btn-back">BACK</a>
  	<a href="#" class="btn btn-dm">DCMA</a>
  </div>
  <big><big>Copyright @2020</big></big>
  <h6>Powered by spboss.in</h6>
</footer>
</body>
</html>