
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forum Rules</title>
<meta name="keywords" content="Forum Rules" />
<meta name="description" content="Forum Rules" />
<link rel="canonical" href="https://spboss.in/forum-rules.php" />

<link rel="icon" href="images1/favicon-96x96.png" type="image/gif" sizes="16x16">


<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

@media (max-width:480px){.row{padding:0;margin:0}}@media (max-width:720px){.panel-heading h2{font-size:14px;padding:5px!important}.panel-body h2{font-size:14px;padding:5px!important}}body{padding-top:70px}.navbar-header{float:none}.navbar-toggle{display:block}.navbar-collapse.collapse{display:none!important}.navbar-nav{float:none!important}.navbar-nav>li{float:none}.navbar-collapse.collapse.in{display:block!important}

/*!
 * Start Bootstrap - 4 Col Portfolio HTML Template (http://startbootstrap.com)
 * Code licensed under the Apache License v2.0.
 * For details, see http://www.apache.org/licenses/LICENSE-2.0.
 */body{padding-top:0;background-color:#fc9;color:#000;font-size:14px;font-weight:700}.container-fluid,.row{padding:0;margin:0}.portfolio-item{margin-bottom:25px}.green_bg_color{background-image:-webkit-linear-gradient(0deg,#7e8080 20%,#b1bcbe 40%,#506465 100%);color:#fff}.panel-info>.panel-heading{background-color:none}.alert-success{background-color:#121312}.alert-info2{color:#31708f;padding:0;border-bottom:2px solid #615c5c}.ss{text-shadow:0 0 3px red,0 0 5px #968512}.card1{border:0;font-weight:400;background-color:#615c5c;padding:0;margin:7px}.panel2{padding:15px;box-shadow:1px 12px 13px grey;margin-bottom:29px;border-radius:0 7px;border-left:20px solid #696666;border-right:23px solid transparent;border-top:12px solid transparent}.panel{border:2px solid #ff006c}.well-sm{margin-bottom:-4px;border-radius:0 7px;font-weight:600;color:#000}a{color:#0f0f0f;text-decoration:none}.btn-info{color:#fff;background-color:#897117;border-color:#6d736d;box-shadow:2px 3px #88888878}.btn-success{color:#fff;background-color:#897117;border-color:#6d736d;box-shadow:2px 3px #88888878}.col12{background:#8e7061;padding:0;margin-top:0;margin-bottom:20px}hr{margin-top:0;margin-bottom:15px;border:0;border-top:2px solid #e60a0a;margin-left:25%;margin-right:25%}.dropdown-menu{background:#ff0ad6;position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px 0;margin:2px 0 0;font-size:14px;text-align:left;list-style:none;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box}.s{text-shadow:2px 0 0 #800040,3px 2px 0 rgba(77,0,38,.5),3px 0 3px #ff002b,5px 0 3px #800015,6px 2px 3px rgba(77,0,13,.5),6px 0 9px #f50,8px 0 9px #802a00,9px 2px 9px rgba(77,25,0,.5),9px 0 18px #ffd500,11px 0 18px #806a00,12px 2px 18px rgba(77,66,0,.5),12px 0 30px #d4ff00,14px 0 30px #6a8000,15px 2px 30px rgba(64,77,0,.5),15px 0 45px #80ff00,17px 0 45px #408000,17px 2px 45px rgba(38,77,0,.5);color:#f0f3ea;font-size:23px}.blinking{animation:blinkingText 4.8s infinite}@keyframes blinkingText{0%{color:red}10%{color:#ff0}20%{color:#00f}40%{color:green}50%{color:pink}60%{color:orange}80%{color:#000}100%{color:brown}}.navbar-nav>li>a{padding-top:0;padding-bottom:12px}.nav>li>a{position:relative;display:block;padding:10px 15px}.form-control{font-family:Montserrat-Bold;font-size:15px;line-height:1.2;color:#333;display:block;width:100%;background:#fff;height:35px;border-radius:25px;padding:0 30px 0 53px;margin-bottom:9px}.home-game-name{font-size:24px;font-family:serif;text-transform:uppercase;font-weight:600;color:#ffef29}ul.breadcrumb{display:none}.card1 a{text-decoration:none}.a-no-underline{text-decoration:none}.h6,h6{font-size:15px}.white{color:#000}.black{color:#000}footer{margin:50px 0}.logo{padding-top:27px;color:#fff!important}.navbar{background:0 0}.navbar-nav a{color:#fff!important;margin-top:12px}.error{color:red;font-size:11px;font-weight:400}.dropdown-menu{background:#f1f1f1}.dropdown-menu li a{color:#000!important;padding:5px;margin-top:0}.dashboard-box{margin-bottom:24px;padding:20px;box-sizing:border-box}.dashbozrd-box-inner{box-shadow:0 0 4px 0 rgba(0,0,0,.08),0 2px 4px 0 rgba(0,0,0,.12);border-radius:4px;background:#fff}.legend{display:block;text-align:left;border-bottom:solid 1px #ddd;color:#444;font-weight:400;line-height:1.583em;padding-bottom:.75em;margin-bottom:1.5em;font-size:1.33em}.checkbox-container{position:relative;padding-left:18px;cursor:pointer;font-size:12px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.checkbox-container input{position:absolute;opacity:0;cursor:pointer;height:0;width:0}.checkmark{position:absolute;top:0;left:0;height:0;width:0;background-color:#eee}.checkbox-container:hover input~.checkmark{background-color:#ccc}.checkbox-container input:checked~.checkmark{background-color:#2196f3}.checkmark:after{content:"";position:absolute;display:none}.checkbox-container input:checked~.checkmark:after{display:block}.checkbox-container .checkmark:after{left:9px;top:5px;width:5px;height:6px;border:solid #fff;border-width:0 3px 3px 0;-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg)}.results h1,h2,h3,h4,h5{color:#fff;font-size:19px}.chart-table h1,.chart-table h2,.chart-table h3,.chart-table h4,.chart-table h5{color:#280098;font-size:19px}.no-pad{padding:2px}.h1,.h2,.h3,h1,h2,h3{margin-top:5px;margin-bottom:5px}.panel-chart p{color:#0c00c3;font-size:19px}.panel-chart h1,h2{color:#000;font-weight:600;font-size:25px}.heading-h3{text-shadow:1px 1px 2px #000,0 0 25px #fff,0 0 5px #b3a7a7;font-size:24px;color:#fcfcfc;font-family:serif;text-transform:uppercase}.panel-success>.panel-heading{border-color:#ff006c!important}.panel-success .panel-footer,.panel-success .panel-heading{background:gold;color:#000;padding:0;font-weight:700}.forum-post-footer1{background:gold}.forum-post-footer2{background:#dcbb00}.panel{background:0 0}.panel-info>.panel-heading{color:#31708f;background-color:#d9edf700;border-color:#ff006c}.headingBck{background-color:#00008b;color:#fff;text-align:center;box-sizing:border-box;box-shadow:0 0 20px #86757a;border-radius:16%;margin:0;padding:0}.no-padding{padding:15px 7px}.navbar-default{border:2px solid #ff006c}.panel{margin-bottom:20px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05);background:0 0}.panel-info{border:2px solid #ff006c}.panel-info .panel-heading{color:#fff}.panel-danger{border:3px solid #bd904d}.refresh-button{position:absolute;transition:opacity .6s ease-in-out;z-index:999;right:20px;bottom:20px}.like_unlike{cursor:pointer!important}.bg-grey{background:#e1e1e1!important}.form-href{color:#000}.forum-btn-b1{background-color:#f1f1f1;border-radius:0!important;color:#000;text-decoration:none;padding:4px 4px!important;min-width:108px}.forum-special-offer{background:#dd984f;border:2px solid #e0009e;color:#fff;font-weight:600;font-style:italic}.small-text-h5{font-size:16px}@media (max-width:768px){.small-text-h5{font-size:12px}.alert-info2{color:#31708f;padding:0;border-bottom:2px solid #615c5c}.form-post-top{font-size:12px}.panel-chart p{color:#0c00c3;font-size:12px}.col-md-12,.col-sm-12,.col-xs-12{padding-right:1px;padding-left:1px}}@media (max-width:767px){.nav.nav-pills.nav-justified{min-width:118px;display:flex}.btn-info{color:#fff;background-color:#897117;border-color:#6d736d;box-shadow:2px 3px #88888878;width:100%;margin-top:10px}input#btnSubmit{width:100%}.dropdown-menu li a{color:#f1eeee!important;padding:5px;margin-top:0}}.welcome h3{text-align:center!important;font-size:25px;color:red}
 
 


.well-sm{background-color:#6ff;color:red}.forum-special-offer{background-color:#fff;border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;box-shadow:0 2px 10px rgba(0,0,0,.3);overflow:hidden;max-width:470px;margin:0 auto 0;color:#000}.h4,.h5,.h6,h4,h5,h6{margin-top:0;margin-bottom:0}html{overflow-x:hidden;scroll-behavior:smooth}body{background-color:#fc9;text-align:center;padding:3px 0px;margin:0;scroll-behavior:smooth;font-family:Helvetica,sans-serif;font-weight:700;padding-bottom:90px}*{margin:0;padding:0;box-sizing:border-box}a,a:hover{text-decoration:none}.btn{display:inline-block;font-weight:400;color:#212529;text-align:center;vertical-align:middle;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:1px solid transparent;padding:.375rem .75rem;font-size:1rem;line-height:1.5;border-radius:.25rem}.forum-rules1 h4{background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);font-size:22px;padding:6px 5px 5px;color:#fff;background-color:#006064;box-shadow:0 0 10px -7px #000}.forum-rules1{border:2px solid #eb008b;border-radius:10px 0 10px 10px}.forum-rules div,.login-area,.para1 p{border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;overflow:hidden}.forum-rules h4,.login-area h4{background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);font-size:22px;padding:6px 5px 5px;color:#fff;background-color:#006064;box-shadow:0 0 10px -7px #000}.logo-div{border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;overflow:hidden}.logo-div img{width:180px;height:auto;margin-top:7px}.para1 p{line-height:1.4;font-size:14px;margin-top:5px;margin-bottom:5px;font-weight:600;border-radius:5px;padding:5px 10px}.para1 a{color:#e91e63}.forum-rules div{border-radius:10px;margin-top:5px}.forum-rules ul{list-style:none;text-align:left;padding:20px 20px 0}.forum-rules li{font-size:18px;text-shadow:1px 1px 2px #ffcad2;font-weight:600;word-spacing:2px;color:#000;padding-bottom:4px;font-family:monospace;margin-bottom:5px;border-bottom:1px solid #7a0029}.forum-rules p{margin-top:20px;font-size:13px;margin-bottom:10px}.forum-rules p span{color:#e91e63}.login-area{margin:10px 0;padding-bottom:10px}.login-area h2{margin-top:5px}.login-area .my-btn22{border:2px solid #219826;background-color:#4caf50;border-radius:15px 0;box-shadow:0 0 1px #000000d6;display:block;text-shadow:1px 1px 4px #333;padding:12px 0;text-align:center;color:#fff;font-size:18px;margin:15px auto;transition:ease-in-out all .3s;width:50%}.login-area a.btn-aa:hover{background-image:linear-gradient(-45deg,#9c27b0 50%,#9c27b0 50%);box-shadow:0 0 10px -3px #000;border-color:#0ff}.form-control{display:block;width:100%;height:calc(1.5em + .75rem + 2px);padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}.login-area select,.login-area textarea{display:block;margin:10px auto;width:95%;border:2px solid #f24790}.login-area select{padding:10px;height:auto}.login-area textarea{height:250px;font-size:17px}.login-area select:focus,.login-area select:hover,.login-area textarea:focus,.login-area textarea:hover{border:2px solid red;outline:0}.extra-feature h5{color:#e91e63;margin-bottom:10px}.extra-feature a{padding:3px 10px;box-shadow:0 0 10px -7px #000;transition:all .3s;color:#fff;font-size:15px}.extra-feature .btn-aa1{background-color:#9c27b0}.extra-feature .btn-bb1{background-color:#e91e63;margin-left:10px;margin-right:10px}.extra-feature .btn-cc1{background-color:#9c27b0}.extra-feature a:hover{box-shadow:0 0 10px -5px #000}.quote-card-div{margin-top:20px}.quote-card-div .my-card{margin-top:10px;overflow:hidden;border:2px inset #d00047;border-radius:5px;box-shadow:0 0 10px -5px #000;background-image:linear-gradient(45deg,#ffc58a 50%,transparent 50%)}.quote-card-div .card-head{display:flex;justify-content:space-between;padding:10px 13px;font-size:18px;background-color:#d00047;border-bottom:2px solid #d00047}.quote-card-div .card-head a{font-style:italic}.quote-card-div .card-head a:hover{text-decoration:underline}.quote-card-div .card-head h5{font-family:serif;letter-spacing:1px;font-size:12px;align-self:center}.quote-card-div .card-head a,.quote-card-div .card-head h5{text-shadow:1px 1px 2px #000;color:#fff}.quote-card-div .card-body{padding-top:0px}.card-body p{text-shadow:1px 1px 2px #ffcad2;padding-top:7px}.quote-card-div .card-body p:last-child{padding-bottom:10px;margin-top:6px}.quote-card-div .card-footer{display:flex;justify-content:space-around;border-top:2px solid #01514a}.quote-card-div .card-footer .card-btn{padding:8px 0;color:#000;text-shadow:1px 1px 2px #fff;width:100%;transition:all .3s}.quote-card-div .card-footer .btn-11{background-color:#00ff7f;border-right:1px solid #000}.quote-card-div .card-footer .btn-22{border-right:1px solid #000;background-color:#0ff}.quote-card-div .card-footer .btn-33{background-color:#87ceeb}.quote-card-div .card-footer .card-btn:hover{color:#000;text-shadow:1px 1px 2px #fff;background-color:#ff0}.page-no{margin:20px 0 5px}.page-no ul{display:flex;list-style:none;justify-content:center;border-radius:10px 0 10px 10px}.page-no li{display:block;width:29px;background-color:red;margin:0 3px;border-radius:10px}.page-no .active,.page-no li:hover{background-color:#900031}.page-no li a{color:#fff;line-height:2}.fixed-footer{padding:0;display:flex;position:fixed;bottom:0;left:0;width:100%;box-shadow:0 -2px 13px -3px #000}.fixed-footer>div{width:25%;padding:0}.fixed-footer a{background-color:#900031;display:flex;justify-content:center;align-items:center;color:#fff;border-left:1px solid #6f0026;transition:all .3s;flex-direction:column;padding:12px 0 6px}.fixed-footer>div:first-child a{border-left-width:0}.fixed-footer a:hover{color:#fff;background-color:#710027;text-shadow:1px 1px 2px #333}.fixed-footer a svg{margin-bottom:8px;font-size:24px}.fixed-footer a span{display:block}@media only screen and (max-width:768px){.login-area textarea:focus+.fixed-footer{display:none}}@media only screen and (max-width:500px){.fixed-footer a{font-size:12px}.page-no-ul li{padding:5px 8px;font-size:13px}.fixed-footer a svg{font-size:18px}}@media only screen and (max-width:375px){.fixed-footer a span{height:27px}}.switch{position:relative;display:inline-block;width:60px;height:34px}.switch input{opacity:0;width:0;height:0}.slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#df1f6d;-webkit-transition:.4s;transition:.4s}.slider:before{position:absolute;content:"";height:26px;width:26px;left:4px;bottom:4px;background-color:#fff;-webkit-transition:.4s;transition:.4s}input:checked+.slider{background-color:#2196f3}input:focus+.slider{box-shadow:0 0 1px #2196f3}input:checked+.slider:before{-webkit-transform:translateX(26px);-ms-transform:translateX(26px);transform:translateX(26px)}.slider.round{border-radius:34px}.slider.round:before{border-radius:50%}i.fa.fa-user.icon{padding-left:14px;position:absolute;padding-top:10px}i.fa.fa-key.icon{padding-left:14px;position:absolute;padding-top:10px}.panel-heading{color:#fff!important}.white{color:#fff}.modal-body{height:60vh;overflow-y:scroll;overflow-x:hidden;margin-top:10px}.modal-open{padding-right:0!important}.login-area input{display:block;margin:0 auto;width:95%;border:2px solid #f24790;font-size:17px}.btn-mahi{cursor:pointer;background-color:#e91e63;border:2px solid #e91e63;border-radius:4px;color:#fff;display:block;font-size:20px;padding:10px;margin-top:20px;width:100%;text-transform:uppercase;font-weight:700;display:block;margin:10px auto;width:95%;border:2px solid #f24790;font-size:17px}.btn-mahi:hover{color:#fff}:root{--success-color:#2ecc71;--error-color:#e74c3c}*{box-sizing:border-box}h2{text-align:center;margin:0 0 20px;color:#e91e63}.form{padding:30px 40px;width:inherit}#signup-form{background-color:#fff;border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;box-shadow:0 2px 10px rgba(0,0,0,.3);overflow:hidden;max-width:470px;margin:0 auto 0}.form-control{margin-bottom:10px;padding-bottom:10px;position:relative}.form-control label{color:#e91e63;display:block;margin-bottom:5px;font-weight:700;font-size:18px;margin:0 0 10px}.form-control input{border:1px solid #e91e63;border-radius:4px;display:block;width:100%;padding:10px;font-size:14px}.form-control input:focus{outline:0;border-color:#777}.form-control.success input{border-color:var(--success-color)}.form-control.error input{border-color:var(--error-color)}.form-control small{color:var(--error-color);position:absolute;bottom:0;left:0;visibility:hidden}.form-control.error small{visibility:visible}.form button{cursor:pointer;background-color:#e91e63;border:2px solid #e91e63;border-radius:4px;color:#fff;display:block;font-size:20px;padding:10px;margin-top:20px;width:100%;text-transform:uppercase;font-weight:700}.form_error{color:#d83d5a}input::-webkit-inner-spin-button,input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}input[type=date]{-moz-appearance:textfield}@media only screen and (max-width:768px){.container{width:580px}}@media only screen and (max-width:500px){.container{display:block;width:92%;justify-content:space-between}.form{padding:20px 25px;width:initial}}input.if_input_state:focus{outline:0;border-color:#777}.if_label_state{color:#777;display:block;margin-bottom:15px;margin-top:-10px}input#mobileno,select#scripts{border:2px solid #f0f0f0;border-radius:4px;display:block;width:100%;padding:10px 10px;font-size:14px}select#scripts{font-size:13px}input#mobileno:focus,select#scripts:focus{outline:0;border-color:#777}.dd-option.dd-option-selected{display:flex}ul.dd-options a{width:110px;overflow-x:hidden}ul.dd-options{width:100px!important;overflow-x:hidden}.dd-option.dd-option-selected li{width:110px}.dd-option-image,.dd-selected-image{width:30px!important;margin-top:3px;height:auto!important}a.dd-option{height:35px;padding:5px}#slick a.dd-selected{height:35px;padding:5px;display:flex}#slick{width:30%!important;float:left;z-index:7;margin-top:10px}.dd-selected-text{line-height:30px!important}.dd-select{width:90px!important}#mobileno{width:65%!important;margin-top:10px;float:right}.container{margin-bottom:300px}.dd-pointer.dd-pointer-down{visibility:hidden}.dateofbirth{margin-top:60px}.dd-selected{display:flex}.closebtn{margin-left:15px;color:#fff;font-weight:700;font-size:22px;line-height:20px}.closebtn:hover{color:#000}.mmm{text-align:center;margin-left:auto;margin-right:auto;background-color:#4caf50!important;border:2px solid #4caf50!important;border-radius:4px;color:#fff;display:block;font-size:16px;padding:10px;margin-top:20px;width:100%}.modal{display:none;position:fixed;z-index:1;padding-top:100px;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:#000;background-color:rgba(0,0,0,.4)}.modal-content{background-color:#fefefe;margin:auto;padding:20px;border:1px solid #888;width:20%}.close{color:#aaa;float:right;font-size:28px;font-weight:700}.close:focus,.close:hover{color:#000;text-decoration:none;cursor:pointer}.modal-content .modal-input{border:2px solid #f0f0f0;border-radius:4px;display:block;width:100%;padding:10px;font-size:14px;margin-right:10px;margin-left:10px}#myModal{z-index:9}.btn.btn-success{text-align:center;margin-left:auto;margin-right:auto;background-color:#4caf50!important;border:2px solid #4caf50!important;border-radius:4px;color:#fff;display:block;font-size:16px;padding:10px;margin-top:20px;width:100%}#slick2{width:120px!important}#slick2 .dd-selected{display:flex}.d-flex{display:flex}.modal-content{width:30%}@media only screen and (max-width:768px){.modal-content{width:50%}}@media only screen and (max-width:500px){.modal-content{width:75%}}.col-md-12,.col-sm-12,.col-xs-12{padding-right:5px;padding-left:5px}@media (max-width:768px){.col-md-10,.col-md-12,.col-sm-12,.col-xs-12{padding-right:0;padding-left:0}}.chart-00,.chart-11,.chart-22,.chart-33,.chart-44,.chart-55,.chart-66,.chart-77,.chart-88,.chart-99,.chat-05,.chat-16,.chat-27,.chat-38,.chat-49,.chat-50,.chat-61,.chat-72,.chat-83,.chat-94{color:red!important}.footer-btn{text-align:center;font-size:14px;padding:8px;display:grid;color:#414141;margin:5px}.footer-btn a{font-size:inherit;color:inherit;display:inherit;text-decoration:none}.container-fluid{padding-right:0!important;padding-left:0!important}


.well-sm {
    border-radius: 3px;
    border: 0px !important;
    box-shadow: none !important;
}
.well-sm {
    padding: 0px;
	margin: 0px 7px !important;
	background:#fff3e8;
	color: #564949;
}
</style><Style>
.admin_block a {
    background: white;
}

.form-group {
    margin-bottom: 0px;
}
</style>
</head>
<body id="bodyId">
<div class="container-fluid">
<div class="logo-div">
<a href="#">
<img src="images1/logo.webp" alt>
</a>
</div>
</div>

<div class="container-fluid">

<div class="para1">
<h1> Dpboss - Forum Rules</h1>
<p>
DpBoss Guesing | Satta Matka | Matka Result | Kalyan Matka | Dpboss | Sattamatka.Com | Satta Matka Guessing |
<a href="#" title="Satta matka chart">
Satta Matka Charts
</a>
| Kalyan Main Milan Matka Bazar| Matka Game |
<a href="#" title="Free Game Open To Close">
Fix Matka Number
</a>
| Free Open To Close 17 | Satta King | DpBoss Matka Guessing | Satta Matka 143 Guessing |
</p>
</div>
<div class="forum-rules">
<div>
<h4>Forum Rules</h4>
<ul>
<li>1. Don't Post Wrong Result.</li>
<li>2. Dont Post Mobile Number Or Any Other Website Link.</li>
<li>3. Post Your Guessing Daily.</li>
<li>4. Don't Post More Than 4 Single Dijit.</li>
<li>5. Don't Use Abbusive Language In Forum.</li>
</ul>
<p>Follow All These Other Wise Your ID &amp; IP Would Be <span>Blocked Permanently.</span></p>
</div>
</div>
</div>
<div style="clear: both">&nbsp;</div>

<center> <a href="https://matkabookings.com"><img src="https://spboss.in/images1/RS3.webp" alt="Online Matka Play"></a></center>
<div class="fixed-footer">
<div style="width:30%">
<a href="https://spboss.in/">
<i class="fa fa-home"></i>
<span>Go to Home</span>
</a>
</div>
<div style="width:40%">
<a href="https://matkabookings.com">
<i class="fa fa-android"></i>
<span>Matka Play (New)</span>
</a>
</div>
<div style="width:30%">
<a onClick="window.location.reload();" style="cursor: pointer;">
<i class="fa fa-refresh"></i>
<span>Refresh</span>
</a>
</div>
</div>

<script src="SITEURLjs/jquery.js"></script>

<script src="SITEURLjs/bootstrap.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="SITEURLjs/vendor/jquery-1.11.0.min.js"></script>
<script src="SITEURLjs/plugins.js"></script>
<script src="SITEURLjs/main.js"></script>
<script src="https://spboss.in/js/jquery.validate.min.js"></script>
</body>
</html>
