<!DOCTYPE html>
<html amp lang="en-in"><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
<title>Tara Mumbai Day Panel Chart | Tara Mumbai Day Panel Patti Panna Record: SPBOSS</title>
<meta name="description" content="Tara Mumbai Day Chart - Tara Mumbai Day Panel Chart Record Patti Panna Record Book By SPBOSS Net Online Live Update Fresh Tara Mumbai Day Matka Bazar 143 satta Matka Chart Final Game History See here!"/>
<link rel="canonical" href="https://spboss.in/panel/tara-mumbai-day.php"/>
<meta name="robots" content="follow, all">
<script type="application/ld+json">
	{
		"@context": "http://schema.org",
		"@type": "NewsArticle",
		"mainEntityOfPage":"https://spboss.in",
		"author": "spboss.in",
		"headline": "Open-source framework for publishing content",
		"datePublished": "2015-10-07T12:02:41Z",
		"dateModified":"2024-10-02T12:02:041Z",
		"image": [
			"logo.jpg"
		],
		"publisher": {
      "@type": "Organization",
      "name": "DPBOSS",
      "logo": {
        "@type": "ImageObject",
        "url": "https://spboss.in/logo.png"
      }
    }
	} 
</script>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<link rel="shortcut icon" href="https://spboss.in/fav/favicon.ico">
<style amp-custom>
html{scroll-behavior:smooth}
body{background-color: #fc9;
text-align: center;
font-weight: 700;
padding: 0;
font-family: Helvetica,sans-serif;}
.logo {
background: #fc9;
padding: 0 10px;
display: block;
color: #fff8f8 ;
margin-bottom: 5px;
letter-spacing: 1px;
font-weight: 700;
border: 3px solid #ff0016;
border-radius: .75em;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1);}
  .logo amp-img{width:220px;height:auto;padding:6px 0 0}
.button2{background-color:#a0d5ff;color:#220c82;padding:10px 30px;font-size:14px;margin: 0px 0px 5px 0px;border:2px solid #0000005c;font-weight:800;text-decoration: none;text-shadow:1px 1px #00bcd4;box-shadow:0 8px 10px 0 rgba(0,0,0,.2),0 6px 8px 0 rgba(0,0,0,.19);display:inline-block;transition:all .3s}.ad-div11{text-align:center;margin:0 0 10px}.chart-list{border:2px solid #eb008b;margin-bottom:2px;width:50%;margin:0 auto 10px;text-align:center;font-weight:600}.chart-list.ab1{border-color:#003c6c}.chart-list h4{color:#fff;padding:5px 10px 3px;font-size:24px;border-top-left-radius:7px;margin:0}.chart-list.ab1 h4{background-color:#024c88}.chart-list a{display:block;font-size:22px;padding:5px 7px 4px;text-decoration:none}.chart-list a:hover{text-decoration:none}.chart-list.ab1 a{border-bottom:2px solid #024c88;color:#003c6c}.chart-list a:hover{background-color:#fff;text-decoration:underline}@media only screen and (max-width:500px){.chart-list{width:95%}}footer{background-color:#fff;color:red;font-weight:bold;font-size:25px;text-decoration:none;border:4px groove purple;text-shadow:1px 1px gold;margin:3px}footer > div{border-bottom:2px solid #b2ddff;padding:10px 0;margin-bottom:10px}footer > div a{text-decoration:none}footer > div a:hover{text-decoration:none}footer .ftr-icon{text-decoration:none;font-size:35px;text-transform:uppercase;color:#007bff}footer p{margin:10px 0 10px;line-height:35px}footer p span{color:rgb(51,102,255)}
.panel.panel-info{border:1px solid #3f51b5;width:70%;margin:0 auto 0}.panel-heading h1{margin:0;padding:5px}table{border-collapse:collapse}table,th,td{border:1px solid #03a9f4a8}thead{background-color:#ffc107;text-shadow:1px 1px 2px #9a7400ab}tbody td{padding:5px 0;font-family:"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol"}@media only screen and (max-width:770px){.panel.panel-info{width:95%}}.r{color:red}tr td:nth-child(1){font-size:13px}tbody tr td:nth-child(2),tbody tr td:nth-child(5),tbody tr td:nth-child(8),tbody tr td:nth-child(11),tbody tr td:nth-child(14),tbody tr td:nth-child(17),tbody tr td:nth-child(20),tbody tr td:nth-child(23){border-right-width:0px;font-size:13px}tbody tr td:nth-child(3),tbody tr td:nth-child(6),tbody tr td:nth-child(9),tbody tr td:nth-child(12),tbody tr td:nth-child(15),tbody tr td:nth-child(18),tbody tr td:nth-child(21),tbody tr td:nth-child(24),tbody tr td:nth-child(27){border-left-width:0px;border-right-width:0px;font-size:23px}tbody tr td:nth-child(4),tbody tr td:nth-child(7),tbody tr td:nth-child(10),tbody tr td:nth-child(13),tbody tr td:nth-child(16),tbody tr td:nth-child(19),tbody tr td:nth-child(22),tbody tr td:nth-child(25),tbody tr td:nth-child(28){border-left-width:0px;font-size:13px}@media only screen and (max-width:500px){.panel.panel-info{width:99%}tbody tr td:nth-child(3),tbody tr td:nth-child(6),tbody tr td:nth-child(9),tbody tr td:nth-child(12),tbody tr td:nth-child(15),tbody tr td:nth-child(18),tbody tr td:nth-child(21),tbody tr td:nth-child(24),tbody tr td:nth-child(27){font-size:14px}tr td:nth-child(1),tbody tr td:nth-child(2),tbody tr td:nth-child(5),tbody tr td:nth-child(8),tbody tr td:nth-child(11),tbody tr td:nth-child(14),tbody tr td:nth-child(17),tbody tr td:nth-child(20),tbody tr td:nth-child(23),tbody tr td:nth-child(4),tbody tr td:nth-child(7),tbody tr td:nth-child(10),tbody tr td:nth-child(13),tbody tr td:nth-child(16),tbody tr td:nth-child(19),tbody tr td:nth-child(22),tbody tr td:nth-child(25),tbody tr td:nth-child(28){font-size:9px}th{font-size:11px}}thead tr th:nth-child(1){width:100px}@media only screen and (max-width:770px){tr td:nth-child(1){font-size:9px}tbody tr td:nth-child(3),tbody tr td:nth-child(6),tbody tr td:nth-child(9),tbody tr td:nth-child(12),tbody tr td:nth-child(15),tbody tr td:nth-child(18),tbody tr td:nth-child(21),tbody tr td:nth-child(24),tbody tr td:nth-child(27){border-left-width:0;border-right-width:0;font-size:16px}tbody tr td:nth-child(4),tbody tr td:nth-child(7),tbody tr td:nth-child(10),tbody tr td:nth-child(13),tbody tr td:nth-child(16),tbody tr td:nth-child(19),tbody tr td:nth-child(22),tbody tr td:nth-child(25),tbody tr td:nth-child(28){border-left-width:0;font-size:11px}tbody tr td:nth-child(2),tbody tr td:nth-child(5),tbody tr td:nth-child(8),tbody tr td:nth-child(11),tbody tr td:nth-child(14),tbody tr td:nth-child(17),tbody tr td:nth-child(20),tbody tr td:nth-child(23){border-right-width:0;font-size:11px}thead tr th:nth-child(1){width:55px}.panel.panel-info{width:99%}}
.css-11, .css-16, .css-22, .css-27, .css-33, .css-38, .css-44, .css-49, .css-50, .css-55, .css-61, .css-66, .css-72, .css-83, .css-88, .css-94, .css-99, .css-05, .css-00, .css-77, .css-star {
    color: red;
}
.chart-11,.chart-22,.chart-33,.chart-44,.chart-55,.chart-66,.chart-77,.chart-88,.chart-99,.chart-00,.chat-05,.chat-50,.chat-16,.chat-61,.chat-27,.chat-72,.chat-38,.chat-83,.chat-49,.chat-94{color:red}

.chart-05,.chart-50,.chart-16,.chart-61,.chart-27,.chart-72,.chart-38,.chart-83,.chart-49,.chart-94{color:red}
@media only screen and (max-width:770px){.panel.panel-info{width:99%}}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
.mp-btn {
  position: fixed;
  bottom: 9px;
  left: 5px;
  padding: 5px 8px;
  font-size: 15px;
  border: 1px solid #fff;
  text-decoration: none;
  background-color: #039;
  color: #fff;
}

.nd td:nth-child(2), .nd td:nth-child(4), .nd td:nth-child(5), .nd td:nth-child(7), .nd td:nth-child(8), .nd td:nth-child(10), .nd td:nth-child(11), .nd td:nth-child(13), .nd td:nth-child(14), .nd td:nth-child(16), .nd td:nth-child(17), .nd td:nth-child(19), .nd td:nth-child(20), .nd td:nth-child(22), .nd td:nth-child(23), .nd td:nth-child(25), .nd td:nth-child(26), .nd td:nth-child(28), .nd td:nth-child(29) {
  writing-mode: vertical-rl;
  text-orientation: upright;
}

.para3 {
  background: linear-gradient(187deg,#fc9 50%,#ffc387 50%);
  border: 2px solid #ff0016;
    border-top-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-left-style: solid;
  border-style: outset;
  margin-bottom: 3px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
}

.chart-h1{
background: #ff00a2;;
padding: 5px 10px;
text-shadow: 1px 1px 2px #000;
display: block;
color: #fff8f8;
margin-bottom: 3px;
letter-spacing: 1px;
font-weight: 700;
border: 2px solid #fff;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1) , background 150ms cubic-bezier(0,0,.58,1);
font-size: 18px;
margin: 3px 0px;
}

h1{
color: #fff8f8;
}

.logo img {
  margin: 5px 0px;
}

h3{font-size: 16px;color:#fff; text-shadow: 0px 0px;margin: 0px;padding: 5px;}

.chart-result {
  margin: 6px 2px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
  border: 1px solid black;
}
.chart-result div {
  font-size: 22px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
}

.chart-result span {
  color: #880e4f;
  text-shadow: 1px 1px 2px #ffe2c6;
  font-size: 21px;
}

.chart-result a {
  border: 1px solid #e6e6e6;
  background: #522f92;
  color: #fff;
  padding: 5px 7px;
  font-size: 12px;
  margin: 2px 0 -1px;
  display: inline-block;
  transition: all .3s;
  cursor: pointer;
  text-shadow: none;
  text-decoration: none;
}
@media screen and (max-width: 400px) {
.logo img {height: 60px;width: auto;max-width: 100%;}
}

@media screen and (max-width: 300px) {
.logo img {height: 40px;width: auto;max-width: 100%;}
}

.pnc-div{}.pn-chat-h2{font-size:18px;color:#00094d;text-shadow:1px 1px 2px #fff;margin:5px;}.pn-chart-p{font-size:13px;font-weight:400;margin:0 0 10px;padding:0 10px 0;}.chart-p-faq{font-size:14px;outline:4px #fff;outline-offset:-9px;border:2px solid #5c3411;border-style:outset;border-radius:0;padding:0;width:50%;margin:auto;}.p-faq-title{background:#5c3411;padding:5px 10px;text-shadow:1px 1px 2px #000;display:block;color:#fff;margin-bottom:3px;letter-spacing:1px;font-weight:700;margin:0 0 5px;font-size:18px;}.p-faq-sub-title{cursor:pointer;color:#0013a5;text-shadow:1px 1px 2px #fff;font-weight:800;font-size:15px;}.p-faq-p{color:#000;font-weight:700;margin:0;font-size:12px;font-style:normal;padding:0 10px 5px;opacity:.9;}@media only screen and (max-width:770px){.chart-p-faq{width:100%}}
</style></head>
<body>
<div class="logo" style="box-shadow: 0 8px 0px -3px #ff9628;">
<a href="https://spboss.in/">
<img src=" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkgAAACSCAYAAAC+JDXPAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAALNNJREFUeJztnQuQXcWZ3xtsnsaAMcYUZvGYsDZhgcWUVsXykGeBZVmiJZiwlEzAUQixWUdxFIqiKEKxE4LlmTsUhQnLqjAhUxizKpeCCSsDy1JIGDAPiVdkjLEAScYg3XsQj+VpcJXy/XXOXa6v76O/73SfPlf6/6r+hTEzp7/umTn93e7v4RwhhBBCCCGEEEIIIaTGtNz0ji3XODhzjRMzNz1fNCFaLLpedLvori7dVvz3q0QXiebJ9x8hz9kt9VwIIYQQQkxkW5yh6QWiGdGTol+LNgfSc6I7RJeJ0zSHThMhhBBCaknTNXYQp+hfirPyVXFclohWi94O6BT10geiF0QPii4VZ+lYsWPX1GtBCCGEkG0ccYgOLJwinOhsjOwQDdO7okdEDdEfwWlLvT6EEEII2YYQB+Rw0Q2i9Ymdon56VfQ9cd5OQfxT6vUihBBCyFZM5hq7i+PxTdGaGjhBPspEC1KvGyGEEEK2Qta5ie3F0Zgner4GTo9F92x0kzunXkdCCCGEbCW03PRRWR7bk9rJKatlov1SrychhBBCRhxxKC6tgWMTUrxuI4QQQoiNjW5yx5abvlAcijdq4NSE1HWp15YQQgghI0jLNQ4SR+KHNXBmYmhZ6vUlhBBCyIhROEf318CRiaUbUq8xIYQQQkaIpmvskeV90FI7MTF1Zep1JoQQQsiIgBR4cR6urYEDE1sLU681IYQQQkYEcRyW1sB5qUJzU681IYQQQkYAcRrOr4HjUoVQVXt26vUmhBBCSM1pucae4jQ8WwPnpQrdnbnG76Vec0IIIYTUHHEarqvYSXlX9IxoeZbHPKEQ5cIsb2MiaiyQf14sukb0I9FKUTPE2OIMLnrJfYuNawkhhBDSH3EazhD9ugKn6H3RKjg+4qQc23RT+/ra2HLTu8n3HSI6uXCoVlttlmedHHM9CSGEEDLiZK7xKXEaflqBc/SOOEWXiD4Zwm55zt7yzLmZoZBl0zV2DWEDIYQQQrZSxGE4uwLn6B5xxA6JOIcjRbeIXvOxJZYdhBBCCNkKKK6tVsZ0jmSMmYrng7ilNwfYdFpV9hBCCCFkBBFn4SRrHI+nbk4xr2Z+/Xa1aFOXPStS2EMIIYSQEUIchkZE5+hXLdc4MN3cGrvL+H8hdtyR5eULVrfc9NGp7CGEEELICNB0jU+I0/BkJOeoJRpPPUcg89xBnKX9RHuntoUQQgghNUccmONE70VykP625aY/knqOhBBCCCEqsnhtRd4RfSn1/AghhBBC1IgTsySSg/R0yzX2ST0/QgghhBAVG90k+q49FMlBWpp6ftsSL7tvIxh9XNb9ItGVWH/RXVlesRwFQO8p/n1J8d8XtNzUofI7sHNq2wkhhJBagTYfslE+H8lBujj1/Kqg5aZ3bG1pfdI4Mcv7x10omugS/r95WG/52r1Cjd10jVlZXsbg0cxepgG98G6HfU0GsBNCCCFbrtfOEr0SyUGal3p+MRFn53Pi7Exng4tR9hMcmjkb3eT2+nGn95CxzyhOg0L/zDa1tjhy02zgSwghZNsly6tNf0AHSYc4EKfJ/J4ouT7rRQf7jilfi6KX54geyOJlHUI4ibpVnLCDxYH7aMx1JIQQQmqJbIRXRNxoz0o9v1jI3NYGWqPxYWPhSi7Lr+hWi96P+PPq1gbRX4s+VsGSEkIIIfVBNr/r4m2wjQtSzy8GhcMSYo1eF31x0FhN1zhAvuapCp2ibr0v8/0fVa0tIYQQUgtkA1wccXPdKrPYimDsEOvzdMtN9SyDgMyylmtcLl+TJXSO2npXnKTzq15nQgghJBmRHaS1srGOpZ5jaLL8uivE+tzfK8ZHHKOxLE/JT+0Ydept0ddSrDchhBBSObLpTUbeWC9NPcfQZOEKa17Z/Wxxjk7K8tif1A5RT4l9p6VYc0IIIaRSsrxGT8xN9Veiw1PPMyQyn5+FcTamz+18Lv49tQPkoadZAoAQQshWT5Zvyq9H3lR/3nRT+6eeawjgHGT2goydQjbalzqee6b8+xs1cIB8HLv5CX8EhBBCSHxkw5sjeqGCjfVh2Vj3TT3fsmSuMTvQevxS1uNf4Jnyz+NHxTkq9HzTNXZN/bPYRtlJtJtoD9F+hXYrtFNCu0Kyi8vn8ynR/u7D+dUZnKrCRlTJh817Fv/+kZRGEUJKIJsz0sgfr+jkYcVGN1n3F91AsnDXYI+jIrasB0oGNGvg9Gh/lqen/llsI2DDPUPUEC0X/US0UvS46NlCKwvhv/296LLie4K1tIkMnIvj3YdzfNjl8/mpaI37cH74b9eJvuxyJyolsPkI0X9z+Zo/6HIbn3K5zU8U//5j0Q0iJDiMys+DENJGNrzbKtxcn8hc45DUc7aS5U1eQ6wD1nwf0dOpnR2jlrZco2eJAgOoJj4pWhxI1xXPm3C5o3Ckyz/RjwI4fUBs2hLRL0SbS+pJl68JqtrX6cMJfuZw5FaI3nT2uV0tmlWRzehTiHIXd5W0eUY0VzSKTaLPc/nv5irRz0XrXT6vN4t/h1N7m+gKUdn3w47FeNe64X/zSHjBh7YqTrbhGC8SoYzNAy6fd1tw7jF/vIP+rAJbSGxko1tY8eaKlPErRvGaJsvbfJReg5abvkz+eX0NHJ0yOqPkcuLnD0emrBPgK5y24MWFl26dnAXYgo0Xm07M+WMTw2ZyYjXT+h0wzwtFDw2w0arnRMiY3T2wzdikz4xkM5yLq1zuFNcd/Oy0f6vXlhhvvug15XjQapc7MLE4WGHLqoh2kKqQje7ILE0MzEOio1LPX0Nma0zbS9cUjmJqJ6eMbi65nHAKqnKOejkLeOHvXXIOZUB2JxwWy0ZQVjgFGYs+ww+BU5oFnkMvPSMK9U6BzY9VYDN+F88OZHMscOqP0yHNvC40jnWys5/QtXWocexhLFTYQAdpawBxQbLZPZhok0UG3VVo35F6HYYhNh4RaM7viF6qgYNTVk/ImlivrhC8iviMqh2Dbm0Q/UfRDsZ5WED8zALR6wHnYdEm0RyXn5LE4guieyue1yOunOOLU6iZim3eXNLm2Jzk9POZaxhne5dfUZVdyyWGsX24UWHD30aygVSNbHYXJd5s0W/sTNlwUwdf9iVzjYtr4JR0613RetGaQvjfVTW0fUV0mHE5P+PCxNiE0Fuiy101gb+43kKcwnsVzm+QcKqDXnsx5g7na3WCOcHptRY0Rabt3Qls3lzC5irQnJxAr4r+0DAO1v8Z5Vi99LboAMP4w3hYYcNXIoxPUoCUc9nsfpl4s0d9oXtbrvFlcUZqlbIs6/MRse0fauAQQSi++XeiBaKjZK0OFO1fSP739AmtvB3Ks7FtKZHNhsDassfoIQWH5WIX7zQF8VaX1mzOnXNHUG3IvzmcHrQDeKvWRpcH7Fpsjh0HNkh1zgy9yenmAifHUtYl5HvhEsP4g8C74V3Psd93eXII2RpY5ya2k83u2zXY/CFcQX1PHKUjevUqS4HYI87HlhOalOvyAn5Gsi5fgMPmYfN+oqWRbZowLulZLr1j0K1XXB4XFRqclv2gBvMbpHdEXw80X8TupHKOIATjazPbjk1s82aDzVWBAG2ULNDMBadwlhpQId8LKw3jD+IIxdhIGtgv8PgkJbLxIlh7Uw0cpLZQEuC81OsCxBYUiEwZVP2ArMUccWS319iN4pzyvS9GtGupcUlxYpFyM+qnNcb59AOpzktrMC8fPe3KB7ciI2tD4nk85nSZYYg5uiOxzZuVNlcJrqqed7q5WDPYQr8XQpb3OEMxLuLganULQgIgG978GjhGv+MctNxUrKwEL8R5PCPV/MXJubik7SdmeWxSDPseNPZmW+bSb0j9NG6YTy9wxaCJWaiDHig55xUBbPi1yz+Bt2vLaLPfblPaPBHAZmhdh83a06jXlDZXCbICfa+W2rJ+sA39Xgj1ARvvuCsV41o/OJK6Ixve1TVwinrp+qabSnJsKWNPJpjvilagMgjynCsi2bg6cw1t9g2+Xhu8i4KAEwOEwm0zLj8FKftSvVI5n14gKzNU9hZOZJYU80QRyXkdWljYu8LlgakhxjvZOOf5JcbEyR2uN1Fnpte1Oq55EPSN4pJPDXnWQoXNuNbaZLQZ34fgfly99Cr6iE11tsvT3e8Z8iytU1clcDI06wJnz/Lews8+dFD/MoMdvcAp2rCfYacWBBqX1I0i7X9DDRyiXsJJyOwq1wPxWXBWKp7nKnFqPhNqDvK8o7MwTXa79bw4SNpskT9w8Nl0LzrNKdUfu9yh+LVyjLbuUc6nGwRk/41x7Lbwif1Rlx/r+4L+bHAkXyk59h2GOSPexOqcLjaMhdYkqOXU/TNGwPkfez4H19X3lbBZG4R8RGHzqz2ed4HyWVWCYpaatUH5js8ZxkFBTu17wUchisLCkdZcHZ8UYExSV2RzHs/q20AVMTXntVyjkvYRTTe5Z7YlHqqy+a2W9Q8asIm2IFmctiboI6dtHYOXx2+c/8vmWcOU4VB9w+mvBqCfGsbrBCc6bxnGhbAuuOY6VfQxw9hwHo5x+qyjTmHNtKeC5xjG+SfRf3H2lhtwRLFOnfW0EBzsu25zDDZDV5W0GQ7c910eGI/n4cQlVNue0OD3SVv2AM6jxSmZcLr3gq9COJ/zFOPhfWUtf0JGBdmkz8y2XKEkd4h6CfV/VrQq6Osm4xyW5TV/qpjXqtDOEdjoJreXZ98ZwV4U+vyi0pzvON0L7sYSU79BORb08xLjoZaN9eSqKfrPok+WGL8NHMSrjXZA5yrG+oTLe4xpno+NEGUPQnS7R5A1UvRxzXq44vssTiRO10KUgkAA7wkud7YsBRWrwlKXSPO700msQHk0Di77YVrTZmUmwHhkFMBmXWMnCXoJQchx16Axt6K5PBryWq2bLFyj3W6NK01BAK7mBVcm9X62cqwyDhJOXawZXIjBCV03Bacc1k1HU4n4OKcvfPkz0afLTK4kiHN6o4ddw6RxwLYG8OFHW/Hd2gvN92/nPaf7fcPPuUxYhvYUDUk125UYj4wSsgGentUr/b9ba8WxOCje/BsLKprHsbHmkM9jOlYl8HGFGTh6125KZRzgvQ3jWa/YLjaMBaEwXqyehCcbbdKswXzD88v28SvLmNPb/GIKQxOD0y3tOlmu1zTvBZxWrlHaVOZDljapxJrkQEaVlmvgJGlVDZyhfnoRV4Ix5p7FL7ZYOpXfB/kZnl0DBwnOThUv3DYWh8ySUYSrXmsF4NgtJm432uUbZ2O5ytMEn8fgNKe3uUx3+lEF16CaNbJ+uNC8F65x+n5tCI63Fh3GqaEm07HOPfVITIoWFqmdoX56Q+wLmj3wslu0qzz3kch2l82a8kLGmVcDBwkpz5oX23Mlpz2mHA/SpvlbyhZAOPqvov/WuLPFRfnWHltuePZ42UmVZMLpbZ5IYGdqtI6I9WRQ815ACr2maCOE+D5rvKrmFC0zjkG2FlqucbJsilkNHKJeWtN0U2Oh5pq5xpg8c21Ee9/JKgg0z+dSCwdpxulebGXrw1iumE5VjnG+YQyLI2ZlTLTWYN+4x7MRn9GZRTYqDtIiRwdpGCgb8bjTrZH1JHxGMQZ61qG5sjZD9WyjbZcpxrjdOAbZmiiCt3+Yb/DJnaJu3RCqBIA86zjR+5HsfE9UWf2TSA7SW6I/UpihzXaaKDnty5Xj4aWr+d3B1z6oHANCKnC0uLkukPb+qMHGeR7PtvTpKrNZhWKx09t8QxJL04HfT8RdadbIGn/j+15AE9hjiu9ZobTtFpfXvtKyRDFGVR96SN3JXGMncUS+nFVbI8hHKAFwXYg5yvxitl5ZJo7mLiHs9CGSg4STRN+rGKRHa696ylxBYbxnleNpWwRY0vqR4v6f7NMycafSRl8HCb+/lnYqsMdaSygE1/Sxa5BQr2hbSt/+U9EHTrdG2uKZQPNeWOc+LEKpOdmBXhB9Vmnbx0WrFGOcpXw+2dpp5V3jL8q2VFVO7hy19Ws0dy07N3nO9ZHse1V0zHALwiHjLYwwDxTt9D0JsaTcl2ktc65yLNR70WQS4sVucTxw4vKpEvOycL3BTh8HCSw3PBsndSjkaflEH4KJIfb104yzB/uOGpraP9B64zia9wL+dnYzfB+EDyb/Xmkb2p9oSneMKZ9PthXEUTpWNstnauActaWp5fI7rHMTH5Vn3BfJtjuarrFrqLX3IYuT5r9GHFHfLuS4VtG80DaVmC5OJ7QF7q5QjvF50UvKMaAUfZosV0q+DtJSw7MhXN9Ya+aUZYGnjb1URWB9HdD2ErQmm2jeC8s7vm9npX2bizlpONrpToi3FeeZWClOKmJ1j1dJnJCDrfNoualDszjtOd4WHR9yzX3I4jQhfqLpH++l6YYN3WKcKo75b1aOhSw0bXruQuUY0JPGOZUlpoOkzUzsVpkaNVZmlbC3bfPulVtdHZbyGNb4G817oXuMuwx2avYETQLGw4rnkm0ZnI7I5okCi6kLTM5Y51DY/3YEm+7Y6CYrj7/I4tRzul/m4vupCT3GNC+y0w3THHf6kyOkAGsr7cKZekQ5DnSeYU4hiOkg4VrS0vOuU8hWtMSvWMHv7GslbX7M5ScMWyP4mWrXw1rbSvNemN/1vZaTwEsVtmlaFW2LdbJIGTa6KTRJvUL0WionSZw1U+GulmtcG8meA0Kv8/C5TO8oYz8YYT6aoGZNIUVN3RJsdog3m3H6gOnVxfdqOV85n83F16cK8rVcg417PtuaydYtOCy45qyqcavFaewWHEMkhJhPqmuK5XTUmpXp+3eEte6uOL+/wU7fYpaIMdRkqKa4OiejDjK1ZCM9I0sWn9SwnETgxOXuCPY8FHp9fWi5qb1k7KcizMf3WB3B1pqXWMvljVvnDRBOY7Chot8YMlS0ncARPwTnaAfDkloanWrjH0KyfIBd/aRpmvxXhuf3Enps4doECQwhGtkO4qSANsPRRiX/EI1s64DWeYTzYpn7FxRjvFx8fScI8l+rtBUfonxOK9EX8xeK526tp4mkClqusa9sqDNZ9bWTZppuSvXJfZ2b2D6LcL0mzuL8SMs7EBn7oCzPOAu9tr7xI5bWDjGFTdhaoBMnVpbg7G8YxyuLNRVfk0EIZ2a5YYx+ekX0fRe+gW8n2FxnAtqMjff2wuadItpdBdrfF2v8jaZ/IdLtP97jGZaSDT7vLXxA0JwSl2mJRAiu3CaRGfYXWbWnSWhmq8qWabrJsQh2vCvzT3LFImN/KQtf8PI3ohM8TZhw1Tg+g4RP+si0wcuxzMvsCOP4B5YYswy4snra08ZOaTNysC5l43q6hUxGbKKxAqJxkvBQBJu/69L9vMuCkyBtTNliwzhwqv9BMUa/rOQ5Slshn9Pcryue96zvpAkZijgsp8rm2qzQSZqrsU++/uQINqyKtZ7DaLlGjCKRiCvzdTw11WhjCJtWqPgWS2uRlD2aLBWRrfZqMxV9hefG+oSOq7G3I9i8zI1mXRz8vmjmCWdqoWEcbQ/DfmU4kPCiaSYLvemGFyq9RfE8bYFZQgYjTtKcCp0kTeYCHKQrItgwGWstPeZzZYT5PN1yU74OB5rOxnJ+fIXsNvTgGjcvZM61hrFL1eQqCQJbtScCK0qMN2MYz0dw2mLVIDo/os3nRrI5FtpGsM87XYHVNoc7nWMz6EPupUqbN7vhWXca27Q11AgZTuYaCN7eUIGDpOqjlEVJiW+MR1rGgYgjulsWJ4PtPsRqeZiwl4vn9Fi1wtkzjzStB9qyfMIOxTcG2NVPV5ccEwH02iw/H8GJiVU3CTZrqiZrNBPJ5hhoTwGR6WU53ZurGAMfsA4f8CzEEzaVdg/60HKo4jk4nbX2oCNkMLLRjlfgIC1X2pSFtiFF7aN8Lg2s79oIa+p7IvY1F2fTKSts4DiR0MbaWMayfMIOhaWYXoiUZRRD1fbC8xGcpIkA9vUCaeMrItgMzUSyOTSI09PMy1r/5wrFGHBmBpVrwd+w9vccf//9HLv5iuc8MsQ2QuxErNHTqRXr3MR2Pva85L61W4Tx18Rex37I2JdkW3rTBZ+Tb2NGTbG1qoVPf5oCd/sax6myCGInCLi1nOSESFlGEO6fuLDZbZ2bW6zrtjGXF64MbfO7hc11LwWAnmqaeVlPRzVxiRNueNkHbfNa6Jw+z5pQPANlRlL1FCTbAi3XODWyg/SIb++zzDWOjjB+shgUGfveCPN5VnSYx/DabtgphBgK35R/S8bM657PjoHFXmzkIU878Skd11drDbYMEuJ7yjQzHsTOhc2o8qytrzXM5jr3ctN+APjA5SeFWrTvBZ81QzX8N5T2I5ut1+/6MsUzLlHMmxA9uH7K4rT1aGslYnF8bMniNHVN8keEsgIy9rsR5nO9OJK9apJ0o+2G/b7o/7g8bXiYkDlyv8uDr99RjNFLNzq/q7ZzDc++3eO5sbh8gF39tCKSLWMuX+dfGmzqJ0t6uYZPunwDDGnzT0SfiGy3lVOcbi44gbVU0Na+F3wcYbzfNZWvIQRi98rE1ZyiqTKkCTEhm+7DER2kh3xjgCK1GEkSxNeKU64A8g2U1XbDRgHGzyumiJ8pXnAXuHL1bHAFur/HeBOGZ6fs0aSNJ4HKBmgPAk4oNpSnDHb1Ek5kYhfo276w2RLL1UsoKVB5s2pPtI2H8XPcyzCO5r3wpuK5lgzTs7ueoWnUi5+lto8jIXpk010S0UFarrAjuKP2sluUJIhPxr4hxno23ZSPMwG0NYPQANRaFBAb2XynP2ZvyycWyfICTlVBe2+FjZ0ar8A2XHd/04UpLBkrq60X+KCzNoDNKcs+9AO/L9p6ZbcZx9K8Fx5QPBeOp7YfI054O2OINIVgUYC1qt6BZFtGNt7FER0krz/kdW5ixwhjr4+9dr0o0vvfjDAf32aPQBugfVOAqeMToWXj9TnpmTE819QLMACWTudYN21WXxlw+lA2iP+eCu0FuxU2lyljgLi3yptWDwFp9Np6Zar6ch1ofua+/R6BtvgkhPdzZ9Vzzd8NA7RJNWRxT5C8rg1abur40GO3XOPy2GvXCxn7vEhr6ftS1HbDhk4NMHWMaykcd58b7hxYrlnGA8zJwpOe9nVKVS8sIBZnri3NFUxIcFqhrb3TFk456tbcVFOXqC1L/I32vdB9BTYMSzZb5+mxpg4UC0SSapCN956IDtJFnjZ8O/C4vxEH6V/HXrs+c7kjxlrKfOZ4mqDthr25+J4QzFaOC/nUMxkVBwlxXNqrhpZoXgJbAa7cNK0dupXiNGYHl8e+vWewt3tTrgN4R2rsR3bmFw3jaN8L2hgfS6/Eqzq+X1PiwbfUCSHlkM13fSwHSTb1oWmiL7lvxajHtCFzDWvFZjMtN314Fqf20YtoOOxpBoojajbpkLWidlSM29ZKN7xe0Sg4SMguvNpgJ64LvEphRALXbY/2sMtH/yqBvWAX0fc9bezWBQnsHYQ2/gjZo5b6XrOc//Uk3h+WulErlXPB793Hiu993vN73izmQkhcxIHZP5ZzJFrb8miqKo7M78nXPhd47FWe6fDBkDE/kUUKzpZ11MQDzHe6l9StIddBOXZMB+mEgHPy4ctOH6j+fvF9qcHppCXIPuVpDK7KtM2AoYtTGNsHS72yu93w4o29OEsxxpPG+VyinMuroj90+QcE3+/BKVioE29C+iOb71cjOki3Nl3j0x42HCN6P/TYVaxfJ+LEfCWLVFNK1lFz3K09xVgUcBk0qbpt/dgN/7RqcZC+Gm5aQ8GJhiW1H4GtdWiXgL/Tn7nRcpBg86197BoVB+n3Rb9yOvuv6vmk4TQUY8wYxzhEMUbn36nmeg7vC4uDSIgO2Xxvi+UgicNwoU9T1VbeODfw+I1Kg/hkvN1l3B9HWsunFaZgvRH0nGqTO1g5NrTU47kWB8m3Z10IcJVs6UpvzUYKDRxb7fUIlLKuEGxe3MeuQQrR7y4U2npl0HnGsTRVqi80jgG0p3o3O12geqqEBrIt0XJTh8ZyjnIHyS8GSL52MsL4lRYJlPEWRlrHt2UdNZsQaoPAodK8oCwVefthyYry+UR/s+G5VZV5QLVhS3NY3yKZVbCn6Amnn0OqXncANs/0sGmY6tRyRFuvDOUgjjKMg3exJg3/ROuEnP4EGzFVmgDtKutvkRAggFY2swnRT7Mt8S/TF/q22EiB2DcmWhHRQfKq2YMTJvna+yKM/6Y4FpXUwZFxEJjdjLSO9/r2sivAVRyqzGpeuKEYc/qO7Pj07OMAalKAOzVWfloDwc/mB0bbynxKDw2cZO0n/yyJpR8Cmx92OpvrVoFZW4sKxRsP7PmkwSBlf5NinDJ71yzFOFrVsUwDGYZsZCeJ3uj85C/6gejPZIPbIbV9ncAesWtRFifbqi2v+kfNvGfZE5FseEGcl7GYaylO8C6i70Zcx28qTdLWVHk42GI49++czjmDuovF9UObCt3W14LMrDfIKvyvorcMdqGXnaa1S2zQCwwB45o53JvE0g/5U6f/fXtB9NkUxvYAcTTauLXrXR7YrWXC+Tf/fc44nzZoQ2Stqj9M6CNXeXYyKUHmGtjk7++zwb0l+p+yUVu8/uBsdJM4sfkPhV2xNnXEHx3qY4987WGiVyLa8oDYYulZNBSc7LTy+k3vRbL9eZG2zow2iyRU09Exp6+kCyFV2yfgco7h2RB6VsVIoYdzZD3Vwqbue02CtUEQd8wyAHg2Ws1o5zEofgo27xHP5C21kL6ntBe60+kqlmMeqDk07vJiqvOK/z3blQ+ut9Qrs14v3aEY4zvGMTq5STGeRsj4qzQ7mZREnJ9Ts+GnMWtFDdlQQ8Z7KO2c3lFsPT/77ZOuGPpHf5sacyPbAt0R2kkqrlSviWy3NoAXAdqaFyF0boDlQBzKncpxoXdcfgrgA478LUHQUMgsvbYtlnpHbTUUY33d5Y4nimkimN5Sm2YYi5xtHv0+yc8qbH7c5fFlMT6goDSC5eTO18FALB+C/DGP13s85+3iv2HtrHFkmrpEbVmvBzd4Ph+nTCcZx+jEUh3cRwzQHjVkI7tRsem9KJt1kiyKzDWuziKloXfKpzhkh00XVOAgQUGbVMrP8PLI9v5K1ub3lWYhWFhbU6VsPAachR8qx2zrJ6KdFGNp403agmN1sn2Kv8UXnC21vC1cKfrGd8DxfKZrHtggQtaAme1sjucTA57ZGXD7gcuvkULajGf9P4PNmuuZexXP/TvjPE43zMHiIO+leD6quv+BcT6d7KwYU6NzAthGqgIxLpkthgad6y9uusko1z9dNh4hYz1QkSOiqsosX7+0Iru2rDnWosxaitOyN0oIVGCrJUUdToA20LZMMCYCP9cox2sLn5zPVI5n6fPWFoLRcZphnS82JsQzZSVsgDQ9tE7r8wwE22ItdjfOpc24szUXhvqdxOw5wGY4d2Wz9mCzteo3WqoMKzuCn/N1yuf6xtF1c4VyHGts0ImKMULW5bpKMa6vou+XJCCykS3Iyp3KoOv7kpabPjNk1hviY+S5uL6K2Yi2W8jk8q6p87JbBBsfqdC+9npfjrpFmvVEtp04V2dmW1qYRLfxnpY+9ghoX7hemYYd4OWEjDNkX61VjtUtnKJqPw3vX3JMCO0MEKflu6HhGgRXYpY0/k4haFVboHBYjR8880aXO8a+cTX4ZI+TC0tdqbbWDBhvnsf3o+4V3hN7etoMELOlbcnRbfORnuNor72smVWaukSbi/lbuFAxxjLjGL3AeocM1i4bPE6qRjazmwNv3ijcuEA24/Gmm/L2lmUD/2hR1+hc0U1Z/DijXlqoXLuDRC8msLMtOI9nbHSTfV/U6OcmX3NhVqEjh5+jZh07wMajeeFgI/i5p7TZQoN0m3F+oMwm2S2cBuH6Z3GX4HSscPbTlW7hCkvbGV3beR22Yl0RG4WMv3kdgjOKgHL8foTYsMYH2KwJXMe6rChsnuiyGbFxiwqbLe1EfG3uxhp47/v8Njil0SY1WMtCaP5mQhbYhTP+kGLsYQoaJkEqQDa0xyNskjiRWpvl13AoFbBYdDEkjtPZ8s958s/ziv/vsizv/4VaQk+LXk/kbKzWptTL9xyXhW8xohVOvR4S/Uh0ZXuds7x4Ja7/VoveqdCeZT7Vx/tQ9pSjCmGzK5Omi2w236aWdRBicOB0aU+HLRlObSFdP+tQKOcWz/0b1//kDzZrkwQ61Wlzr8Boq24fYHMniIfTxB51rssxHs/vBH8DvoHTbVkLXD6pGOMs4xj9sDqcvTQR2DYSE2SFZXFrCY2KUJTxVP36NebXwPY6aVOJuk2WHmhV6yVnqwLczV+J3qvBfIYJNk45W9wTYuVCnWCF0v9yH3Ze72fz2hrY2SmUedhn4Ep/yJjRfvxea2taIVPMty5RW/spxwBwDH1bmeBEeZZhjEEcrxh/mOpUAZ0MA7V+arCpphZOu/4aae/a9ZPvu74G9tdJ2muYThADkXoz6id8wkbm1+El5tcJGsN+twbzGiScDpxT2GphvAZz6BTKOAxzNOpmM1ruHDLE5k5wCqQtlgmhnIG25tN3lGNsUD6/zWzFGDixDJltCCxXif1kcRBJKmRDO60Gm2pStfIrvkGfKnuyzk3g9C1Wc9dR1J0lrtaAtdJ0FcK1jPp3ZAhIgdf2nKtK2MzKOoPjNZhHW4gD8slsqpPNCEL3PTlqY0m7h25VjgO0ToO1avm5ijF+7PyKtmrRtlPppU0R7CIxyeI1KB0VPYTgcMvaFQHlT9dgDnXQPQFaoqA5b+pNqddLDS9o0++IBwhmt9TDiSUEHWNjDtGAFll262swJ03QLmx+oAY2I1jdkqruk4HXS9rq1pbr8CsN83FOFwMUqwjjGQob+umBSLaRWGRxutCPih7a6CZ3LrF2ZcsjbC1a03LTITbUMmnboYVA7PMCzMmXyUjz0Gi5CxNf1QlONDQNRkNqjXE+Bzl7bawQNpdxyC0OkiX+SFOXqC3r9bvGYbW2MRkGsrGfUtjRS3Vq7Ex8yPKsp9Qb7Mg5R6DlGtfWYB6ptaFs4coOtDVVQgtO0TVOVwgxJAguRaXtUAGhvkKGFOoQlbkeHcSYy09xtLV5rEJpATgKZU79di5srsq5w+/e+SVtBpbWH9raVkBTl6gta+an73ystZx8QSyYNekAjm+wGoGkIrI8HTz1Jlul3mu56f8eaO1W1GA+KdWUtfw3IdayACc2VToG7V5Uf+/i9QizgN5u2ORjZbkh86jp8rgcSzFPKwcUY8bIbMPVIAKNkR0YMgYFgcvI4otxVYjyCYhBQ9XrUL97CKjXnMRa6/JoU9+bxnE0LUZwVR06QLsbVKLXlpzACVjZdkgkBfLp/+gabLRV6Z+yLXWYpq1ZOf8MgpGzbft6Dc7RnKZr7BDi97AAn55xDH+9y697Qupml9fymXC5I4ZTohDdzGOBjflPRJeJ7nd53SRro1sIQddwIGZEf+nyT8Ox4qoGgTFx4jhf9H2XO6ivOP18kKm11uVF/HDSc6zTZ2H5gpO1AwubESe30uUbvuXn8GJhM34X8TuoDcL2ASc16K2GU4vu3xk4x+hV9pgr14QX2Viozo4ipU8VY3UK2WT4fbvb5VXfywT842TtvmKcX3SN80Tx39C2xqfKeAiQ9o/fA7xXcOK7sofQmBmOKgoPM3NtVCk2+ttF79Vg040pFFL8c9nUg3y6bLrJsQg2olBmswZrNUxrxLGu6mVEcqcCpy+Ip8FJ1wUur9yMTbaXM/gD99vO4LjLN81YDoSV7VzuoB7mcmcBmwk2npvc784JQcvtOcGJPs7lV3elrsmN4KoEDibqAGHzxmlKL5tRVgDO/kTxdYjbQXxTVTYjLvCoYlxcOZ7i8nVDI9eyPfDa4H26VzFWp3CSs4cLd5q3fTHOZ7rG2dPFuxr2AR+2d+uhXV3++01GHXEa9pJN73/XYOONpUnMMeSaZXHKI1wujsfJNVivQVofKCCbEEIIqT9FY1h0eN+aro3WZIrGsxqKtQpt75bg4MJJquNJ0vWZa9A5IoQQsu3RctOzsrwvWurNuIyeknnMtdY38iHLe5wFtbvppv7Z+RAn6agsbRPcTm0Qx4gl8gkhhJBm3gF+1Byl28UxOsXSMkSLjJUFtj3rMcY+opmE64k5Lgx9PUkIIYSMPOIoHSCb5OWi50W/qYET1K03REthZ1VrstFN7RNhHnf3G0/+26lZtadJaF58V5VrSgghhIwc69zEdq3cUfpL0Y2ip7J0sUpw0taJftRy0+fKP4+s4sSoE1mL8QjzumbwmNMHZfmJ3posnqMKJ2yxjHUqYtKqWk9CCCFkq0AcBGS9zZZ/oo8broBWZVviVKJs3K9neb+zO1pbahg1ThB9rmqnqBOx5ZII8/yqz9gy9/3la/8tHETRC1l+2mMd813RM6L/C2cTTpisa8qUWUIIIWTrIXONj2d5zNJxrbz5LQKY1xs3bfm+xg/lOZfK//5z0Rdbbmqfkl3igyI23RTaQZL5qiqtwkGU7/ksTrNEVynW+/Xi54P1ParppvaNtU6EEEII6UG+iTf2EQfnoGxLVlZPzZaN/gDRyGzUxYlZaAepdJ8eecaOorFe69x0jYMYbE0IIYSQKKDBbQTn6N7U8yKEEEIIMdNyjVmhHSTRRannRQghhBBiJssz50I6Rx+Ijk09L0IIIYQQE003tYs4M9cEdpBeRPZY6rkRQgghhJhoucaYODQrAjtIK0MEaBNCCCGEJEGcmS9l4QtkLkk9L0IIIYQQMy03fXb4AO3GFannRQghhBBiRhyaKyNksM1NPS9CCCGEEBMoeinOzP2BnaNNosNTz40QQgghxETTNT4tzszPAjtIz2SuMTIVxAkhhBBCfguc9BQnPiEdpHtabvojqedGCCGEEGJCHJnTI8QfXZt6XoQQQgghZsSZmQjtILVcY37qeRFCCCGEmBGHZmkEB+nE1PMihBBCCDHRdFO7i0PzWGAH6cWMLUYIIYQQMqqII/N50UuBHaRHXnaLdk09N0IIIYQQE+LMnBghQPtHqedFCCGEEGKm5abPj+AgXZJ6XoQQQgghZsSZuSFCgPZpqedFCCGEEGKi6ab2Eofm4cAO0pqMLUYIIYQQMqq0XGOWODPPBnaQlslz90s9N0IIIYQQE+LMLBC9HdhBmkTz29RzI4QQQggxESP+SDQ39bwIIYQQQsyIM7MqtIPUdFP7p54XIYQQQogZcWg2BXaQMl6vEUIIIWSkEYfmFtF7oZyjlptmej8hhBBCRhtxaJDm/xXRnaLnlCdKr2V5Sv8/ii4VHZp6PoQQQgghwdjoJndoucYh4jCdIo7O1zwlX9s4DN+b2n5CCCGEEEIIIYQQQgghhBBCCCGEEFI7/j/SXNO5jJTNlAAAAABJRU5ErkJggg=="  
alt="logo of spboss.in" height="73" width="292">
</a>
</div>
<div class="container-fluid">
<div>

<h1 class="chart-h1" >TARA MUMBAI DAY PANEL CHART</h1>
<div class="para3">
<h2 style="font-size: 14px;margin: 0px;"> TARA MUMBAI DAY PANEL RESULT CHART RECORDS </h2>
<p style="margin: 0;font-size: 12px;line-height: 14px;">Dpboss TARA MUMBAI DAY panel chart, TARA MUMBAI DAY panel chart, old TARA MUMBAI DAY panel chart, 
TARA MUMBAI DAY pana patti chart, TARA MUMBAI DAY penel chart, TARA MUMBAI DAY panel chart, 
TARA MUMBAI DAY panel chart, dpboss TARA MUMBAI DAY, TARA MUMBAI DAY panel record, TARA MUMBAI DAY panel record, TARA MUMBAI DAY panel chart 2015, 
TARA MUMBAI DAY panel chart 2012, TARA MUMBAI DAY panel chart 2012 to 2014, TARA MUMBAI DAY final ank, TARA MUMBAI DAY panel chart.co, 
TARA MUMBAI DAY panel chart matka, TARA MUMBAI DAY panel chart book, TARA MUMBAI DAY matka chart, matka panel chart TARA MUMBAI DAY, matka TARA MUMBAI DAY chart, 
satta TARA MUMBAI DAY chart panel, TARA MUMBAI DAY state chart, TARA MUMBAI DAY chart result, 
डीपी बॉस,  सट्टा चार्ट, सट्टा मटका पैनल चार्ट, सट्टा मटका पैनल चार्ट, तारा मुंबई डे मटका पैनल चार्ट, सट्टा मटका तारा मुंबई डे चार्ट पैनल, तारा मुंबई डे सट्टा चार्ट, तारा मुंबई डे पैनल चार्ट </p>
</div>  
<div class="chart-result">    
		<div>TARA MUMBAI DAY</div>
		<span>256-35-159</span><br>
		<a href="tara-mumbai-day.php">Refresh Result</a>
</div>
	
<div id="top"></div>
<a href="#bottom" class="button2"> Go to Bottom </a><div class="panel panel-info">
<div class="panel-heading text-center" style="background: #3f51b5;">
<h3>TARA MUMBAI DAY MATKA PANEL RECORD 2019 - 2024</h3></div>
<div class="panel-body">
<table style="width: 100%; text-align:center;" class="panel-chart chart-table" cellpadding="2">
<thead> 
<tr>
<th>Date</th>
<th colspan="3">Mon</th>
<th colspan="3">Tue</th>
<th colspan="3">Wed</th>
<th colspan="3">Thu</th>
<th colspan="3">Fri</th>
<th colspan="3">Sat</th>					
</tr>
</thead>                	
<tbody>

	<tr>
		<td>02/12/2019<br>to<br>07/12/2019</td>
		<td>4<br>5<br>8</td>
		<td>76</td>
		<td>3<br>4<br>9</td>
		<td>4<br>7<br>7</td>
		<td>80</td>
		<td>2<br>3<br>5</td>
		<td>7<br>9<br>0</td>
		<td>68</td>
		<td>2<br>7<br>9</td>
		<td>1<br>9<br>0</td>
		<td>09</td>
		<td>1<br>8<br>0</td>
		<td>8<br>9<br>9</td>
		<td>60</td>
		<td>2<br>8<br>0</td>
		<td>3<br>6<br>8</td>
		<td>78</td>
		<td>2<br>7<br>9</td>
	</tr>
	<tr>
		<td>09/12/2019<br>to<br>14/12/2019</td>
		<td>1<br>2<br>7</td>
		<td>06</td>
		<td>7<br>9<br>0</td>
		<td>5<br>6<br>9</td>
		<td>08</td>
		<td>9<br>9<br>0</td>
		<td class="r"></p>6<br>8<br>9</td>
		<td class="r">38</td>
		<td class="r">2<br>6<br>0</td>
		<td>5<br>5<br>6</td>
		<td>67</td>
		<td>4<br>5<br>8</td>
		<td>4<br>5<br>7</td>
		<td>60</td>
		<td>5<br>6<br>9</td>
		<td class="r">2<br>5<br>5</td>
		<td class="r">27</td>
		<td class="r">4<br>5<br>8</td>
	</tr>
	<tr>
		<td>16/12/2019<br>to<br>21/12/2019</td>
		<td class="r">1<br>2<br>5</td>
		<td class="r">88</td>
		<td class="r">4<br>7<br>7</td>
		<td class="r">3<br>6<br>7</td>
		<td class="r">66</td>
		<td class="r">1<br>6<br>9</td>
		<td class="r">4<br>6<br>6</td>
		<td class="r">61</td>
		<td class="r">4<br>7<br>0</td>
		<td>2<br>5<br>7</td>
		<td>45</td>
		<td>8<br>8<br>9</td>
		<td>3<br>3<br>9</td>
		<td>59</td>
		<td>3<br>8<br>8</td>
		<td class="r">2<br>4<br>5</td>
		<td class="r">11</td>
		<td class="r">5<br>6<br>0</td>
	</tr>
	<tr>
		<td>30/12/2019<br>to<br>04/01/2020</td>
		<td>2<br>3<br>9</td>
		<td>40</td>
		<td>3<br>7<br>0</td>
		<td>2<br>6<br>7</td>
		<td>56</td>
		<td>3<br>6<br>7</td>
		<td>2<br>4<br>9</td>
		<td>56</td>
		<td>3<br>3<br>0</td>
		<td>2<br>6<br>0</td>
		<td>82</td>
		<td>4<br>9<br>9</td>
		<td>3<br>7<br>8</td>
		<td>85</td>
		<td>1<br>6<br>8</td>
		<td>5<br>7<br>8</td>
		<td>08</td>
		<td>2<br>6<br>0</td>
	</tr>
	<tr>
		<td>06/01/2020<br>to<br>11/01/2020</td>
		<td>6<br>9<br>0</td>
		<td>52</td>
		<td>1<br>5<br>6</td>
		<td>3<br>7<br>8</td>
		<td>82</td>
		<td>1<br>4<br>7</td>
		<td>3<br>3<br>4</td>
		<td>02</td>
		<td>2<br>5<br>5</td>
		<td>4<br>5<br>7</td>
		<td>69</td>
		<td>4<br>7<br>8</td>
		<td class="r">6<br>7<br>8</td>
		<td class="r">16</td>
		<td class="r">3<br>4<br>9</td>
		<td>1<br>9<br>9</td>
		<td>92</td>
		<td>2<br>3<br>7</td>
	</tr>
	<tr>
		<td>13/01/2020<br>to<br>18/01/2020</td>
		<td>1<br>4<br>6</td>
		<td>18</td>
		<td>2<br>3<br>3</td>
		<td>8<br>9<br>0</td>
		<td>70</td>
		<td>5<br>6<br>9</td>
		<td>1<br>3<br>6</td>
		<td>03</td>
		<td>7<br>7<br>9</td>
		<td>3<br>4<br>4</td>
		<td>13</td>
		<td>2<br>4<br>7</td>
		<td>2<br>4<br>5</td>
		<td>18</td>
		<td>1<br>7<br>0</td>
		<td>2<br>2<br>3</td>
		<td>75</td>
		<td>3<br>4<br>8</td>
	</tr>
	<tr>
		<td>20/01/2020<br>to<br>25/01/2020</td>
		<td>1<br>3<br>4</td>
		<td>89</td>
		<td>5<br>6<br>8</td>
		<td>7<br>7<br>0</td>
		<td>43</td>
		<td>1<br>4<br>8</td>
		<td>4<br>7<br>9</td>
		<td>03</td>
		<td>1<br>5<br>7</td>
		<td class="r">4<br>4<br>6</td>
		<td class="r">44</td>
		<td class="r">3<br>4<br>7</td>
		<td>1<br>5<br>5</td>
		<td>13</td>
		<td>6<br>8<br>9</td>
		<td class="r">3<br>8<br>8</td>
		<td class="r">99</td>
		<td class="r">1<br>3<br>5</td>
	</tr>
	<tr>
		<td>27/01/2020<br>to<br>01/02/2020</td>
		<td>2<br>4<br>0</td>
		<td>69</td>
		<td>6<br>6<br>7</td>
		<td class="r">8<br>9<br>0</td>
		<td class="r">77</td>
		<td class="r">1<br>6<br>0</td>
		<td>3<br>6<br>0</td>
		<td>96</td>
		<td>1<br>2<br>3</td>
		<td>3<br>5<br>7</td>
		<td>59</td>
		<td>2<br>8<br>9</td>
		<td>3<br>5<br>7</td>
		<td>59</td>
		<td>1<br>2<br>6</td>
		<td>2<br>3<br>6</td>
		<td>13</td>
		<td>2<br>5<br>6</td>
	</tr>
	<tr>
		<td>03/02/2020<br>to<br>08/02/2020</td>
		<td>3<br>6<br>0</td>
		<td>93</td>
		<td>1<br>4<br>8</td>
		<td>2<br>8<br>9</td>
		<td>93</td>
		<td>2<br>5<br>6</td>
		<td class="r">6<br>6<br>8</td>
		<td class="r">05</td>
		<td class="r">4<br>5<br>6</td>
		<td>5<br>5<br>9</td>
		<td>90</td>
		<td>2<br>2<br>6</td>
		<td>4<br>5<br>7</td>
		<td>62</td>
		<td>4<br>9<br>9</td>
		<td>7<br>9<br>9</td>
		<td>52</td>
		<td>4<br>9<br>9</td>
	</tr>
	<tr>
		<td>10/02/2020<br>to<br>15/02/2020</td>
		<td>6<br>7<br>9</td>
		<td>24</td>
		<td>3<br>3<br>8</td>
		<td>1<br>7<br>0</td>
		<td>81</td>
		<td>5<br>8<br>8</td>
		<td>6<br>8<br>8</td>
		<td>25</td>
		<td>4<br>5<br>6</td>
		<td>7<br>8<br>8</td>
		<td>31</td>
		<td>1<br>3<br>7</td>
		<td>1<br>1<br>4</td>
		<td>65</td>
		<td>2<br>5<br>8</td>
		<td>1<br>7<br>0</td>
		<td>85</td>
		<td>2<br>3<br>0</td>
	</tr>
	<tr>
		<td>17/02/2020<br>to<br>22/02/2020</td>
		<td class="r">3<br>6<br>9</td>
		<td class="r">88</td>
		<td class="r">4<br>6<br>8</td>
		<td>2<br>2<br>6</td>
		<td>08</td>
		<td>1<br>2<br>5</td>
		<td>1<br>6<br>6</td>
		<td>31</td>
		<td>2<br>9<br>0</td>
		<td>8<br>9<br>9</td>
		<td>64</td>
		<td>2<br>3<br>9</td>
		<td>1<br>9<br>0</td>
		<td>09</td>
		<td>2<br>2<br>5</td>
		<td>5<br>5<br>6</td>
		<td>67</td>
		<td>1<br>1<br>5</td>
	</tr>
	<tr>
		<td>24/02/2020<br>to<br>29/02/2020</td>
		<td>2<br>4<br>7</td>
		<td>39</td>
		<td>3<br>6<br>0</td>
		<td class="r">2<br>4<br>9</td>
		<td class="r">55</td>
		<td class="r">3<br>5<br>7</td>
		<td>1<br>4<br>8</td>
		<td>37</td>
		<td>2<br>7<br>8</td>
		<td class="r">1<br>5<br>0</td>
		<td class="r">61</td>
		<td class="r">2<br>4<br>5</td>
		<td class="r">7<br>7<br>8</td>
		<td class="r">22</td>
		<td class="r">6<br>6<br>0</td>
		<td>1<br>3<br>8</td>
		<td>28</td>
		<td>8<br>0<br>0</td>
	</tr>
	<tr>
		<td>02/03/2020<br>to<br>08/03/2020</td>
		<td>3<br>6<br>7</td>
		<td>65</td>
		<td>4<br>4<br>7</td>
		<td>5<br>8<br>9</td>
		<td>28</td>
		<td>2<br>3<br>3</td>
		<td>5<br>5<br>7</td>
		<td>71</td>
		<td>4<br>8<br>9</td>
		<td class="r">2<br>3<br>7</td>
		<td class="r">22</td>
		<td class="r">5<br>8<br>9</td>
		<td>6<br>7<br>7</td>
		<td>04</td>
		<td>2<br>3<br>9</td>
		<td class="r">1<br>3<br>4</td>
		<td class="r">88</td>
		<td class="r">3<br>5<br>0</td>
	</tr>
	<tr>
		<td>09/03/2020<br>to<br>14/03/2020</td>
		<td>2<br>3<br>5</td>
		<td>06</td>
		<td>2<br>5<br>9</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td>6<br>6<br>9</td>
		<td>13</td>
		<td>2<br>5<br>6</td>
		<td class="r">1<br>8<br>8</td>
		<td class="r">77</td>
		<td class="r">2<br>6<br>9</td>
		<td>7<br>9<br>9</td>
		<td>56</td>
		<td>2<br>7<br>7</td>
		<td>5<br>6<br>9</td>
		<td>04</td>
		<td>1<br>3<br>0</td>
	</tr>
	<tr>
		<td>16/03/2020<br>to<br>21/03/2020</td>
		<td>2<br>6<br>9</td>
		<td>74</td>
		<td>3<br>5<br>6</td>
		<td>2<br>2<br>5</td>
		<td>93</td>
		<td>6<br>8<br>9</td>
		<td>3<br>6<br>8</td>
		<td>74</td>
		<td>4<br>5<br>5</td>
		<td class="r">1<br>5<br>6</td>
		<td class="r">22</td>
		<td class="r">6<br>7<br>9</td>
		<td>1<br>1<br>2</td>
		<td>42</td>
		<td>1<br>3<br>8</td>
		<td>1<br>3<br>8</td>
		<td>29</td>
		<td>3<br>6<br>0</td>
	</tr>
	<tr>
		<td>23/03/2020<br>to<br>04/04/2020</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
	</tr>
	<tr>
		<td>06/04/2020<br>to<br>11/04/2020</td>
		<td>1<br>4<br>5</td>
		<td>02</td>
		<td>5<br>8<br>9</td>
		<td class="r">1<br>1<br>9</td>
		<td class="r">11</td>
		<td class="r">1<br>2<br>8</td>
		<td>3<br>5<br>0</td>
		<td>86</td>
		<td>3<br>3<br>0</td>
		<td>3<br>4<br>6</td>
		<td>35</td>
		<td>3<br>4<br>8</td>
		<td>5<br>5<br>0</td>
		<td>08</td>
		<td>4<br>6<br>8</td>
		<td>1<br>2<br>9</td>
		<td>26</td>
		<td>7<br>9<br>0</td>
	</tr>
	<tr>
		<td>13/04/2020<br>to<br>18/04/2020</td>
		<td>1<br>2<br>9</td>
		<td>29</td>
		<td>1<br>8<br>0</td>
		<td>5<br>6<br>9</td>
		<td>08</td>
		<td>1<br>2<br>5</td>
		<td>2<br>3<br>6</td>
		<td>15</td>
		<td>1<br>7<br>7</td>
		<td class="r">5<br>7<br>0</td>
		<td class="r">22</td>
		<td class="r">5<br>8<br>9</td>
		<td>3<br>3<br>0</td>
		<td>65</td>
		<td>2<br>3<br>0</td>
		<td>4<br>6<br>0</td>
		<td>08</td>
		<td>3<br>6<br>9</td>
	</tr>
	<tr>
		<td>20/04/2020<br>to<br>25/04/2020</td>
		<td>1<br>2<br>3</td>
		<td>60</td>
		<td>2<br>4<br>4</td>
		<td class="r">3<br>4<br>6</td>
		<td class="r">33</td>
		<td class="r">3<br>0<br>0</td>
		<td class="r">6<br>7<br>9</td>
		<td class="r">27</td>
		<td class="r">4<br>6<br>7</td>
		<td>3<br>6<br>9</td>
		<td>87</td>
		<td>2<br>7<br>8</td>
		<td>4<br>4<br>6</td>
		<td>47</td>
		<td>4<br>4<br>9</td>
		<td>4<br>5<br>0</td>
		<td>97</td>
		<td>2<br>6<br>9</td>
	</tr>
	<tr>
		<td>27/04/2020<br>to<br>02/05/2020</td>
		<td>2<br>3<br>6</td>
		<td>12</td>
		<td>3<br>4<br>5</td>
		<td class="r">3<br>8<br>9</td>
		<td class="r">05</td>
		<td class="r">2<br>3<br>0</td>
		<td class="r">2<br>6<br>9</td>
		<td class="r">77</td>
		<td class="r">4<br>6<br>7</td>
		<td>3<br>3<br>7</td>
		<td>39</td>
		<td>2<br>7<br>0</td>
		<td>2<br>7<br>9</td>
		<td>85</td>
		<td>1<br>4<br>0</td>
		<td>4<br>5<br>6</td>
		<td>51</td>
		<td>1<br>1<br>9</td>
	</tr>
	<tr>
		<td>04/05/2020<br>to<br>09/05/2020</td>
		<td>3<br>9<br>9</td>
		<td>17</td>
		<td>4<br>6<br>7</td>
		<td class="r">4<br>5<br>8</td>
		<td class="r">72</td>
		<td class="r">1<br>3<br>8</td>
		<td class="r">3<br>4<br>8</td>
		<td class="r">50</td>
		<td class="r">3<br>3<br>4</td>
		<td class="r">1<br>1<br>9</td>
		<td class="r">16</td>
		<td class="r">7<br>9<br>0</td>
		<td>4<br>5<br>9</td>
		<td>82</td>
		<td>7<br>7<br>8</td>
		<td class="r">1<br>2<br>8</td>
		<td class="r">11</td>
		<td class="r">1<br>0<br>0</td>
	</tr>
	<tr>
		<td>11/05/2020<br>to<br>16/05/2020</td>
		<td>2<br>3<br>5</td>
		<td>02</td>
		<td>5<br>7<br>0</td>
		<td class="r">6<br>9<br>0</td>
		<td class="r">50</td>
		<td class="r">2<br>9<br>9</td>
		<td class="r">2<br>9<br>0</td>
		<td class="r">11</td>
		<td class="r">5<br>7<br>9</td>
		<td>6<br>9<br>0</td>
		<td>51</td>
		<td>4<br>7<br>0</td>
		<td>1<br>1<br>2</td>
		<td>48</td>
		<td>1<br>1<br>6</td>
		<td>3<br>3<br>7</td>
		<td>39</td>
		<td>3<br>7<br>9</td>
	</tr>
	<tr>
		<td>18/05/2020<br>to<br>23/05/2020</td>
		<td>1<br>9<br>0</td>
		<td>03</td>
		<td>2<br>5<br>6</td>
		<td>4<br>5<br>6</td>
		<td>59</td>
		<td>1<br>3<br>5</td>
		<td>6<br>7<br>7</td>
		<td>09</td>
		<td>1<br>2<br>6</td>
		<td>1<br>1<br>3</td>
		<td>51</td>
		<td>1<br>2<br>8</td>
		<td>1<br>2<br>6</td>
		<td>92</td>
		<td>1<br>1<br>0</td>
		<td>1<br>3<br>6</td>
		<td>01</td>
		<td>1<br>5<br>5</td>
	</tr>
	<tr>
		<td>25/05/2020<br>to<br>30/05/2020</td>
		<td>4<br>4<br>7</td>
		<td>58</td>
		<td>3<br>7<br>8</td>
		<td class="r">1<br>4<br>6</td>
		<td class="r">16</td>
		<td class="r">4<br>5<br>7</td>
		<td>1<br>3<br>8</td>
		<td>23</td>
		<td>1<br>4<br>8</td>
		<td>4<br>5<br>9</td>
		<td>86</td>
		<td>4<br>6<br>6</td>
		<td>6<br>6<br>9</td>
		<td>18</td>
		<td>1<br>1<br>6</td>
		<td class="r">3<br>5<br>8</td>
		<td class="r">61</td>
		<td class="r">2<br>9<br>0</td>
	</tr>
	<tr>
		<td>01/06/2020<br>to<br>06/06/2020</td>
		<td class="r">3<br>5<br>6</td>
		<td class="r">44</td>
		<td class="r">2<br>3<br>9</td>
		<td>7<br>9<br>0</td>
		<td>69</td>
		<td>3<br>7<br>9</td>
		<td>2<br>7<br>8</td>
		<td>70</td>
		<td>3<br>8<br>9</td>
		<td>3<br>3<br>4</td>
		<td>09</td>
		<td>2<br>2<br>5</td>
		<td>2<br>7<br>9</td>
		<td>84</td>
		<td>5<br>9<br>0</td>
		<td class="r">1<br>4<br>8</td>
		<td class="r">33</td>
		<td class="r">1<br>5<br>7</td>
	</tr>
	<tr>
		<td>08/06/2020<br>to<br>13/06/2020</td>
		<td class="r">5<br>5<br>7</td>
		<td class="r">77</td>
		<td class="r">4<br>6<br>7</td>
		<td>2<br>2<br>9</td>
		<td>39</td>
		<td>5<br>6<br>8</td>
		<td>2<br>4<br>6</td>
		<td>28</td>
		<td>2<br>7<br>9</td>
		<td>5<br>6<br>7</td>
		<td>89</td>
		<td>2<br>3<br>4</td>
		<td>4<br>4<br>0</td>
		<td>84</td>
		<td>2<br>6<br>6</td>
		<td>2<br>9<br>9</td>
		<td>07</td>
		<td>2<br>7<br>8</td>
	</tr>
	<tr>
		<td>15/06/2020<br>to<br>20/06/2020</td>
		<td>4<br>7<br>9</td>
		<td>04</td>
		<td>7<br>8<br>9</td>
		<td>5<br>7<br>7</td>
		<td>97</td>
		<td>1<br>3<br>3</td>
		<td>5<br>7<br>9</td>
		<td>17</td>
		<td>3<br>6<br>8</td>
		<td>5<br>6<br>9</td>
		<td>01</td>
		<td>4<br>8<br>9</td>
		<td>1<br>5<br>7</td>
		<td>34</td>
		<td>4<br>4<br>6</td>
		<td>9<br>0<br>0</td>
		<td>91</td>
		<td>1<br>4<br>6</td>
	</tr>
	<tr>
		<td>22/06/2020<br>to<br>27/06/2020</td>
		<td class="r">4<br>6<br>7</td>
		<td class="r">72</td>
		<td class="r">3<br>9<br>0</td>
		<td>8<br>8<br>0</td>
		<td>62</td>
		<td>2<br>4<br>6</td>
		<td>1<br>2<br>8</td>
		<td>14</td>
		<td>3<br>5<br>6</td>
		<td>5<br>9<br>9</td>
		<td>39</td>
		<td>3<br>6<br>0</td>
		<td>1<br>3<br>6</td>
		<td>01</td>
		<td>5<br>6<br>0</td>
		<td>2<br>3<br>5</td>
		<td>04</td>
		<td>1<br>5<br>8</td>
	</tr>
	<tr>
		<td>29/06/2020<br>to<br>04/07/2020</td>
		<td class="r">2<br>5<br>7</td>
		<td class="r">49</td>
		<td class="r">4<br>6<br>9</td>
		<td>2<br>5<br>7</td>
		<td>41</td>
		<td>6<br>7<br>8</td>
		<td>1<br>2<br>5</td>
		<td>86</td>
		<td>8<br>8<br>0</td>
		<td>2<br>2<br>3</td>
		<td>79</td>
		<td>4<br>5<br>0</td>
		<td>6<br>7<br>7</td>
		<td>02</td>
		<td>1<br>4<br>7</td>
		<td>6<br>8<br>8</td>
		<td>26</td>
		<td>1<br>7<br>8</td>
	</tr>
	<tr>
		<td>06/07/2020<br>to<br>11/07/2020</td>
		<td>3<br>6<br>0</td>
		<td>98</td>
		<td>1<br>3<br>4</td>
		<td class="r">7<br>9<br>9</td>
		<td class="r">50</td>
		<td class="r">5<br>7<br>8</td>
		<td>1<br>1<br>5</td>
		<td>71</td>
		<td>5<br>6<br>0</td>
		<td>2<br>7<br>8</td>
		<td>73</td>
		<td>4<br>9<br>0</td>
		<td class="r">6<br>7<br>9</td>
		<td class="r">27</td>
		<td class="r">3<br>5<br>9</td>
		<td class="r">6<br>7<br>7</td>
		<td class="r">05</td>
		<td class="r">2<br>3<br>0</td>
	</tr>
	<tr>
		<td>13/07/2020<br>to<br>18/07/2020</td>
		<td>3<br>9<br>0</td>
		<td>23</td>
		<td>6<br>8<br>9</td>
		<td>1<br>7<br>8</td>
		<td>60</td>
		<td>5<br>6<br>9</td>
		<td>1<br>3<br>3</td>
		<td>79</td>
		<td>9<br>0<br>0</td>
		<td>5<br>7<br>8</td>
		<td>09</td>
		<td>3<br>7<br>9</td>
		<td>1<br>6<br>7</td>
		<td>41</td>
		<td>5<br>7<br>9</td>
		<td>1<br>7<br>0</td>
		<td>81</td>
		<td>3<br>4<br>4</td>
	</tr>
	<tr>
		<td>20/07/2020<br>to<br>25/07/2020</td>
		<td class="r">1<br>4<br>8</td>
		<td class="r">38</td>
		<td class="r">3<br>6<br>9</td>
		<td>1<br>3<br>4</td>
		<td>81</td>
		<td>4<br>7<br>0</td>
		<td>3<br>5<br>6</td>
		<td>41</td>
		<td>2<br>3<br>6</td>
		<td>1<br>6<br>7</td>
		<td>46</td>
		<td>8<br>9<br>9</td>
		<td class="r">2<br>7<br>8</td>
		<td class="r">77</td>
		<td class="r">3<br>6<br>8</td>
		<td>4<br>5<br>9</td>
		<td>82</td>
		<td>6<br>8<br>8</td>
	</tr>
	<tr>
		<td>27/07/2020<br>to<br>01/08/2020</td>
		<td>6<br>8<br>9</td>
		<td>36</td>
		<td>7<br>9<br>0</td>
		<td class="r">2<br>2<br>0</td>
		<td class="r">44</td>
		<td class="r">2<br>6<br>6</td>
		<td>7<br>8<br>0</td>
		<td>54</td>
		<td>2<br>3<br>9</td>
		<td>2<br>3<br>9</td>
		<td>43</td>
		<td>1<br>5<br>7</td>
		<td>3<br>5<br>7</td>
		<td>54</td>
		<td>7<br>8<br>9</td>
		<td>5<br>7<br>9</td>
		<td>12</td>
		<td>2<br>5<br>5</td>
	</tr>
	<tr>
		<td>03/08/2020<br>to<br>08/08/2020</td>
		<td class="r">1<br>7<br>7</td>
		<td class="r">55</td>
		<td class="r">1<br>4<br>0</td>
		<td class="r">4<br>6<br>8</td>
		<td class="r">83</td>
		<td class="r">1<br>3<br>9</td>
		<td>2<br>7<br>9</td>
		<td>85</td>
		<td>3<br>3<br>9</td>
		<td>4<br>5<br>9</td>
		<td>80</td>
		<td>6<br>7<br>7</td>
		<td class="r">4<br>5<br>8</td>
		<td class="r">77</td>
		<td class="r">2<br>6<br>9</td>
		<td>2<br>3<br>6</td>
		<td>18</td>
		<td>2<br>6<br>0</td>
	</tr>
	<tr>
		<td>10/08/2020<br>to<br>15/08/2020</td>
		<td class="r">6<br>9<br>0</td>
		<td class="r">55</td>
		<td class="r">4<br>4<br>7</td>
		<td>4<br>7<br>8</td>
		<td>98</td>
		<td>8<br>0<br>0</td>
		<td class="r">4<br>6<br>9</td>
		<td class="r">94</td>
		<td class="r">2<br>3<br>9</td>
		<td>6<br>7<br>7</td>
		<td>02</td>
		<td>5<br>8<br>9</td>
		<td>2<br>2<br>7</td>
		<td>13</td>
		<td>1<br>5<br>7</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
	</tr>
	<tr>
		<td>17/08/2020<br>to<br>22/08/2020</td>
		<td>4<br>7<br>8</td>
		<td>96</td>
		<td>8<br>8<br>0</td>
		<td>3<br>7<br>8</td>
		<td>87</td>
		<td>4<br>5<br>8</td>
		<td>1<br>2<br>8</td>
		<td>12</td>
		<td>1<br>4<br>7</td>
		<td>6<br>6<br>9</td>
		<td>12</td>
		<td>3<br>9<br>0</td>
		<td>2<br>6<br>9</td>
		<td>76</td>
		<td>1<br>5<br>0</td>
		<td>1<br>5<br>8</td>
		<td>46</td>
		<td>2<br>6<br>8</td>
	</tr>
	<tr>
		<td>24/08/2020<br>to<br>29/08/2020</td>
		<td class="r">2<br>4<br>9</td>
		<td class="r">55</td>
		<td class="r">2<br>3<br>0</td>
		<td class="r">3<br>3<br>4</td>
		<td class="r">00</td>
		<td class="r">2<br>4<br>4</td>
		<td>3<br>3<br>6</td>
		<td>29</td>
		<td>1<br>2<br>6</td>
		<td>4<br>9<br>0</td>
		<td>31</td>
		<td>5<br>7<br>9</td>
		<td>5<br>8<br>8</td>
		<td>17</td>
		<td>3<br>6<br>8</td>
		<td>3<br>8<br>0</td>
		<td>12</td>
		<td>3<br>9<br>0</td>
	</tr>
	<tr>
		<td>31/08/2020<br>to<br>05/09/2020</td>
		<td class="r">3<br>6<br>9</td>
		<td class="r">83</td>
		<td class="r">7<br>8<br>8</td>
		<td>1<br>6<br>0</td>
		<td>73</td>
		<td>1<br>2<br>0</td>
		<td class="r">3<br>6<br>8</td>
		<td class="r">77</td>
		<td class="r">2<br>6<br>9</td>
		<td class="r">2<br>5<br>9</td>
		<td class="r">61</td>
		<td class="r">1<br>2<br>8</td>
		<td>4<br>4<br>5</td>
		<td>32</td>
		<td>3<br>3<br>6</td>
		<td>3<br>7<br>0</td>
		<td>01</td>
		<td>5<br>7<br>9</td>
	</tr>
	<tr>
		<td>07/09/2020<br>to<br>12/09/2020</td>
		<td>2<br>8<br>0</td>
		<td>06</td>
		<td>1<br>2<br>3</td>
		<td>5<br>7<br>9</td>
		<td>13</td>
		<td>2<br>5<br>6</td>
		<td class="r">4<br>5<br>7</td>
		<td class="r">66</td>
		<td class="r">3<br>6<br>7</td>
		<td>1<br>2<br>4</td>
		<td>76</td>
		<td>3<br>4<br>9</td>
		<td>4<br>5<br>6</td>
		<td>59</td>
		<td>6<br>6<br>7</td>
		<td>4<br>9<br>9</td>
		<td>28</td>
		<td>2<br>7<br>9</td>
	</tr>
	<tr>
		<td>14/09/2020<br>to<br>19/09/2020</td>
		<td>3<br>4<br>9</td>
		<td>64</td>
		<td>7<br>7<br>0</td>
		<td class="r">2<br>7<br>9</td>
		<td class="r">88</td>
		<td class="r">2<br>3<br>3</td>
		<td>2<br>2<br>7</td>
		<td>19</td>
		<td>5<br>6<br>8</td>
		<td>1<br>2<br>3</td>
		<td>68</td>
		<td>5<br>6<br>7</td>
		<td>2<br>4<br>9</td>
		<td>59</td>
		<td>1<br>9<br>9</td>
		<td>3<br>5<br>7</td>
		<td>57</td>
		<td>8<br>9<br>0</td>
	</tr>
	<tr>
		<td>21/09/2020<br>to<br>26/09/2020</td>
		<td>2<br>4<br>5</td>
		<td>14</td>
		<td>1<br>5<br>8</td>
		<td class="r">6<br>6<br>7</td>
		<td class="r">99</td>
		<td class="r">4<br>7<br>8</td>
		<td>5<br>6<br>8</td>
		<td>95</td>
		<td>8<br>8<br>9</td>
		<td>1<br>4<br>8</td>
		<td>31</td>
		<td>1<br>0<br>0</td>
		<td class="r">1<br>3<br>4</td>
		<td class="r">88</td>
		<td class="r">1<br>2<br>5</td>
		<td>1<br>6<br>0</td>
		<td>79</td>
		<td>2<br>3<br>4</td>
	</tr>
	<tr>
		<td>28/09/2020<br>to<br>03/10/2020</td>
		<td class="r">5<br>6<br>7</td>
		<td class="r">83</td>
		<td class="r">6<br>7<br>0</td>
		<td>2<br>4<br>7</td>
		<td>30</td>
		<td>4<br>6<br>0</td>
		<td>5<br>8<br>9</td>
		<td>25</td>
		<td>3<br>3<br>9</td>
		<td>5<br>7<br>0</td>
		<td>20</td>
		<td>5<br>5<br>0</td>
		<td>4<br>5<br>6</td>
		<td>58</td>
		<td>2<br>2<br>4</td>
		<td>2<br>8<br>8</td>
		<td>82</td>
		<td>2<br>5<br>5</td>
	</tr>
	<tr>
		<td>05/10/2020<br>to<br>10/10/2020</td>
		<td>6<br>6<br>0</td>
		<td>23</td>
		<td>5<br>9<br>9</td>
		<td class="r">3<br>7<br>8</td>
		<td class="r">88</td>
		<td class="r">4<br>6<br>8</td>
		<td>1<br>3<br>8</td>
		<td>24</td>
		<td>5<br>9<br>0</td>
		<td>4<br>6<br>9</td>
		<td>95</td>
		<td>3<br>4<br>8</td>
		<td>6<br>6<br>9</td>
		<td>15</td>
		<td>1<br>1<br>3</td>
		<td>4<br>5<br>6</td>
		<td>57</td>
		<td>4<br>5<br>8</td>
	</tr>
	<tr>
		<td>12/10/2020<br>to<br>17/10/2020</td>
		<td>4<br>7<br>8</td>
		<td>93</td>
		<td>2<br>4<br>7</td>
		<td>3<br>8<br>9</td>
		<td>09</td>
		<td>1<br>1<br>7</td>
		<td class="r">1<br>2<br>9</td>
		<td class="r">27</td>
		<td class="r">3<br>5<br>9</td>
		<td>5<br>8<br>9</td>
		<td>29</td>
		<td>4<br>6<br>9</td>
		<td>2<br>3<br>4</td>
		<td>98</td>
		<td>4<br>5<br>9</td>
		<td>*<br>*<br>*</td>
		<td>**</td>
		<td>*<br>*<br>*</td>
	</tr>
	<tr>
		<td>19/10/2020<br>to<br>24/10/2020</td>
		<td>1<br>2<br>5</td>
		<td>86</td>
		<td>3<br>4<br>9</td>
		<td>2<br>4<br>7</td>
		<td>36</td>
		<td>8<br>9<br>9</td>
		<td class="r">8<br>0<br>0</td>
		<td class="r">88</td>
		<td class="r">4<br>7<br>7</td>
		<td>3<br>3<br>5</td>
		<td>19</td>
		<td>5<br>7<br>7</td>
		<td>3<br>5<br>9</td>
		<td>71</td>
		<td>1<br>4<br>6</td>
		<td>2<br>4<br>0</td>
		<td>64</td>
		<td>3<br>3<br>8</td>
	</tr>
	<tr>
		<td>26/11/2020<br>to<br>31/11/2020</td>
		<td class="r">4<br>7<br>0</td>
		<td class="r">11</td>
		<td class="r">2<br>2<br>7</td>
		<td>2<br>4<br>7</td>
		<td>37</td>
		<td>4<br>6<br>7</td>
		<td>3<br>3<br>9</td>
		<td>54</td>
		<td>7<br>7<br>0</td>
		<td>3<br>9<br>9</td>
		<td>14</td>
		<td>2<br>5<br>7</td>
		<td>6<br>9<br>9</td>
		<td>40</td>
		<td>6<br>7<br>7</td>
		<td>1<br>3<br>6</td>
		<td>08</td>
		<td>4<br>7<br>7</td>
	</tr>
	<tr>
		<td>02/11/2020<br>to<br>07/11/2020</td>
		<td>5<br>9<br>0</td>
		<td>48</td>
		<td>1<br>8<br>9</td>
		<td>1<br>4<br>5</td>
		<td>06</td>
		<td>3<br>5<br>8</td>
		<td>4<br>6<br>7</td>
		<td>73</td>
		<td>1<br>4<br>8</td>
		<td>2<br>4<br>0</td>
		<td>65</td>
		<td>1<br>5<br>9</td>
		<td>6<br>6<br>8</td>
		<td>03</td>
		<td>1<br>4<br>8</td>
		<td>2<br>6<br>7</td>
		<td>59</td>
		<td>3<br>8<br>8</td>
	</tr>
	<tr>
		<td>09/11/2020<br>to<br>22/11/2020</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">*<br>*<br>*</td>
		<td class="r">**</td>
		<td class="r">*<br>*<br>*</td>
	</tr>
	<tr>
		<td>23/11/2020<br>to<br>28/11/2020</td>
		<td>7<br>9<br>0</td>
		<td>68</td>
		<td>2<br>3<br>3</td>
		<td>5<br>8<br>9</td>
		<td>21</td>
		<td>2<br>2<br>7</td>
		<td>3<br>3<br>6</td>
		<td>29</td>
		<td>4<br>7<br>8</td>
		<td>4<br>7<br>8</td>
		<td>98</td>
		<td>5<br>5<br>8</td>
		<td>4<br>5<br>9</td>
		<td>84</td>
		<td>4<br>5<br>5</td>
		<td>4<br>7<br>9</td>
		<td>08</td>
		<td>4<br>4<br>0</td>
	</tr>
	<tr>
		<td>30/11/2020<br>to<br>05/12/2020</td>
		<td>5<br>7<br>8</td>
		<td>09</td>
		<td>9<br>0<br>0</td>
		<td>3<br>5<br>0</td>
		<td>81</td>
		<td>2<br>4<br>5</td>
		<td>1<br>3<br>7</td>
		<td>10</td>
		<td>2<br>2<br>6</td>
		<td>1<br>3<br>3</td>
		<td>70</td>
		<td>1<br>4<br>5</td>
		<td class="r">5<br>7<br>9</td>
		<td class="r">16</td>
		<td class="r">3<br>6<br>7</td>
		<td>2<br>5<br>0</td>
		<td>74</td>
		<td>5<br>9<br>0</td>
	</tr>
					 
 
      <tr>
        <td>07/12/2020<br/>to<br/>12/12/2020</td>
      
<td class="">1<br>6<br>0</td>
<td class="">76</td>
<td class="">7<br>9<br>0</td>


<td class="">2<br>7<br>8</td>
<td class="">74</td>
<td class="">2<br>4<br>8</td>


<td class="">3<br>7<br>0</td>
<td class="">07</td>
<td class="">2<br>6<br>9</td>


<td class="r">8<br>8<br>9</td>
<td class="r">55</td>
<td class="r">6<br>9<br>0</td>


<td class="">2<br>9<br>0</td>
<td class="">14</td>
<td class="">2<br>4<br>8</td>


<td class="r">1<br>2<br>8</td>
<td class="r">11</td>
<td class="r">3<br>9<br>9</td>

</tr>      <tr>
        <td>14/12/2020<br/>to<br/>19/12/2020</td>
      
<td class="r">7<br>8<br>9</td>
<td class="r">44</td>
<td class="r">3<br>3<br>8</td>


<td class="">5<br>7<br>9</td>
<td class="">17</td>
<td class="">1<br>2<br>4</td>


<td class="">4<br>4<br>9</td>
<td class="">71</td>
<td class="">4<br>7<br>0</td>


<td class="">1<br>3<br>6</td>
<td class="">09</td>
<td class="">1<br>9<br>9</td>


<td class="">2<br>5<br>6</td>
<td class="">31</td>
<td class="">2<br>9<br>0</td>


<td class="">1<br>8<br>0</td>
<td class="">91</td>
<td class="">1<br>4<br>6</td>

</tr>      <tr>
        <td>21/12/2020<br/>to<br/>26/12/2020</td>
      
<td class="">4<br>7<br>8</td>
<td class="">93</td>
<td class="">4<br>4<br>5</td>


<td class="">4<br>9<br>0</td>
<td class="">32</td>
<td class="">1<br>3<br>8</td>


<td class="r">2<br>6<br>9</td>
<td class="r">72</td>
<td class="r">2<br>4<br>6</td>


<td class="">4<br>6<br>8</td>
<td class="">87</td>
<td class="">3<br>5<br>9</td>


<td class="">2<br>3<br>8</td>
<td class="">37</td>
<td class="">3<br>6<br>8</td>


<td class="r">3<br>6<br>0</td>
<td class="r">94</td>
<td class="r">1<br>5<br>8</td>

</tr>      <tr>
        <td>28/12/2020<br/>to<br/>02/01/2021</td>
      
<td class="">2<br>3<br>9</td>
<td class="">40</td>
<td class="">2<br>4<br>4</td>


<td class="">3<br>5<br>9</td>
<td class="">79</td>
<td class="">1<br>2<br>6</td>


<td class="">3<br>4<br>8</td>
<td class="">58</td>
<td class="">5<br>6<br>7</td>


<td class="">6<br>8<br>0</td>
<td class="">40</td>
<td class="">2<br>9<br>9</td>


<td class="">3<br>7<br>9</td>
<td class="">98</td>
<td class="">4<br>5<br>9</td>


<td class="">4<br>6<br>0</td>
<td class="">06</td>
<td class="">4<br>4<br>8</td>

</tr>      <tr>
        <td>04/01/2021<br/>to<br/>09/01/2021</td>
      
<td class="">4<br>5<br>5</td>
<td class="">40</td>
<td class="">2<br>3<br>5</td>


<td class="">2<br>5<br>7</td>
<td class="">42</td>
<td class="">1<br>3<br>8</td>


<td class="">2<br>7<br>9</td>
<td class="">80</td>
<td class="">2<br>8<br>0</td>


<td class="">2<br>7<br>9</td>
<td class="">80</td>
<td class="">2<br>8<br>0</td>


<td class="">6<br>7<br>0</td>
<td class="">39</td>
<td class="">2<br>2<br>5</td>


<td class="r">1<br>9<br>0</td>
<td class="r">05</td>
<td class="r">3<br>4<br>8</td>

</tr>      <tr>
        <td>11/01/2021<br/>to<br/>16/01/2021</td>
      
<td class="">3<br>6<br>7</td>
<td class="">62</td>
<td class="">4<br>9<br>9</td>


<td class="r">6<br>7<br>7</td>
<td class="r">05</td>
<td class="r">4<br>5<br>6</td>


<td class="r">1<br>9<br>9</td>
<td class="r">94</td>
<td class="r">7<br>8<br>9</td>


<td class="r">2<br>8<br>9</td>
<td class="r">94</td>
<td class="r">3<br>5<br>6</td>


<td class="">4<br>5<br>9</td>
<td class="">81</td>
<td class="">6<br>7<br>8</td>


<td class="">2<br>4<br>8</td>
<td class="">43</td>
<td class="">2<br>2<br>9</td>

</tr>      <tr>
        <td>18/01/2021<br/>to<br/>23/01/2021</td>
      
<td class="">1<br>4<br>6</td>
<td class="">10</td>
<td class="">2<br>4<br>4</td>


<td class="r">3<br>8<br>8</td>
<td class="r">94</td>
<td class="r">5<br>9<br>0</td>


<td class="">1<br>4<br>0</td>
<td class="">57</td>
<td class="">2<br>2<br>3</td>


<td class="">2<br>3<br>0</td>
<td class="">52</td>
<td class="">6<br>6<br>0</td>


<td class="">2<br>4<br>6</td>
<td class="">23</td>
<td class="">6<br>8<br>9</td>


<td class="">2<br>8<br>0</td>
<td class="">02</td>
<td class="">6<br>7<br>9</td>

</tr>      <tr>
        <td>25/01/2021<br/>to<br/>30/01/2021</td>
      
<td class="">1<br>1<br>2</td>
<td class="">46</td>
<td class="">3<br>5<br>8</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">1<br>7<br>8</td>
<td class="r">61</td>
<td class="r">2<br>3<br>6</td>


<td class="r">3<br>7<br>9</td>
<td class="r">99</td>
<td class="r">2<br>8<br>9</td>


<td class="">1<br>4<br>4</td>
<td class="">96</td>
<td class="">4<br>5<br>7</td>


<td class="">3<br>6<br>8</td>
<td class="">76</td>
<td class="">2<br>6<br>8</td>

</tr>      <tr>
        <td>01/02/2021<br/>to<br/>06/02/2021</td>
      
<td class="r">5<br>9<br>0</td>
<td class="r">44</td>
<td class="r">2<br>3<br>9</td>


<td class="">5<br>6<br>6</td>
<td class="">78</td>
<td class="">1<br>3<br>4</td>


<td class="">2<br>3<br>7</td>
<td class="">26</td>
<td class="">6<br>0<br>0</td>


<td class="">3<br>4<br>6</td>
<td class="">35</td>
<td class="">7<br>8<br>0</td>


<td class="r">1<br>4<br>8</td>
<td class="r">38</td>
<td class="r">5<br>6<br>7</td>


<td class="">7<br>7<br>8</td>
<td class="">20</td>
<td class="">3<br>3<br>4</td>

</tr>      <tr>
        <td>08/02/2021<br/>to<br/>13/02/2021</td>
      
<td class="">1<br>5<br>7</td>
<td class="">36</td>
<td class="">7<br>9<br>0</td>


<td class="">6<br>7<br>8</td>
<td class="">13</td>
<td class="">2<br>4<br>7</td>


<td class="r">4<br>8<br>9</td>
<td class="r">11</td>
<td class="r">5<br>8<br>8</td>


<td class="r">3<br>3<br>4</td>
<td class="r">00</td>
<td class="r">1<br>1<br>8</td>


<td class="">1<br>1<br>7</td>
<td class="">91</td>
<td class="">1<br>3<br>7</td>


<td class="">2<br>4<br>6</td>
<td class="">23</td>
<td class="">2<br>5<br>6</td>

</tr>      <tr>
        <td>15/02/2021<br/>to<br/>20/02/2021</td>
      
<td class="">5<br>8<br>8</td>
<td class="">13</td>
<td class="">2<br>4<br>7</td>


<td class="">4<br>7<br>8</td>
<td class="">97</td>
<td class="">7<br>0<br>0</td>


<td class="">3<br>6<br>6</td>
<td class="">54</td>
<td class="">3<br>5<br>6</td>


<td class="">9<br>9<br>0</td>
<td class="">87</td>
<td class="">7<br>0<br>0</td>


<td class="r">6<br>9<br>0</td>
<td class="r">50</td>
<td class="r">4<br>8<br>8</td>


<td class="">2<br>6<br>7</td>
<td class="">54</td>
<td class="">4<br>0<br>0</td>

</tr>      <tr>
        <td>22/02/2021<br/>to<br/>27/02/2021</td>
      
<td class="r">7<br>8<br>9</td>
<td class="r">44</td>
<td class="r">1<br>6<br>7</td>


<td class="">4<br>6<br>7</td>
<td class="">71</td>
<td class="">2<br>3<br>6</td>


<td class="">3<br>4<br>4</td>
<td class="">15</td>
<td class="">1<br>6<br>8</td>


<td class="">2<br>7<br>8</td>
<td class="">75</td>
<td class="">1<br>2<br>2</td>


<td class="">2<br>6<br>0</td>
<td class="">89</td>
<td class="">9<br>0<br>0</td>


<td class="r">6<br>8<br>9</td>
<td class="r">38</td>
<td class="r">3<br>6<br>9</td>

</tr>      <tr>
        <td>01/03/2021<br/>to<br/>06/03/2021</td>
      
<td class="r">2<br>5<br>6</td>
<td class="r">38</td>
<td class="r">3<br>6<br>9</td>


<td class="">6<br>7<br>9</td>
<td class="">24</td>
<td class="">1<br>6<br>7</td>


<td class="r">1<br>1<br>6</td>
<td class="r">83</td>
<td class="r">2<br>3<br>8</td>


<td class="r">2<br>6<br>0</td>
<td class="r">83</td>
<td class="r">3<br>4<br>6</td>


<td class="">1<br>3<br>5</td>
<td class="">96</td>
<td class="">5<br>5<br>6</td>


<td class="">1<br>2<br>0</td>
<td class="">39</td>
<td class="">4<br>6<br>9</td>

</tr>      <tr>
        <td>08/03/2021<br/>to<br/>13/03/2021</td>
      
<td class="">5<br>7<br>8</td>
<td class="">07</td>
<td class="">3<br>4<br>0</td>


<td class="">2<br>7<br>9</td>
<td class="">84</td>
<td class="">7<br>8<br>9</td>


<td class="">9<br>9<br>0</td>
<td class="">80</td>
<td class="">2<br>8<br>0</td>


<td class="">2<br>6<br>7</td>
<td class="">54</td>
<td class="">2<br>4<br>8</td>


<td class="">6<br>8<br>8</td>
<td class="">29</td>
<td class="">6<br>6<br>7</td>


<td class="">3<br>3<br>6</td>
<td class="">21</td>
<td class="">5<br>6<br>0</td>

</tr>      <tr>
        <td>15/03/2021<br/>to<br/>20/03/2021</td>
      
<td class="">1<br>4<br>7</td>
<td class="">21</td>
<td class="">6<br>7<br>8</td>


<td class="">2<br>5<br>0</td>
<td class="">70</td>
<td class="">5<br>7<br>8</td>


<td class="">1<br>9<br>9</td>
<td class="">93</td>
<td class="">1<br>2<br>0</td>


<td class="r">3<br>4<br>9</td>
<td class="r">66</td>
<td class="r">1<br>6<br>9</td>


<td class="">3<br>6<br>7</td>
<td class="">64</td>
<td class="">2<br>5<br>7</td>


<td class="">7<br>7<br>0</td>
<td class="">48</td>
<td class="">4<br>5<br>9</td>

</tr>      <tr>
        <td>22/03/2021<br/>to<br/>27/03/2021</td>
      
<td class="">5<br>5<br>9</td>
<td class="">91</td>
<td class="">3<br>3<br>5</td>


<td class="">4<br>6<br>7</td>
<td class="">76</td>
<td class="">3<br>5<br>8</td>


<td class="">2<br>5<br>0</td>
<td class="">79</td>
<td class="">2<br>7<br>0</td>


<td class="">1<br>2<br>6</td>
<td class="">95</td>
<td class="">7<br>8<br>0</td>


<td class="">3<br>8<br>9</td>
<td class="">01</td>
<td class="">2<br>4<br>5</td>


<td class="">1<br>4<br>7</td>
<td class="">26</td>
<td class="">1<br>5<br>0</td>

</tr>      <tr>
        <td>29/03/2021<br/>to<br/>03/04/2021</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">3<br>4<br>6</td>
<td class="">37</td>
<td class="">4<br>5<br>8</td>


<td class="">3<br>8<br>9</td>
<td class="">03</td>
<td class="">7<br>8<br>8</td>


<td class="">4<br>7<br>9</td>
<td class="">07</td>
<td class="">4<br>5<br>8</td>


<td class="">1<br>7<br>0</td>
<td class="">87</td>
<td class="">4<br>5<br>8</td>


<td class="">4<br>7<br>0</td>
<td class="">15</td>
<td class="">3<br>4<br>8</td>

</tr>      <tr>
        <td>05/04/2021<br/>to<br/>10/04/2021</td>
      
<td class="">3<br>7<br>8</td>
<td class="">80</td>
<td class="">1<br>2<br>7</td>


<td class="">2<br>3<br>6</td>
<td class="">18</td>
<td class="">2<br>7<br>9</td>


<td class="">7<br>8<br>0</td>
<td class="">53</td>
<td class="">5<br>9<br>9</td>


<td class="">1<br>5<br>6</td>
<td class="">20</td>
<td class="">5<br>7<br>8</td>


<td class="">3<br>4<br>8</td>
<td class="">54</td>
<td class="">1<br>4<br>9</td>


<td class="">5<br>6<br>8</td>
<td class="">97</td>
<td class="">1<br>6<br>0</td>

</tr>      <tr>
        <td>12/04/2021<br/>to<br/>17/04/2021</td>
      
<td class="">5<br>6<br>8</td>
<td class="">97</td>
<td class="">5<br>5<br>7</td>


<td class="">4<br>6<br>0</td>
<td class="">06</td>
<td class="">5<br>5<br>6</td>


<td class="">1<br>3<br>6</td>
<td class="">01</td>
<td class="">1<br>4<br>6</td>


<td class="r">1<br>7<br>8</td>
<td class="r">66</td>
<td class="r">3<br>6<br>7</td>


<td class="r">1<br>6<br>7</td>
<td class="r">44</td>
<td class="r">1<br>4<br>9</td>


<td class="">2<br>4<br>7</td>
<td class="">34</td>
<td class="">1<br>6<br>7</td>

</tr>      <tr>
        <td>19/04/2021<br/>to<br/>24/04/2021</td>
      
<td class="">6<br>9<br>9</td>
<td class="">41</td>
<td class="">1<br>3<br>7</td>


<td class="">7<br>9<br>0</td>
<td class="">65</td>
<td class="">2<br>3<br>0</td>


<td class="">6<br>8<br>8</td>
<td class="">24</td>
<td class="">5<br>9<br>0</td>


<td class="">2<br>3<br>8</td>
<td class="">31</td>
<td class="">6<br>6<br>9</td>


<td class="r">2<br>4<br>5</td>
<td class="r">11</td>
<td class="r">2<br>3<br>6</td>


<td class="">5<br>5<br>0</td>
<td class="">07</td>
<td class="">1<br>8<br>8</td>

</tr>      <tr>
        <td>26/04/2021<br/>to<br/>01/05/2021</td>
      
<td class="">2<br>4<br>5</td>
<td class="">18</td>
<td class="">2<br>7<br>9</td>


<td class="">5<br>6<br>7</td>
<td class="">86</td>
<td class="">3<br>4<br>9</td>


<td class="r">7<br>8<br>0</td>
<td class="r">50</td>
<td class="r">5<br>5<br>0</td>


<td class="">4<br>7<br>8</td>
<td class="">93</td>
<td class="">3<br>4<br>6</td>


<td class="">4<br>7<br>0</td>
<td class="">18</td>
<td class="">3<br>6<br>9</td>


<td class="r">2<br>7<br>9</td>
<td class="r">83</td>
<td class="r">1<br>3<br>9</td>

</tr>      <tr>
        <td>03/05/2021<br/>to<br/>08/05/2021</td>
      
<td class="">6<br>0<br>0</td>
<td class="">68</td>
<td class="">3<br>7<br>8</td>


<td class="">3<br>3<br>5</td>
<td class="">17</td>
<td class="">7<br>0<br>0</td>


<td class="">4<br>7<br>0</td>
<td class="">10</td>
<td class="">1<br>9<br>0</td>


<td class="r">2<br>4<br>9</td>
<td class="r">50</td>
<td class="r">3<br>7<br>0</td>


<td class="">4<br>5<br>8</td>
<td class="">78</td>
<td class="">3<br>7<br>8</td>


<td class="">2<br>4<br>4</td>
<td class="">09</td>
<td class="">6<br>6<br>7</td>

</tr>      <tr>
        <td>10/05/2021<br/>to<br/>15/05/2021</td>
      
<td class="">5<br>6<br>7</td>
<td class="">81</td>
<td class="">3<br>4<br>4</td>


<td class="">4<br>8<br>9</td>
<td class="">14</td>
<td class="">1<br>5<br>8</td>


<td class="">5<br>7<br>0</td>
<td class="">23</td>
<td class="">3<br>3<br>7</td>


<td class="">7<br>7<br>8</td>
<td class="">26</td>
<td class="">3<br>4<br>9</td>


<td class="">1<br>4<br>5</td>
<td class="">04</td>
<td class="">1<br>3<br>0</td>


<td class="">3<br>5<br>5</td>
<td class="">30</td>
<td class="">1<br>3<br>6</td>

</tr>      <tr>
        <td>17/05/2021<br/>to<br/>22/05/2021</td>
      
<td class="">2<br>2<br>8</td>
<td class="">23</td>
<td class="">1<br>3<br>9</td>


<td class="">3<br>5<br>8</td>
<td class="">67</td>
<td class="">1<br>6<br>0</td>


<td class="r">1<br>3<br>6</td>
<td class="r">00</td>
<td class="r">1<br>3<br>6</td>


<td class="">2<br>5<br>7</td>
<td class="">41</td>
<td class="">5<br>6<br>0</td>


<td class="">1<br>2<br>6</td>
<td class="">91</td>
<td class="">3<br>8<br>0</td>


<td class="r">2<br>8<br>0</td>
<td class="r">00</td>
<td class="r">4<br>6<br>0</td>

</tr>      <tr>
        <td>24/05/2021<br/>to<br/>29/05/2021</td>
      
<td class="r">5<br>6<br>7</td>
<td class="r">88</td>
<td class="r">1<br>2<br>5</td>


<td class="">1<br>8<br>0</td>
<td class="">97</td>
<td class="">3<br>5<br>9</td>


<td class="">6<br>7<br>8</td>
<td class="">15</td>
<td class="">8<br>8<br>9</td>


<td class="">4<br>8<br>0</td>
<td class="">21</td>
<td class="">2<br>9<br>0</td>


<td class="">2<br>8<br>9</td>
<td class="">97</td>
<td class="">7<br>0<br>0</td>


<td class="">2<br>8<br>9</td>
<td class="">91</td>
<td class="">5<br>6<br>0</td>

</tr>      <tr>
        <td>31/05/2021<br/>to<br/>05/06/2021</td>
      
<td class="">3<br>3<br>9</td>
<td class="">52</td>
<td class="">2<br>4<br>6</td>


<td class="">3<br>7<br>9</td>
<td class="">96</td>
<td class="">4<br>4<br>8</td>


<td class="">2<br>3<br>5</td>
<td class="">06</td>
<td class="">4<br>4<br>8</td>


<td class="">2<br>6<br>9</td>
<td class="">78</td>
<td class="">3<br>7<br>8</td>


<td class="">3<br>4<br>8</td>
<td class="">52</td>
<td class="">3<br>9<br>0</td>


<td class="">1<br>5<br>0</td>
<td class="">62</td>
<td class="">4<br>9<br>9</td>

</tr>      <tr>
        <td>07/06/2021<br/>to<br/>12/06/2021</td>
      
<td class="">4<br>5<br>6</td>
<td class="">52</td>
<td class="">3<br>9<br>0</td>


<td class="">3<br>5<br>8</td>
<td class="">67</td>
<td class="">5<br>6<br>6</td>


<td class="">2<br>5<br>8</td>
<td class="">53</td>
<td class="">3<br>4<br>6</td>


<td class="">1<br>8<br>0</td>
<td class="">92</td>
<td class="">4<br>9<br>9</td>


<td class="r">3<br>5<br>8</td>
<td class="r">66</td>
<td class="r">3<br>6<br>7</td>


<td class="">1<br>1<br>8</td>
<td class="">06</td>
<td class="">3<br>6<br>7</td>

</tr>      <tr>
        <td>14/06/2021<br/>to<br/>19/06/2021</td>
      
<td class="r">4<br>8<br>9</td>
<td class="r">16</td>
<td class="r">3<br>5<br>8</td>


<td class="r">2<br>7<br>7</td>
<td class="r">66</td>
<td class="r">2<br>4<br>0</td>


<td class="">2<br>2<br>9</td>
<td class="">31</td>
<td class="">1<br>2<br>8</td>


<td class="">2<br>3<br>7</td>
<td class="">20</td>
<td class="">1<br>2<br>7</td>


<td class="">2<br>2<br>5</td>
<td class="">92</td>
<td class="">2<br>4<br>6</td>


<td class="">4<br>5<br>0</td>
<td class="">95</td>
<td class="">2<br>3<br>0</td>

</tr>      <tr>
        <td>21/06/2021<br/>to<br/>26/06/2021</td>
      
<td class="">5<br>5<br>9</td>
<td class="">93</td>
<td class="">2<br>2<br>9</td>


<td class="r">1<br>7<br>8</td>
<td class="r">61</td>
<td class="r">5<br>8<br>8</td>


<td class="">3<br>7<br>0</td>
<td class="">08</td>
<td class="">2<br>2<br>4</td>


<td class="">2<br>5<br>6</td>
<td class="">30</td>
<td class="">3<br>8<br>9</td>


<td class="r">3<br>8<br>9</td>
<td class="r">00</td>
<td class="r">2<br>8<br>0</td>


<td class="r">2<br>3<br>6</td>
<td class="r">10</td>
<td class="r">4<br>7<br>9</td>

</tr>      <tr>
        <td>28/06/2021<br/>to<br/>03/07/2021</td>
      
<td class="">4<br>7<br>8</td>
<td class="">95</td>
<td class="">6<br>9<br>0</td>


<td class="">1<br>3<br>7</td>
<td class="">19</td>
<td class="">1<br>4<br>4</td>


<td class="">2<br>9<br>0</td>
<td class="">12</td>
<td class="">5<br>8<br>9</td>


<td class="">4<br>5<br>9</td>
<td class="">84</td>
<td class="">7<br>8<br>9</td>


<td class="">1<br>1<br>7</td>
<td class="">98</td>
<td class="">1<br>3<br>4</td>


<td class="">2<br>3<br>4</td>
<td class="">98</td>
<td class="">3<br>6<br>9</td>

</tr>      <tr>
        <td>05/07/2021<br/>to<br/>10/07/2021</td>
      
<td class="r">1<br>5<br>0</td>
<td class="r">61</td>
<td class="r">1<br>3<br>7</td>


<td class="">1<br>1<br>7</td>
<td class="">98</td>
<td class="">4<br>6<br>8</td>


<td class="r">6<br>9<br>0</td>
<td class="r">55</td>
<td class="r">3<br>5<br>7</td>


<td class="">4<br>7<br>0</td>
<td class="">18</td>
<td class="">2<br>7<br>9</td>


<td class="">6<br>7<br>8</td>
<td class="">10</td>
<td class="">1<br>2<br>7</td>


<td class="">5<br>6<br>6</td>
<td class="">74</td>
<td class="">2<br>5<br>7</td>

</tr>      <tr>
        <td>12/07/2021<br/>to<br/>17/07/2021</td>
      
<td class="">1<br>5<br>9</td>
<td class="">51</td>
<td class="">1<br>4<br>6</td>


<td class="">1<br>4<br>7</td>
<td class="">29</td>
<td class="">3<br>7<br>9</td>


<td class="">3<br>7<br>8</td>
<td class="">84</td>
<td class="">1<br>3<br>0</td>


<td class="">7<br>7<br>8</td>
<td class="">26</td>
<td class="">1<br>5<br>0</td>


<td class="">2<br>3<br>9</td>
<td class="">46</td>
<td class="">5<br>5<br>6</td>


<td class="r">5<br>6<br>8</td>
<td class="r">99</td>
<td class="r">4<br>5<br>0</td>

</tr>      <tr>
        <td>19/07/2021<br/>to<br/>24/07/2021</td>
      
<td class="">2<br>3<br>8</td>
<td class="">37</td>
<td class="">5<br>5<br>7</td>


<td class="">7<br>8<br>0</td>
<td class="">58</td>
<td class="">1<br>3<br>4</td>


<td class="">5<br>6<br>7</td>
<td class="">85</td>
<td class="">2<br>6<br>7</td>


<td class="">5<br>6<br>8</td>
<td class="">92</td>
<td class="">1<br>4<br>7</td>


<td class="">3<br>4<br>8</td>
<td class="">51</td>
<td class="">3<br>8<br>0</td>


<td class="">2<br>5<br>9</td>
<td class="">69</td>
<td class="">1<br>3<br>5</td>

</tr>      <tr>
        <td>26/07/2021<br/>to<br/>31/07/2021</td>
      
<td class="r">5<br>6<br>8</td>
<td class="r">99</td>
<td class="r">2<br>8<br>9</td>


<td class="">2<br>4<br>9</td>
<td class="">52</td>
<td class="">6<br>7<br>9</td>


<td class="">2<br>6<br>7</td>
<td class="">52</td>
<td class="">2<br>3<br>7</td>


<td class="">6<br>9<br>9</td>
<td class="">45</td>
<td class="">1<br>1<br>3</td>


<td class="r">1<br>5<br>7</td>
<td class="r">33</td>
<td class="r">2<br>4<br>7</td>


<td class="">3<br>8<br>0</td>
<td class="">17</td>
<td class="">4<br>5<br>8</td>

</tr>      <tr>
        <td>02/08/2021<br/>to<br/>07/08/2021</td>
      
<td class="">1<br>6<br>8</td>
<td class="">59</td>
<td class="">9<br>0<br>0</td>


<td class="r">5<br>8<br>0</td>
<td class="r">33</td>
<td class="r">5<br>8<br>0</td>


<td class="">4<br>5<br>0</td>
<td class="">97</td>
<td class="">1<br>8<br>8</td>


<td class="">1<br>5<br>7</td>
<td class="">37</td>
<td class="">3<br>4<br>0</td>


<td class="">5<br>9<br>0</td>
<td class="">45</td>
<td class="">3<br>4<br>8</td>


<td class="">2<br>6<br>7</td>
<td class="">51</td>
<td class="">2<br>3<br>6</td>

</tr>      <tr>
        <td>09/08/2021<br/>to<br/>14/08/2021</td>
      
<td class="">8<br>8<br>0</td>
<td class="">62</td>
<td class="">1<br>5<br>6</td>


<td class="">1<br>5<br>7</td>
<td class="">39</td>
<td class="">2<br>7<br>0</td>


<td class="">2<br>3<br>7</td>
<td class="">24</td>
<td class="">7<br>7<br>0</td>


<td class="">6<br>7<br>9</td>
<td class="">26</td>
<td class="">1<br>6<br>9</td>


<td class="">4<br>7<br>0</td>
<td class="">12</td>
<td class="">1<br>3<br>8</td>


<td class="">3<br>9<br>9</td>
<td class="">18</td>
<td class="">2<br>7<br>9</td>

</tr>      <tr>
        <td>16/08/2021<br/>to<br/>21/08/2021</td>
      
<td class="">1<br>3<br>7</td>
<td class="">10</td>
<td class="">5<br>5<br>0</td>


<td class="">1<br>2<br>3</td>
<td class="">68</td>
<td class="">4<br>6<br>8</td>


<td class="">1<br>7<br>0</td>
<td class="">80</td>
<td class="">5<br>6<br>9</td>


<td class="r">5<br>5<br>7</td>
<td class="r">72</td>
<td class="r">1<br>4<br>7</td>


<td class="">4<br>5<br>9</td>
<td class="">80</td>
<td class="">2<br>8<br>0</td>


<td class="">1<br>5<br>7</td>
<td class="">36</td>
<td class="">4<br>6<br>6</td>

</tr>      <tr>
        <td>23/08/2021<br/>to<br/>28/08/2021</td>
      
<td class="">1<br>3<br>7</td>
<td class="">17</td>
<td class="">2<br>6<br>9</td>


<td class="">1<br>4<br>8</td>
<td class="">36</td>
<td class="">8<br>8<br>0</td>


<td class="r">6<br>6<br>0</td>
<td class="r">22</td>
<td class="r">1<br>5<br>6</td>


<td class="">7<br>8<br>8</td>
<td class="">31</td>
<td class="">5<br>8<br>8</td>


<td class="">2<br>7<br>8</td>
<td class="">71</td>
<td class="">4<br>8<br>9</td>


<td class="">3<br>4<br>0</td>
<td class="">74</td>
<td class="">1<br>6<br>7</td>

</tr>      <tr>
        <td>30/08/2021<br/>to<br/>04/09/2021</td>
      
<td class="">1<br>4<br>6</td>
<td class="">19</td>
<td class="">5<br>7<br>7</td>


<td class="">7<br>8<br>9</td>
<td class="">41</td>
<td class="">2<br>3<br>6</td>


<td class="">1<br>3<br>6</td>
<td class="">02</td>
<td class="">2<br>3<br>7</td>


<td class="">3<br>5<br>6</td>
<td class="">40</td>
<td class="">2<br>3<br>5</td>


<td class="">4<br>7<br>8</td>
<td class="">97</td>
<td class="">3<br>5<br>9</td>


<td class="r">2<br>6<br>9</td>
<td class="r">77</td>
<td class="r">3<br>4<br>0</td>

</tr>      <tr>
        <td>06/09/2021<br/>to<br/>11/09/2021</td>
      
<td class="r">3<br>5<br>7</td>
<td class="r">55</td>
<td class="r">2<br>6<br>7</td>


<td class="">1<br>2<br>6</td>
<td class="">90</td>
<td class="">4<br>6<br>0</td>


<td class="">7<br>7<br>0</td>
<td class="">41</td>
<td class="">1<br>3<br>7</td>


<td class="r">5<br>7<br>9</td>
<td class="r">11</td>
<td class="r">2<br>9<br>0</td>


<td class="">2<br>5<br>7</td>
<td class="">43</td>
<td class="">7<br>7<br>9</td>


<td class="">5<br>8<br>9</td>
<td class="">26</td>
<td class="">4<br>5<br>7</td>

</tr>      <tr>
        <td>13/09/2021<br/>to<br/>18/09/2021</td>
      
<td class="r">2<br>6<br>7</td>
<td class="r">50</td>
<td class="r">3<br>8<br>9</td>


<td class="">2<br>4<br>6</td>
<td class="">26</td>
<td class="">1<br>7<br>8</td>


<td class="">1<br>5<br>0</td>
<td class="">67</td>
<td class="">8<br>9<br>0</td>


<td class="">4<br>4<br>7</td>
<td class="">58</td>
<td class="">2<br>3<br>3</td>


<td class="">4<br>5<br>8</td>
<td class="">78</td>
<td class="">3<br>6<br>9</td>


<td class="">6<br>9<br>0</td>
<td class="">57</td>
<td class="">2<br>6<br>9</td>

</tr>      <tr>
        <td>20/09/2021<br/>to<br/>25/09/2021</td>
      
<td class="">3<br>5<br>9</td>
<td class="">78</td>
<td class="">9<br>9<br>0</td>


<td class="">3<br>6<br>7</td>
<td class="">67</td>
<td class="">3<br>6<br>8</td>


<td class="">4<br>5<br>8</td>
<td class="">74</td>
<td class="">2<br>3<br>9</td>


<td class="">1<br>5<br>5</td>
<td class="">10</td>
<td class="">2<br>3<br>5</td>


<td class="">3<br>6<br>0</td>
<td class="">95</td>
<td class="">2<br>3<br>0</td>


<td class="">2<br>2<br>7</td>
<td class="">10</td>
<td class="">6<br>6<br>8</td>

</tr>      <tr>
        <td>27/09/2021<br/>to<br/>02/10/2021</td>
      
<td class="r">1<br>3<br>4</td>
<td class="r">88</td>
<td class="r">2<br>7<br>9</td>


<td class="r">7<br>8<br>9</td>
<td class="r">49</td>
<td class="r">1<br>9<br>9</td>


<td class="">1<br>4<br>4</td>
<td class="">97</td>
<td class="">1<br>6<br>0</td>


<td class="">3<br>3<br>6</td>
<td class="">28</td>
<td class="">3<br>5<br>0</td>


<td class="r">8<br>9<br>0</td>
<td class="r">72</td>
<td class="r">5<br>7<br>0</td>


<td class="r">3<br>4<br>7</td>
<td class="r">44</td>
<td class="r">1<br>6<br>7</td>

</tr>      <tr>
        <td>04/10/2021<br/>to<br/>09/10/2021</td>
      
<td class="">1<br>8<br>8</td>
<td class="">78</td>
<td class="">2<br>3<br>3</td>


<td class="">1<br>2<br>7</td>
<td class="">08</td>
<td class="">1<br>3<br>4</td>


<td class="r">3<br>4<br>7</td>
<td class="r">44</td>
<td class="r">2<br>5<br>7</td>


<td class="">2<br>8<br>0</td>
<td class="">04</td>
<td class="">1<br>6<br>7</td>


<td class="r">5<br>6<br>7</td>
<td class="r">88</td>
<td class="r">1<br>1<br>6</td>


<td class="">2<br>3<br>8</td>
<td class="">37</td>
<td class="">2<br>6<br>9</td>

</tr>      <tr>
        <td>11/10/2021<br/>to<br/>16/10/2021</td>
      
<td class="">6<br>7<br>0</td>
<td class="">39</td>
<td class="">1<br>2<br>6</td>


<td class="">1<br>9<br>0</td>
<td class="">03</td>
<td class="">2<br>4<br>7</td>


<td class="">2<br>4<br>8</td>
<td class="">42</td>
<td class="">1<br>3<br>8</td>


<td class="r">1<br>2<br>5</td>
<td class="r">83</td>
<td class="r">4<br>4<br>5</td>


<td class="">2<br>4<br>7</td>
<td class="">39</td>
<td class="">1<br>8<br>0</td>


<td class="">2<br>5<br>9</td>
<td class="">68</td>
<td class="">2<br>6<br>0</td>

</tr>      <tr>
        <td>18/10/2021<br/>to<br/>23/10/2021</td>
      
<td class="r">6<br>7<br>9</td>
<td class="r">27</td>
<td class="r">4<br>5<br>8</td>


<td class="">3<br>8<br>0</td>
<td class="">15</td>
<td class="">3<br>4<br>8</td>


<td class="">6<br>7<br>8</td>
<td class="">10</td>
<td class="">5<br>5<br>0</td>


<td class="">8<br>9<br>0</td>
<td class="">76</td>
<td class="">1<br>1<br>4</td>


<td class="r">2<br>3<br>0</td>
<td class="r">50</td>
<td class="r">3<br>7<br>0</td>


<td class="r">4<br>6<br>9</td>
<td class="r">99</td>
<td class="r">4<br>7<br>8</td>

</tr>      <tr>
        <td>25/10/2021<br/>to<br/>30/10/2021</td>
      
<td class="">5<br>6<br>7</td>
<td class="">82</td>
<td class="">7<br>7<br>8</td>


<td class="">3<br>4<br>8</td>
<td class="">54</td>
<td class="">6<br>8<br>0</td>


<td class="">1<br>3<br>8</td>
<td class="">24</td>
<td class="">1<br>4<br>9</td>


<td class="r">2<br>7<br>8</td>
<td class="r">72</td>
<td class="r">4<br>9<br>9</td>


<td class="">2<br>3<br>7</td>
<td class="">25</td>
<td class="">7<br>8<br>0</td>


<td class="">3<br>7<br>8</td>
<td class="">84</td>
<td class="">2<br>5<br>7</td>

</tr>      <tr>
        <td>01/11/2021<br/>to<br/>06/11/2021</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>

</tr>      <tr>
        <td>08/11/2021<br/>to<br/>13/11/2021</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">1<br>5<br>0</td>
<td class="">60</td>
<td class="">2<br>8<br>0</td>


<td class="">3<br>3<br>5</td>
<td class="">19</td>
<td class="">2<br>2<br>5</td>


<td class="">5<br>7<br>9</td>
<td class="">19</td>
<td class="">4<br>7<br>8</td>


<td class="r">4<br>7<br>7</td>
<td class="r">88</td>
<td class="r">1<br>8<br>9</td>


<td class="">1<br>3<br>4</td>
<td class="">82</td>
<td class="">1<br>3<br>8</td>

</tr>      <tr>
        <td>15/11/2021<br/>to<br/>20/11/2021</td>
      
<td class="">1<br>3<br>0</td>
<td class="">41</td>
<td class="">3<br>3<br>5</td>


<td class="">3<br>6<br>0</td>
<td class="">98</td>
<td class="">1<br>3<br>4</td>


<td class="">1<br>3<br>0</td>
<td class="">40</td>
<td class="">1<br>9<br>0</td>


<td class="">1<br>5<br>6</td>
<td class="">23</td>
<td class="">6<br>8<br>9</td>


<td class="">2<br>9<br>9</td>
<td class="">03</td>
<td class="">6<br>8<br>9</td>


<td class="">4<br>6<br>0</td>
<td class="">01</td>
<td class="">6<br>7<br>8</td>

</tr>      <tr>
        <td>22/11/2021<br/>to<br/>27/11/2021</td>
      
<td class="">3<br>7<br>9</td>
<td class="">98</td>
<td class="">3<br>5<br>0</td>


<td class="">4<br>9<br>0</td>
<td class="">37</td>
<td class="">2<br>5<br>0</td>


<td class="">1<br>2<br>7</td>
<td class="">04</td>
<td class="">2<br>5<br>7</td>


<td class="">6<br>6<br>8</td>
<td class="">04</td>
<td class="">1<br>4<br>9</td>


<td class="">1<br>2<br>9</td>
<td class="">24</td>
<td class="">3<br>4<br>7</td>


<td class="">2<br>8<br>8</td>
<td class="">87</td>
<td class="">1<br>7<br>9</td>

</tr>      <tr>
        <td>29/11/2021<br/>to<br/>04/12/2021</td>
      
<td class="r">3<br>4<br>6</td>
<td class="r">38</td>
<td class="r">1<br>7<br>0</td>


<td class="">4<br>6<br>0</td>
<td class="">08</td>
<td class="">1<br>7<br>0</td>


<td class="">1<br>5<br>0</td>
<td class="">69</td>
<td class="">5<br>5<br>9</td>


<td class="">5<br>7<br>7</td>
<td class="">91</td>
<td class="">2<br>2<br>7</td>


<td class="">1<br>7<br>9</td>
<td class="">75</td>
<td class="">4<br>5<br>6</td>


<td class="">5<br>8<br>8</td>
<td class="">12</td>
<td class="">1<br>3<br>8</td>

</tr>      <tr>
        <td>06/12/2021<br/>to<br/>11/12/2021</td>
      
<td class="">2<br>3<br>6</td>
<td class="">14</td>
<td class="">4<br>0<br>0</td>


<td class="">1<br>6<br>0</td>
<td class="">76</td>
<td class="">4<br>4<br>8</td>


<td class="">8<br>9<br>9</td>
<td class="">69</td>
<td class="">1<br>4<br>4</td>


<td class="r">1<br>2<br>6</td>
<td class="r">94</td>
<td class="r">2<br>5<br>7</td>


<td class="r">3<br>4<br>5</td>
<td class="r">27</td>
<td class="r">5<br>6<br>6</td>


<td class="">7<br>8<br>0</td>
<td class="">54</td>
<td class="">4<br>0<br>0</td>

</tr>      <tr>
        <td>13/12/2021<br/>to<br/>18/12/2021</td>
      
<td class="">6<br>8<br>9</td>
<td class="">30</td>
<td class="">1<br>2<br>7</td>


<td class="r">2<br>3<br>0</td>
<td class="r">55</td>
<td class="r">3<br>6<br>6</td>


<td class="r">2<br>4<br>9</td>
<td class="r">55</td>
<td class="r">4<br>5<br>6</td>


<td class="">1<br>2<br>4</td>
<td class="">74</td>
<td class="">5<br>9<br>0</td>


<td class="">7<br>8<br>0</td>
<td class="">51</td>
<td class="">2<br>3<br>6</td>


<td class="">1<br>4<br>0</td>
<td class="">59</td>
<td class="">3<br>7<br>9</td>

</tr>      <tr>
        <td>20/12/2021<br/>to<br/>25/12/2021</td>
      
<td class="">3<br>4<br>8</td>
<td class="">57</td>
<td class="">8<br>9<br>0</td>


<td class="">5<br>7<br>8</td>
<td class="">09</td>
<td class="">1<br>2<br>6</td>


<td class="r">2<br>7<br>0</td>
<td class="r">99</td>
<td class="r">1<br>3<br>5</td>


<td class="r">7<br>8<br>8</td>
<td class="r">33</td>
<td class="r">3<br>4<br>6</td>


<td class="r">3<br>7<br>8</td>
<td class="r">88</td>
<td class="r">2<br>7<br>9</td>


<td class="r">1<br>7<br>0</td>
<td class="r">88</td>
<td class="r">3<br>5<br>0</td>

</tr>      <tr>
        <td>27/12/2021<br/>to<br/>01/01/2022</td>
      
<td class="">3<br>4<br>7</td>
<td class="">42</td>
<td class="">3<br>3<br>6</td>


<td class="">2<br>8<br>9</td>
<td class="">98</td>
<td class="">5<br>6<br>7</td>


<td class="">6<br>6<br>9</td>
<td class="">10</td>
<td class="">1<br>3<br>6</td>


<td class="r">4<br>5<br>9</td>
<td class="r">83</td>
<td class="r">1<br>4<br>8</td>


<td class="">2<br>6<br>7</td>
<td class="">57</td>
<td class="">2<br>6<br>9</td>


<td class="">5<br>6<br>0</td>
<td class="">15</td>
<td class="">6<br>9<br>0</td>

</tr>      <tr>
        <td>03/01/2022<br/>to<br/>08/01/2022</td>
      
<td class="">6<br>7<br>7</td>
<td class="">09</td>
<td class="">1<br>8<br>0</td>


<td class="">1<br>0<br>0</td>
<td class="">13</td>
<td class="">4<br>4<br>5</td>


<td class="">4<br>7<br>9</td>
<td class="">09</td>
<td class="">2<br>7<br>0</td>


<td class="">3<br>8<br>9</td>
<td class="">03</td>
<td class="">4<br>9<br>0</td>


<td class="">1<br>1<br>9</td>
<td class="">17</td>
<td class="">4<br>4<br>9</td>


<td class="">4<br>7<br>9</td>
<td class="">09</td>
<td class="">1<br>3<br>5</td>

</tr>      <tr>
        <td>10/01/2022<br/>to<br/>15/01/2022</td>
      
<td class="">1<br>4<br>5</td>
<td class="">03</td>
<td class="">6<br>7<br>0</td>


<td class="r">2<br>3<br>4</td>
<td class="r">94</td>
<td class="r">3<br>5<br>6</td>


<td class="">3<br>4<br>7</td>
<td class="">48</td>
<td class="">3<br>7<br>8</td>


<td class="">1<br>2<br>6</td>
<td class="">96</td>
<td class="">3<br>4<br>9</td>


<td class="">5<br>7<br>9</td>
<td class="">18</td>
<td class="">5<br>5<br>8</td>


<td class="">2<br>5<br>6</td>
<td class="">37</td>
<td class="">1<br>2<br>4</td>

</tr>      <tr>
        <td>17/01/2022<br/>to<br/>22/01/2022</td>
      
<td class="">5<br>6<br>8</td>
<td class="">96</td>
<td class="">1<br>1<br>4</td>


<td class="">4<br>5<br>8</td>
<td class="">70</td>
<td class="">1<br>3<br>6</td>


<td class="r">3<br>4<br>0</td>
<td class="r">77</td>
<td class="r">4<br>5<br>8</td>


<td class="r">2<br>2<br>3</td>
<td class="r">77</td>
<td class="r">4<br>6<br>7</td>


<td class="">4<br>4<br>6</td>
<td class="">45</td>
<td class="">2<br>4<br>9</td>


<td class="r">4<br>4<br>6</td>
<td class="r">49</td>
<td class="r">1<br>8<br>0</td>

</tr>      <tr>
        <td>24/01/2022<br/>to<br/>29/01/2022</td>
      
<td class="">4<br>5<br>9</td>
<td class="">86</td>
<td class="">3<br>5<br>8</td>


<td class="">4<br>5<br>8</td>
<td class="">70</td>
<td class="">3<br>3<br>4</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">1<br>5<br>7</td>
<td class="">39</td>
<td class="">4<br>5<br>0</td>


<td class="">4<br>5<br>7</td>
<td class="">68</td>
<td class="">4<br>5<br>9</td>


<td class="">7<br>9<br>0</td>
<td class="">65</td>
<td class="">8<br>8<br>9</td>

</tr>      <tr>
        <td>31/01/2022<br/>to<br/>05/02/2022</td>
      
<td class="">4<br>7<br>9</td>
<td class="">08</td>
<td class="">5<br>6<br>7</td>


<td class="">2<br>4<br>4</td>
<td class="">01</td>
<td class="">5<br>8<br>8</td>


<td class="">5<br>6<br>8</td>
<td class="">91</td>
<td class="">6<br>6<br>9</td>


<td class="">1<br>7<br>0</td>
<td class="">81</td>
<td class="">1<br>4<br>6</td>


<td class="">3<br>5<br>9</td>
<td class="">74</td>
<td class="">7<br>7<br>0</td>


<td class="">5<br>6<br>9</td>
<td class="">02</td>
<td class="">6<br>7<br>9</td>

</tr>      <tr>
        <td>07/02/2022<br/>to<br/>12/02/2022</td>
      
<td class="r">6<br>7<br>0</td>
<td class="r">38</td>
<td class="r">9<br>9<br>0</td>


<td class="">5<br>9<br>9</td>
<td class="">36</td>
<td class="">1<br>5<br>0</td>


<td class="">1<br>6<br>8</td>
<td class="">53</td>
<td class="">1<br>5<br>7</td>


<td class="">4<br>5<br>6</td>
<td class="">52</td>
<td class="">1<br>3<br>8</td>


<td class="">2<br>3<br>8</td>
<td class="">36</td>
<td class="">8<br>8<br>0</td>


<td class="">3<br>5<br>7</td>
<td class="">52</td>
<td class="">2<br>3<br>7</td>

</tr>      <tr>
        <td>14/02/2022<br/>to<br/>19/02/2022</td>
      
<td class="">1<br>6<br>7</td>
<td class="">41</td>
<td class="">5<br>6<br>0</td>


<td class="">3<br>3<br>5</td>
<td class="">14</td>
<td class="">5<br>9<br>0</td>


<td class="">1<br>4<br>7</td>
<td class="">24</td>
<td class="">2<br>5<br>7</td>


<td class="">2<br>3<br>0</td>
<td class="">52</td>
<td class="">2<br>4<br>6</td>


<td class="">1<br>2<br>3</td>
<td class="">64</td>
<td class="">3<br>5<br>6</td>


<td class="">4<br>9<br>9</td>
<td class="">23</td>
<td class="">1<br>4<br>8</td>

</tr>      <tr>
        <td>21/02/2022<br/>to<br/>26/02/2022</td>
      
<td class="">1<br>6<br>7</td>
<td class="">40</td>
<td class="">5<br>7<br>8</td>


<td class="">2<br>5<br>6</td>
<td class="">31</td>
<td class="">4<br>8<br>9</td>


<td class="r">2<br>4<br>0</td>
<td class="r">66</td>
<td class="r">4<br>4<br>8</td>


<td class="r">3<br>8<br>9</td>
<td class="r">05</td>
<td class="r">6<br>9<br>0</td>


<td class="">6<br>6<br>8</td>
<td class="">01</td>
<td class="">3<br>4<br>4</td>


<td class="">1<br>5<br>8</td>
<td class="">43</td>
<td class="">6<br>7<br>0</td>

</tr>      <tr>
        <td>28/02/2022<br/>to<br/>05/03/2022</td>
      
<td class="">1<br>7<br>8</td>
<td class="">69</td>
<td class="">1<br>2<br>6</td>


<td class="r">3<br>5<br>6</td>
<td class="r">49</td>
<td class="r">2<br>2<br>5</td>


<td class="">4<br>8<br>9</td>
<td class="">15</td>
<td class="">7<br>8<br>0</td>


<td class="">2<br>3<br>6</td>
<td class="">18</td>
<td class="">1<br>2<br>5</td>


<td class="">1<br>4<br>9</td>
<td class="">42</td>
<td class="">1<br>5<br>6</td>


<td class="r">3<br>5<br>0</td>
<td class="r">83</td>
<td class="r">2<br>3<br>8</td>

</tr>      <tr>
        <td>07/03/2022<br/>to<br/>12/03/2022</td>
      
<td class="">6<br>8<br>9</td>
<td class="">30</td>
<td class="">5<br>7<br>8</td>


<td class="r">9<br>9<br>0</td>
<td class="r">83</td>
<td class="r">1<br>5<br>7</td>


<td class="">1<br>7<br>0</td>
<td class="">87</td>
<td class="">8<br>9<br>0</td>


<td class="">3<br>8<br>0</td>
<td class="">15</td>
<td class="">2<br>6<br>7</td>


<td class="">3<br>6<br>8</td>
<td class="">71</td>
<td class="">1<br>2<br>8</td>


<td class="">2<br>4<br>5</td>
<td class="">18</td>
<td class="">2<br>6<br>0</td>

</tr>      <tr>
        <td>14/03/2022<br/>to<br/>19/03/2022</td>
      
<td class="r">5<br>7<br>8</td>
<td class="r">00</td>
<td class="r">5<br>6<br>9</td>


<td class="">3<br>5<br>6</td>
<td class="">43</td>
<td class="">5<br>8<br>0</td>


<td class="">2<br>4<br>8</td>
<td class="">46</td>
<td class="">1<br>5<br>0</td>


<td class="">3<br>6<br>8</td>
<td class="">73</td>
<td class="">2<br>3<br>8</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">3<br>4<br>5</td>
<td class="">26</td>
<td class="">1<br>5<br>0</td>

</tr>      <tr>
        <td>21/03/2022<br/>to<br/>26/03/2022</td>
      
<td class="">5<br>8<br>0</td>
<td class="">32</td>
<td class="">2<br>0<br>0</td>


<td class="">2<br>4<br>4</td>
<td class="">03</td>
<td class="">1<br>3<br>9</td>


<td class="">2<br>5<br>8</td>
<td class="">59</td>
<td class="">5<br>7<br>7</td>


<td class="">4<br>7<br>8</td>
<td class="">91</td>
<td class="">3<br>3<br>5</td>


<td class="">4<br>6<br>9</td>
<td class="">95</td>
<td class="">1<br>6<br>8</td>


<td class="">2<br>4<br>4</td>
<td class="">09</td>
<td class="">3<br>7<br>9</td>

</tr>      <tr>
        <td>28/03/2022<br/>to<br/>02/04/2022</td>
      
<td class="">3<br>4<br>0</td>
<td class="">76</td>
<td class="">1<br>6<br>9</td>


<td class="">2<br>7<br>0</td>
<td class="">92</td>
<td class="">4<br>9<br>9</td>


<td class="">5<br>8<br>0</td>
<td class="">36</td>
<td class="">3<br>6<br>7</td>


<td class="">1<br>8<br>0</td>
<td class="">93</td>
<td class="">5<br>8<br>0</td>


<td class="">6<br>7<br>9</td>
<td class="">20</td>
<td class="">3<br>8<br>9</td>


<td class="">1<br>2<br>7</td>
<td class="">09</td>
<td class="">4<br>6<br>9</td>

</tr>      <tr>
        <td>04/04/2022<br/>to<br/>09/04/2022</td>
      
<td class="">2<br>6<br>9</td>
<td class="">79</td>
<td class="">1<br>3<br>5</td>


<td class="">1<br>4<br>9</td>
<td class="">42</td>
<td class="">1<br>5<br>6</td>


<td class="">1<br>3<br>5</td>
<td class="">93</td>
<td class="">1<br>4<br>8</td>


<td class="">1<br>8<br>9</td>
<td class="">86</td>
<td class="">4<br>6<br>6</td>


<td class="">2<br>4<br>9</td>
<td class="">54</td>
<td class="">3<br>4<br>7</td>


<td class="">2<br>6<br>7</td>
<td class="">51</td>
<td class="">4<br>8<br>9</td>

</tr>      <tr>
        <td>11/04/2022<br/>to<br/>16/04/2022</td>
      
<td class="">4<br>7<br>0</td>
<td class="">12</td>
<td class="">5<br>7<br>0</td>


<td class="">1<br>4<br>7</td>
<td class="">26</td>
<td class="">1<br>2<br>3</td>


<td class="">3<br>4<br>5</td>
<td class="">26</td>
<td class="">3<br>6<br>7</td>


<td class="">2<br>3<br>7</td>
<td class="">26</td>
<td class="">8<br>9<br>9</td>


<td class="r">1<br>3<br>0</td>
<td class="r">49</td>
<td class="r">3<br>6<br>0</td>


<td class="">2<br>9<br>0</td>
<td class="">19</td>
<td class="">5<br>7<br>7</td>

</tr>      <tr>
        <td>18/04/2022<br/>to<br/>23/04/2022</td>
      
<td class="r">3<br>4<br>4</td>
<td class="r">11</td>
<td class="r">2<br>9<br>0</td>


<td class="">4<br>5<br>6</td>
<td class="">52</td>
<td class="">5<br>8<br>9</td>


<td class="">1<br>3<br>4</td>
<td class="">81</td>
<td class="">3<br>8<br>0</td>


<td class="">4<br>5<br>9</td>
<td class="">80</td>
<td class="">1<br>9<br>0</td>


<td class="r">4<br>5<br>7</td>
<td class="r">61</td>
<td class="r">4<br>8<br>9</td>


<td class="">1<br>1<br>3</td>
<td class="">57</td>
<td class="">3<br>7<br>7</td>

</tr>      <tr>
        <td>25/04/2022<br/>to<br/>30/04/2022</td>
      
<td class="">5<br>9<br>0</td>
<td class="">45</td>
<td class="">6<br>9<br>0</td>


<td class="">1<br>6<br>7</td>
<td class="">48</td>
<td class="">3<br>7<br>8</td>


<td class="r">1<br>2<br>8</td>
<td class="r">11</td>
<td class="r">4<br>7<br>0</td>


<td class="">5<br>6<br>9</td>
<td class="">03</td>
<td class="">3<br>4<br>6</td>


<td class="">1<br>5<br>6</td>
<td class="">20</td>
<td class="">5<br>7<br>8</td>


<td class="r">4<br>7<br>0</td>
<td class="r">16</td>
<td class="r">3<br>5<br>8</td>

</tr>      <tr>
        <td>02/05/2022<br/>to<br/>07/05/2022</td>
      
<td class="">1<br>7<br>0</td>
<td class="">80</td>
<td class="">4<br>7<br>9</td>


<td class="">1<br>3<br>5</td>
<td class="">97</td>
<td class="">1<br>7<br>9</td>


<td class="">5<br>6<br>0</td>
<td class="">13</td>
<td class="">1<br>2<br>0</td>


<td class="">1<br>4<br>7</td>
<td class="">24</td>
<td class="">2<br>3<br>9</td>


<td class="r">1<br>3<br>3</td>
<td class="r">77</td>
<td class="r">4<br>4<br>9</td>


<td class="r">3<br>7<br>9</td>
<td class="r">99</td>
<td class="r">1<br>2<br>6</td>

</tr>      <tr>
        <td>09/05/2022<br/>to<br/>14/05/2022</td>
      
<td class="">1<br>9<br>0</td>
<td class="">04</td>
<td class="">1<br>5<br>8</td>


<td class="">7<br>8<br>9</td>
<td class="">48</td>
<td class="">4<br>7<br>7</td>


<td class="">4<br>7<br>9</td>
<td class="">08</td>
<td class="">4<br>6<br>8</td>


<td class="r">3<br>4<br>8</td>
<td class="r">55</td>
<td class="r">1<br>6<br>8</td>


<td class="r">2<br>3<br>6</td>
<td class="r">11</td>
<td class="r">3<br>8<br>0</td>


<td class="">2<br>4<br>0</td>
<td class="">69</td>
<td class="">2<br>3<br>4</td>

</tr>      <tr>
        <td>16/05/2022<br/>to<br/>21/05/2022</td>
      
<td class="">2<br>5<br>9</td>
<td class="">62</td>
<td class="">4<br>8<br>0</td>


<td class="">3<br>4<br>6</td>
<td class="">30</td>
<td class="">1<br>2<br>7</td>


<td class="">2<br>5<br>9</td>
<td class="">67</td>
<td class="">4<br>5<br>8</td>


<td class="">1<br>2<br>0</td>
<td class="">30</td>
<td class="">5<br>7<br>8</td>


<td class="">2<br>3<br>8</td>
<td class="">39</td>
<td class="">2<br>7<br>0</td>


<td class="">1<br>6<br>7</td>
<td class="">42</td>
<td class="">3<br>9<br>0</td>

</tr>      <tr>
        <td>23/05/2022<br/>to<br/>28/05/2022</td>
      
<td class="r">2<br>5<br>6</td>
<td class="r">33</td>
<td class="r">2<br>3<br>8</td>


<td class="">5<br>6<br>9</td>
<td class="">02</td>
<td class="">5<br>8<br>9</td>


<td class="">5<br>6<br>7</td>
<td class="">82</td>
<td class="">1<br>3<br>8</td>


<td class="r">4<br>8<br>9</td>
<td class="r">16</td>
<td class="r">2<br>7<br>7</td>


<td class="r">7<br>9<br>0</td>
<td class="r">61</td>
<td class="r">2<br>3<br>6</td>


<td class="">1<br>3<br>0</td>
<td class="">40</td>
<td class="">3<br>8<br>9</td>

</tr>      <tr>
        <td>30/05/2022<br/>to<br/>04/06/2022</td>
      
<td class="">1<br>2<br>4</td>
<td class="">73</td>
<td class="">1<br>3<br>9</td>


<td class="">7<br>8<br>9</td>
<td class="">47</td>
<td class="">3<br>4<br>0</td>


<td class="">3<br>4<br>8</td>
<td class="">54</td>
<td class="">2<br>6<br>6</td>


<td class="">2<br>6<br>6</td>
<td class="">42</td>
<td class="">6<br>7<br>9</td>


<td class="">6<br>9<br>0</td>
<td class="">57</td>
<td class="">7<br>0<br>0</td>


<td class="r">1<br>7<br>7</td>
<td class="r">50</td>
<td class="r">2<br>2<br>6</td>

</tr>      <tr>
        <td>06/06/2022<br/>to<br/>11/06/2022</td>
      
<td class="r">3<br>6<br>8</td>
<td class="r">77</td>
<td class="r">1<br>3<br>3</td>


<td class="r">3<br>6<br>9</td>
<td class="r">83</td>
<td class="r">7<br>7<br>9</td>


<td class="">1<br>5<br>0</td>
<td class="">68</td>
<td class="">5<br>6<br>7</td>


<td class="">1<br>8<br>9</td>
<td class="">80</td>
<td class="">4<br>6<br>0</td>


<td class="">1<br>4<br>5</td>
<td class="">02</td>
<td class="">7<br>7<br>8</td>


<td class="">5<br>6<br>8</td>
<td class="">90</td>
<td class="">3<br>3<br>4</td>

</tr>      <tr>
        <td>13/06/2022<br/>to<br/>18/06/2022</td>
      
<td class="">4<br>6<br>9</td>
<td class="">90</td>
<td class="">6<br>7<br>7</td>


<td class="">2<br>2<br>7</td>
<td class="">10</td>
<td class="">4<br>7<br>9</td>


<td class="">2<br>3<br>3</td>
<td class="">80</td>
<td class="">2<br>3<br>5</td>


<td class="">1<br>3<br>4</td>
<td class="">89</td>
<td class="">2<br>8<br>9</td>


<td class="">5<br>7<br>8</td>
<td class="">06</td>
<td class="">2<br>5<br>9</td>


<td class="">6<br>7<br>7</td>
<td class="">06</td>
<td class="">4<br>5<br>7</td>

</tr>      <tr>
        <td>20/06/2022<br/>to<br/>25/06/2022</td>
      
<td class="">1<br>2<br>4</td>
<td class="">74</td>
<td class="">2<br>5<br>7</td>


<td class="r">7<br>9<br>0</td>
<td class="r">61</td>
<td class="r">2<br>4<br>5</td>


<td class="">4<br>8<br>0</td>
<td class="">29</td>
<td class="">2<br>3<br>4</td>


<td class="">1<br>5<br>0</td>
<td class="">62</td>
<td class="">1<br>4<br>7</td>


<td class="">2<br>7<br>8</td>
<td class="">78</td>
<td class="">1<br>2<br>5</td>


<td class="">6<br>7<br>9</td>
<td class="">21</td>
<td class="">5<br>7<br>9</td>

</tr>      <tr>
        <td>27/06/2022<br/>to<br/>02/07/2022</td>
      
<td class="r">1<br>9<br>0</td>
<td class="r">05</td>
<td class="r">7<br>8<br>0</td>


<td class="r">1<br>5<br>8</td>
<td class="r">49</td>
<td class="r">1<br>2<br>6</td>


<td class="">7<br>8<br>9</td>
<td class="">43</td>
<td class="">6<br>8<br>9</td>


<td class="">5<br>9<br>0</td>
<td class="">46</td>
<td class="">2<br>5<br>9</td>


<td class="">1<br>5<br>8</td>
<td class="">47</td>
<td class="">8<br>9<br>0</td>


<td class="">1<br>5<br>7</td>
<td class="">37</td>
<td class="">3<br>5<br>9</td>

</tr>      <tr>
        <td>04/07/2022<br/>to<br/>09/07/2022</td>
      
<td class="">1<br>6<br>8</td>
<td class="">53</td>
<td class="">1<br>2<br>0</td>


<td class="">2<br>7<br>9</td>
<td class="">81</td>
<td class="">1<br>3<br>7</td>


<td class="">1<br>7<br>0</td>
<td class="">81</td>
<td class="">1<br>2<br>8</td>


<td class="">6<br>8<br>0</td>
<td class="">41</td>
<td class="">5<br>7<br>9</td>


<td class="">3<br>7<br>8</td>
<td class="">81</td>
<td class="">5<br>7<br>9</td>


<td class="">1<br>4<br>5</td>
<td class="">02</td>
<td class="">6<br>6<br>0</td>

</tr>      <tr>
        <td>11/07/2022<br/>to<br/>16/07/2022</td>
      
<td class="">1<br>7<br>8</td>
<td class="">69</td>
<td class="">2<br>8<br>9</td>


<td class="">6<br>7<br>8</td>
<td class="">10</td>
<td class="">4<br>6<br>0</td>


<td class="">2<br>7<br>9</td>
<td class="">87</td>
<td class="">3<br>6<br>8</td>


<td class="">2<br>3<br>5</td>
<td class="">01</td>
<td class="">3<br>9<br>9</td>


<td class="">1<br>4<br>6</td>
<td class="">18</td>
<td class="">3<br>5<br>0</td>


<td class="">2<br>8<br>9</td>
<td class="">98</td>
<td class="">5<br>6<br>7</td>

</tr>      <tr>
        <td>18/07/2022<br/>to<br/>23/07/2022</td>
      
<td class="">3<br>6<br>9</td>
<td class="">84</td>
<td class="">5<br>9<br>0</td>


<td class="">2<br>3<br>7</td>
<td class="">24</td>
<td class="">1<br>5<br>8</td>


<td class="">3<br>4<br>5</td>
<td class="">23</td>
<td class="">2<br>5<br>6</td>


<td class="">4<br>6<br>8</td>
<td class="">87</td>
<td class="">2<br>6<br>9</td>


<td class="">1<br>5<br>6</td>
<td class="">23</td>
<td class="">4<br>9<br>0</td>


<td class="">2<br>4<br>5</td>
<td class="">19</td>
<td class="">4<br>7<br>8</td>

</tr>      <tr>
        <td>25/07/2022<br/>to<br/>30/07/2022</td>
      
<td class="">3<br>5<br>9</td>
<td class="">79</td>
<td class="">2<br>7<br>0</td>


<td class="">3<br>5<br>0</td>
<td class="">87</td>
<td class="">5<br>6<br>6</td>


<td class="">4<br>7<br>0</td>
<td class="">12</td>
<td class="">2<br>3<br>7</td>


<td class="">3<br>3<br>6</td>
<td class="">21</td>
<td class="">5<br>7<br>9</td>


<td class="">2<br>5<br>9</td>
<td class="">69</td>
<td class="">9<br>0<br>0</td>


<td class="">7<br>7<br>8</td>
<td class="">21</td>
<td class="">3<br>4<br>4</td>

</tr>      <tr>
        <td>01/08/2022<br/>to<br/>06/08/2022</td>
      
<td class="">1<br>2<br>6</td>
<td class="">97</td>
<td class="">1<br>6<br>0</td>


<td class="">1<br>4<br>8</td>
<td class="">30</td>
<td class="">3<br>8<br>9</td>


<td class="">8<br>9<br>0</td>
<td class="">76</td>
<td class="">2<br>5<br>9</td>


<td class="r">1<br>1<br>6</td>
<td class="r">88</td>
<td class="r">8<br>0<br>0</td>


<td class="">2<br>4<br>7</td>
<td class="">31</td>
<td class="">2<br>2<br>7</td>


<td class="">2<br>5<br>8</td>
<td class="">57</td>
<td class="">5<br>6<br>6</td>

</tr>      <tr>
        <td>08/08/2022<br/>to<br/>13/08/2022</td>
      
<td class="r">1<br>2<br>0</td>
<td class="r">33</td>
<td class="r">7<br>7<br>9</td>


<td class="r">2<br>3<br>9</td>
<td class="r">44</td>
<td class="r">1<br>4<br>9</td>


<td class="">3<br>7<br>9</td>
<td class="">98</td>
<td class="">3<br>5<br>0</td>


<td class="">4<br>0<br>0</td>
<td class="">47</td>
<td class="">1<br>8<br>8</td>


<td class="r">2<br>2<br>9</td>
<td class="r">33</td>
<td class="r">2<br>4<br>7</td>


<td class="">1<br>3<br>4</td>
<td class="">86</td>
<td class="">3<br>4<br>9</td>

</tr>      <tr>
        <td>15/08/2022<br/>to<br/>20/08/2022</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">2<br>7<br>0</td>
<td class="r">94</td>
<td class="r">1<br>1<br>2</td>


<td class="">2<br>2<br>7</td>
<td class="">14</td>
<td class="">1<br>6<br>7</td>


<td class="">1<br>7<br>7</td>
<td class="">56</td>
<td class="">8<br>8<br>0</td>


<td class="">2<br>8<br>0</td>
<td class="">03</td>
<td class="">5<br>9<br>9</td>


<td class="">1<br>7<br>7</td>
<td class="">52</td>
<td class="">2<br>3<br>7</td>

</tr>      <tr>
        <td>22/08/2022<br/>to<br/>27/08/2022</td>
      
<td class="">1<br>2<br>5</td>
<td class="">89</td>
<td class="">5<br>6<br>8</td>


<td class="">3<br>5<br>8</td>
<td class="">60</td>
<td class="">2<br>4<br>4</td>


<td class="">2<br>5<br>7</td>
<td class="">48</td>
<td class="">1<br>3<br>4</td>


<td class="">2<br>7<br>9</td>
<td class="">84</td>
<td class="">2<br>4<br>8</td>


<td class="">1<br>6<br>7</td>
<td class="">41</td>
<td class="">4<br>8<br>9</td>


<td class="r">8<br>8<br>0</td>
<td class="r">61</td>
<td class="r">1<br>1<br>9</td>

</tr>      <tr>
        <td>29/08/2022<br/>to<br/>03/09/2022</td>
      
<td class="">2<br>3<br>0</td>
<td class="">59</td>
<td class="">2<br>7<br>0</td>


<td class="">5<br>7<br>0</td>
<td class="">25</td>
<td class="">3<br>5<br>7</td>


<td class="r">7<br>8<br>0</td>
<td class="r">50</td>
<td class="r">4<br>6<br>0</td>


<td class="">1<br>2<br>7</td>
<td class="">01</td>
<td class="">4<br>8<br>9</td>


<td class="r">1<br>2<br>7</td>
<td class="r">05</td>
<td class="r">2<br>6<br>7</td>


<td class="">3<br>3<br>5</td>
<td class="">13</td>
<td class="">3<br>3<br>7</td>

</tr>      <tr>
        <td>05/09/2022<br/>to<br/>10/09/2022</td>
      
<td class="">3<br>7<br>8</td>
<td class="">89</td>
<td class="">5<br>5<br>9</td>


<td class="">2<br>4<br>9</td>
<td class="">54</td>
<td class="">1<br>1<br>2</td>


<td class="">5<br>7<br>8</td>
<td class="">03</td>
<td class="">7<br>8<br>8</td>


<td class="">5<br>7<br>9</td>
<td class="">19</td>
<td class="">1<br>9<br>9</td>


<td class="">3<br>5<br>0</td>
<td class="">89</td>
<td class="">4<br>7<br>8</td>


<td class="">2<br>5<br>8</td>
<td class="">59</td>
<td class="">9<br>0<br>0</td>

</tr>      <tr>
        <td>12/09/2022<br/>to<br/>17/09/2022</td>
      
<td class="r">7<br>0<br>0</td>
<td class="r">77</td>
<td class="r">1<br>7<br>9</td>


<td class="">1<br>9<br>0</td>
<td class="">08</td>
<td class="">5<br>6<br>7</td>


<td class="">5<br>8<br>9</td>
<td class="">21</td>
<td class="">3<br>4<br>4</td>


<td class="r">5<br>9<br>0</td>
<td class="r">49</td>
<td class="r">2<br>2<br>5</td>


<td class="r">6<br>8<br>8</td>
<td class="r">22</td>
<td class="r">2<br>4<br>6</td>


<td class="r">1<br>5<br>6</td>
<td class="r">27</td>
<td class="r">1<br>2<br>4</td>

</tr>      <tr>
        <td>19/09/2022<br/>to<br/>24/09/2022</td>
      
<td class="">1<br>4<br>6</td>
<td class="">14</td>
<td class="">6<br>8<br>0</td>


<td class="">6<br>7<br>8</td>
<td class="">18</td>
<td class="">2<br>3<br>3</td>


<td class="">2<br>4<br>5</td>
<td class="">14</td>
<td class="">7<br>8<br>9</td>


<td class="">1<br>7<br>8</td>
<td class="">63</td>
<td class="">1<br>5<br>7</td>


<td class="">1<br>6<br>0</td>
<td class="">76</td>
<td class="">2<br>7<br>7</td>


<td class="">2<br>3<br>6</td>
<td class="">13</td>
<td class="">1<br>3<br>9</td>

</tr>      <tr>
        <td>26/09/2022<br/>to<br/>01/10/2022</td>
      
<td class="">7<br>0<br>0</td>
<td class="">73</td>
<td class="">1<br>3<br>9</td>


<td class="">4<br>0<br>0</td>
<td class="">43</td>
<td class="">1<br>6<br>6</td>


<td class="">7<br>8<br>9</td>
<td class="">40</td>
<td class="">1<br>2<br>7</td>


<td class="">4<br>9<br>0</td>
<td class="">30</td>
<td class="">4<br>8<br>8</td>


<td class="">6<br>9<br>9</td>
<td class="">43</td>
<td class="">2<br>2<br>9</td>


<td class="">3<br>3<br>8</td>
<td class="">42</td>
<td class="">7<br>7<br>8</td>

</tr>      <tr>
        <td>03/10/2022<br/>to<br/>08/10/2022</td>
      
<td class="r">4<br>5<br>7</td>
<td class="r">61</td>
<td class="r">1<br>4<br>6</td>


<td class="">1<br>2<br>9</td>
<td class="">28</td>
<td class="">3<br>5<br>0</td>


<td class="">6<br>8<br>9</td>
<td class="">39</td>
<td class="">2<br>3<br>4</td>


<td class="">7<br>7<br>9</td>
<td class="">36</td>
<td class="">4<br>5<br>7</td>


<td class="">2<br>9<br>9</td>
<td class="">06</td>
<td class="">3<br>5<br>8</td>


<td class="">5<br>7<br>7</td>
<td class="">95</td>
<td class="">6<br>9<br>0</td>

</tr>      <tr>
        <td>10/10/2022<br/>to<br/>15/10/2022</td>
      
<td class="">3<br>5<br>8</td>
<td class="">63</td>
<td class="">7<br>8<br>8</td>


<td class="r">3<br>6<br>0</td>
<td class="r">94</td>
<td class="r">6<br>8<br>0</td>


<td class="">1<br>1<br>8</td>
<td class="">07</td>
<td class="">4<br>4<br>9</td>


<td class="">3<br>7<br>8</td>
<td class="">80</td>
<td class="">5<br>6<br>9</td>


<td class="">5<br>6<br>6</td>
<td class="">74</td>
<td class="">4<br>5<br>5</td>


<td class="">1<br>1<br>0</td>
<td class="">20</td>
<td class="">1<br>4<br>5</td>

</tr>      <tr>
        <td>17/10/2022<br/>to<br/>22/10/2022</td>
      
<td class="r">5<br>6<br>8</td>
<td class="r">94</td>
<td class="r">2<br>4<br>8</td>


<td class="r">2<br>5<br>0</td>
<td class="r">77</td>
<td class="r">1<br>7<br>9</td>


<td class="">1<br>6<br>0</td>
<td class="">74</td>
<td class="">1<br>4<br>9</td>


<td class="r">4<br>5<br>7</td>
<td class="r">61</td>
<td class="r">5<br>7<br>9</td>


<td class="r">6<br>6<br>8</td>
<td class="r">00</td>
<td class="r">2<br>8<br>0</td>


<td class="">8<br>8<br>9</td>
<td class="">53</td>
<td class="">1<br>6<br>6</td>

</tr>      <tr>
        <td>24/10/2022<br/>to<br/>29/10/2022</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">4<br>6<br>8</td>
<td class="">81</td>
<td class="">1<br>4<br>6</td>


<td class="r">2<br>5<br>7</td>
<td class="r">49</td>
<td class="r">3<br>6<br>0</td>


<td class="">1<br>3<br>4</td>
<td class="">89</td>
<td class="">1<br>8<br>0</td>


<td class="">3<br>4<br>6</td>
<td class="">36</td>
<td class="">2<br>6<br>8</td>


<td class="r">3<br>4<br>4</td>
<td class="r">11</td>
<td class="r">1<br>3<br>7</td>

</tr>      <tr>
        <td>31/10/2022<br/>to<br/>05/11/2022</td>
      
<td class="">1<br>5<br>9</td>
<td class="">54</td>
<td class="">7<br>8<br>9</td>


<td class="r">3<br>6<br>7</td>
<td class="r">61</td>
<td class="r">2<br>4<br>5</td>


<td class="r">2<br>5<br>9</td>
<td class="r">66</td>
<td class="r">8<br>9<br>9</td>


<td class="">6<br>7<br>0</td>
<td class="">34</td>
<td class="">1<br>1<br>2</td>


<td class="r">1<br>2<br>6</td>
<td class="r">94</td>
<td class="r">6<br>8<br>0</td>


<td class="">5<br>8<br>8</td>
<td class="">18</td>
<td class="">2<br>2<br>4</td>

</tr>      <tr>
        <td>07/11/2022<br/>to<br/>12/11/2022</td>
      
<td class="">5<br>5<br>7</td>
<td class="">76</td>
<td class="">4<br>6<br>6</td>


<td class="">7<br>9<br>0</td>
<td class="">65</td>
<td class="">3<br>5<br>7</td>


<td class="r">5<br>7<br>0</td>
<td class="r">22</td>
<td class="r">3<br>3<br>6</td>


<td class="">3<br>7<br>8</td>
<td class="">82</td>
<td class="">3<br>4<br>5</td>


<td class="">5<br>6<br>7</td>
<td class="">81</td>
<td class="">4<br>7<br>0</td>


<td class="">2<br>7<br>0</td>
<td class="">92</td>
<td class="">6<br>8<br>8</td>

</tr>      <tr>
        <td>14/11/2022<br/>to<br/>19/11/2022</td>
      
<td class="">4<br>6<br>8</td>
<td class="">82</td>
<td class="">7<br>7<br>8</td>


<td class="">2<br>2<br>4</td>
<td class="">85</td>
<td class="">4<br>5<br>6</td>


<td class="">2<br>8<br>9</td>
<td class="">97</td>
<td class="">1<br>8<br>8</td>


<td class="r">1<br>8<br>0</td>
<td class="r">94</td>
<td class="r">3<br>4<br>7</td>


<td class="r">1<br>6<br>6</td>
<td class="r">38</td>
<td class="r">4<br>5<br>9</td>


<td class="">5<br>6<br>8</td>
<td class="">96</td>
<td class="">3<br>6<br>7</td>

</tr>      <tr>
        <td>21/11/2022<br/>to<br/>26/11/2022</td>
      
<td class="r">4<br>5<br>7</td>
<td class="r">66</td>
<td class="r">2<br>5<br>9</td>


<td class="">8<br>8<br>0</td>
<td class="">62</td>
<td class="">1<br>3<br>8</td>


<td class="r">2<br>4<br>9</td>
<td class="r">50</td>
<td class="r">1<br>3<br>6</td>


<td class="">1<br>5<br>9</td>
<td class="">53</td>
<td class="">6<br>8<br>9</td>


<td class="r">2<br>4<br>9</td>
<td class="r">55</td>
<td class="r">3<br>6<br>6</td>


<td class="r">7<br>9<br>0</td>
<td class="r">61</td>
<td class="r">5<br>8<br>8</td>

</tr>      <tr>
        <td>28/11/2022<br/>to<br/>03/12/2022</td>
      
<td class="">1<br>8<br>0</td>
<td class="">97</td>
<td class="">2<br>6<br>9</td>


<td class="">2<br>3<br>8</td>
<td class="">35</td>
<td class="">1<br>6<br>8</td>


<td class="">7<br>7<br>8</td>
<td class="">21</td>
<td class="">5<br>8<br>8</td>


<td class="">1<br>3<br>8</td>
<td class="">26</td>
<td class="">4<br>4<br>8</td>


<td class="">5<br>9<br>9</td>
<td class="">32</td>
<td class="">4<br>9<br>9</td>


<td class="r">6<br>7<br>7</td>
<td class="r">00</td>
<td class="r">3<br>7<br>0</td>

</tr>      <tr>
        <td>05/12/2022<br/>to<br/>10/12/2022</td>
      
<td class="r">4<br>6<br>7</td>
<td class="r">72</td>
<td class="r">1<br>4<br>7</td>


<td class="">2<br>4<br>7</td>
<td class="">30</td>
<td class="">1<br>3<br>6</td>


<td class="">6<br>9<br>9</td>
<td class="">46</td>
<td class="">1<br>7<br>8</td>


<td class="">1<br>4<br>4</td>
<td class="">95</td>
<td class="">2<br>3<br>0</td>


<td class="">3<br>8<br>8</td>
<td class="">92</td>
<td class="">6<br>8<br>8</td>


<td class="">2<br>3<br>9</td>
<td class="">41</td>
<td class="">2<br>2<br>7</td>

</tr>      <tr>
        <td>12/12/2022<br/>to<br/>17/12/2022</td>
      
<td class="">2<br>6<br>9</td>
<td class="">76</td>
<td class="">8<br>9<br>9</td>


<td class="">1<br>1<br>5</td>
<td class="">76</td>
<td class="">4<br>6<br>6</td>


<td class="">6<br>7<br>8</td>
<td class="">18</td>
<td class="">5<br>6<br>7</td>


<td class="">2<br>5<br>6</td>
<td class="">35</td>
<td class="">2<br>5<br>8</td>


<td class="r">1<br>2<br>0</td>
<td class="r">38</td>
<td class="r">4<br>7<br>7</td>


<td class="">4<br>9<br>0</td>
<td class="">36</td>
<td class="">8<br>8<br>0</td>

</tr>      <tr>
        <td>19/12/2022<br/>to<br/>24/12/2022</td>
      
<td class="">1<br>5<br>0</td>
<td class="">68</td>
<td class="">1<br>7<br>0</td>


<td class="r">1<br>5<br>7</td>
<td class="r">33</td>
<td class="r">1<br>4<br>8</td>


<td class="">3<br>4<br>8</td>
<td class="">56</td>
<td class="">5<br>5<br>6</td>


<td class="">4<br>5<br>7</td>
<td class="">60</td>
<td class="">2<br>9<br>9</td>


<td class="">4<br>9<br>0</td>
<td class="">34</td>
<td class="">4<br>0<br>0</td>


<td class="">6<br>6<br>9</td>
<td class="">13</td>
<td class="">3<br>5<br>5</td>

</tr>      <tr>
        <td>26/12/2022<br/>to<br/>31/12/2022</td>
      
<td class="">2<br>3<br>4</td>
<td class="">90</td>
<td class="">4<br>8<br>8</td>


<td class="r">1<br>2<br>2</td>
<td class="r">55</td>
<td class="r">1<br>5<br>9</td>


<td class="r">7<br>0<br>0</td>
<td class="r">77</td>
<td class="r">4<br>4<br>9</td>


<td class="">4<br>5<br>7</td>
<td class="">62</td>
<td class="">6<br>7<br>9</td>


<td class="r">1<br>3<br>7</td>
<td class="r">16</td>
<td class="r">3<br>4<br>9</td>


<td class="">8<br>0<br>0</td>
<td class="">84</td>
<td class="">6<br>8<br>0</td>

</tr>      <tr>
        <td>02/01/2023<br/>to<br/>07/01/2023</td>
      
<td class="">3<br>8<br>0</td>
<td class="">15</td>
<td class="">1<br>6<br>8</td>


<td class="">9<br>0<br>0</td>
<td class="">91</td>
<td class="">5<br>6<br>0</td>


<td class="r">3<br>6<br>8</td>
<td class="r">72</td>
<td class="r">1<br>5<br>6</td>


<td class="">3<br>4<br>4</td>
<td class="">15</td>
<td class="">3<br>3<br>9</td>


<td class="">2<br>9<br>0</td>
<td class="">14</td>
<td class="">2<br>5<br>7</td>


<td class="">5<br>7<br>9</td>
<td class="">15</td>
<td class="">3<br>6<br>6</td>

</tr>      <tr>
        <td>09/01/2023<br/>to<br/>14/01/2023</td>
      
<td class="">6<br>7<br>8</td>
<td class="">18</td>
<td class="">2<br>8<br>8</td>


<td class="">6<br>7<br>7</td>
<td class="">02</td>
<td class="">6<br>7<br>9</td>


<td class="">3<br>4<br>6</td>
<td class="">31</td>
<td class="">2<br>4<br>5</td>


<td class="">2<br>3<br>5</td>
<td class="">08</td>
<td class="">3<br>6<br>9</td>


<td class="">3<br>6<br>9</td>
<td class="">89</td>
<td class="">5<br>6<br>8</td>


<td class="">2<br>6<br>6</td>
<td class="">45</td>
<td class="">8<br>8<br>9</td>

</tr>      <tr>
        <td>16/01/2023<br/>to<br/>21/01/2023</td>
      
<td class="r">1<br>1<br>7</td>
<td class="r">94</td>
<td class="r">1<br>6<br>7</td>


<td class="r">2<br>5<br>7</td>
<td class="r">44</td>
<td class="r">3<br>3<br>8</td>


<td class="">4<br>6<br>9</td>
<td class="">96</td>
<td class="">3<br>4<br>9</td>


<td class="">3<br>4<br>5</td>
<td class="">29</td>
<td class="">1<br>1<br>7</td>


<td class="r">3<br>4<br>7</td>
<td class="r">44</td>
<td class="r">7<br>8<br>9</td>


<td class="r">1<br>2<br>8</td>
<td class="r">11</td>
<td class="r">1<br>1<br>9</td>

</tr>      <tr>
        <td>23/01/2023<br/>to<br/>28/01/2023</td>
      
<td class="r">5<br>6<br>8</td>
<td class="r">94</td>
<td class="r">2<br>3<br>9</td>


<td class="">7<br>7<br>8</td>
<td class="">24</td>
<td class="">3<br>5<br>6</td>


<td class="r">3<br>9<br>9</td>
<td class="r">11</td>
<td class="r">1<br>4<br>6</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">3<br>7<br>9</td>
<td class="">96</td>
<td class="">1<br>2<br>3</td>


<td class="">6<br>9<br>9</td>
<td class="">43</td>
<td class="">4<br>4<br>5</td>

</tr>      <tr>
        <td>30/01/2023<br/>to<br/>04/02/2023</td>
      
<td class="r">1<br>3<br>8</td>
<td class="r">22</td>
<td class="r">1<br>5<br>6</td>


<td class="">3<br>4<br>4</td>
<td class="">18</td>
<td class="">1<br>3<br>4</td>


<td class="">5<br>9<br>9</td>
<td class="">32</td>
<td class="">2<br>2<br>8</td>


<td class="">4<br>8<br>0</td>
<td class="">29</td>
<td class="">3<br>8<br>8</td>


<td class="">1<br>1<br>3</td>
<td class="">56</td>
<td class="">2<br>7<br>7</td>


<td class="r">3<br>4<br>6</td>
<td class="r">38</td>
<td class="r">4<br>7<br>7</td>

</tr>      <tr>
        <td>06/02/2023<br/>to<br/>11/02/2023</td>
      
<td class="">3<br>4<br>8</td>
<td class="">53</td>
<td class="">2<br>5<br>6</td>


<td class="">3<br>4<br>6</td>
<td class="">36</td>
<td class="">2<br>4<br>0</td>


<td class="">3<br>6<br>8</td>
<td class="">76</td>
<td class="">2<br>4<br>0</td>


<td class="">2<br>3<br>7</td>
<td class="">29</td>
<td class="">1<br>8<br>0</td>


<td class="">1<br>4<br>7</td>
<td class="">20</td>
<td class="">3<br>8<br>9</td>


<td class="">4<br>4<br>7</td>
<td class="">53</td>
<td class="">1<br>5<br>7</td>

</tr>      <tr>
        <td>13/02/2023<br/>to<br/>18/02/2023</td>
      
<td class="">4<br>5<br>8</td>
<td class="">71</td>
<td class="">1<br>3<br>7</td>


<td class="">5<br>5<br>0</td>
<td class="">01</td>
<td class="">3<br>9<br>9</td>


<td class="">6<br>8<br>0</td>
<td class="">42</td>
<td class="">6<br>7<br>9</td>


<td class="">3<br>4<br>4</td>
<td class="">12</td>
<td class="">4<br>8<br>0</td>


<td class="r">2<br>2<br>6</td>
<td class="r">05</td>
<td class="r">2<br>5<br>8</td>


<td class="">4<br>0<br>0</td>
<td class="">43</td>
<td class="">6<br>7<br>0</td>

</tr>      <tr>
        <td>20/02/2023<br/>to<br/>25/02/2023</td>
      
<td class="">5<br>9<br>0</td>
<td class="">41</td>
<td class="">5<br>8<br>8</td>


<td class="r">2<br>5<br>7</td>
<td class="r">49</td>
<td class="r">2<br>3<br>4</td>


<td class="">3<br>5<br>7</td>
<td class="">51</td>
<td class="">2<br>4<br>5</td>


<td class="">5<br>5<br>6</td>
<td class="">69</td>
<td class="">2<br>7<br>0</td>


<td class="">3<br>8<br>0</td>
<td class="">10</td>
<td class="">4<br>8<br>8</td>


<td class="r">3<br>5<br>8</td>
<td class="r">61</td>
<td class="r">4<br>8<br>9</td>

</tr>      <tr>
        <td>27/02/2023<br/>to<br/>04/03/2023</td>
      
<td class="">1<br>5<br>7</td>
<td class="">30</td>
<td class="">2<br>8<br>0</td>


<td class="r">4<br>7<br>9</td>
<td class="r">05</td>
<td class="r">6<br>9<br>0</td>


<td class="">4<br>7<br>0</td>
<td class="">13</td>
<td class="">1<br>2<br>0</td>


<td class="">1<br>5<br>7</td>
<td class="">34</td>
<td class="">3<br>5<br>6</td>


<td class="">1<br>2<br>8</td>
<td class="">19</td>
<td class="">4<br>5<br>0</td>


<td class="">3<br>4<br>9</td>
<td class="">64</td>
<td class="">2<br>3<br>9</td>

</tr>      <tr>
        <td>06/03/2023<br/>to<br/>11/03/2023</td>
      
<td class="">2<br>4<br>9</td>
<td class="">58</td>
<td class="">5<br>6<br>7</td>


<td class="">6<br>6<br>8</td>
<td class="">09</td>
<td class="">3<br>6<br>0</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">1<br>4<br>9</td>
<td class="">43</td>
<td class="">7<br>8<br>8</td>


<td class="">5<br>5<br>9</td>
<td class="">97</td>
<td class="">4<br>5<br>8</td>


<td class="">1<br>2<br>7</td>
<td class="">06</td>
<td class="">3<br>3<br>0</td>

</tr>      <tr>
        <td>13/03/2023<br/>to<br/>18/03/2023</td>
      
<td class="r">2<br>3<br>7</td>
<td class="r">27</td>
<td class="r">4<br>6<br>7</td>


<td class="">1<br>9<br>9</td>
<td class="">95</td>
<td class="">4<br>4<br>7</td>


<td class="">3<br>3<br>0</td>
<td class="">60</td>
<td class="">2<br>8<br>0</td>


<td class="">2<br>6<br>8</td>
<td class="">64</td>
<td class="">1<br>6<br>7</td>


<td class="">4<br>0<br>0</td>
<td class="">43</td>
<td class="">6<br>8<br>9</td>


<td class="">2<br>4<br>0</td>
<td class="">63</td>
<td class="">4<br>4<br>5</td>

</tr>      <tr>
        <td>20/03/2023<br/>to<br/>25/03/2023</td>
      
<td class="">3<br>5<br>8</td>
<td class="">64</td>
<td class="">7<br>7<br>0</td>


<td class="">4<br>7<br>8</td>
<td class="">95</td>
<td class="">2<br>3<br>0</td>


<td class="">4<br>9<br>9</td>
<td class="">28</td>
<td class="">4<br>6<br>8</td>


<td class="">3<br>8<br>9</td>
<td class="">07</td>
<td class="">3<br>4<br>0</td>


<td class="">5<br>8<br>8</td>
<td class="">12</td>
<td class="">2<br>0<br>0</td>


<td class="r">6<br>6<br>7</td>
<td class="r">94</td>
<td class="r">6<br>9<br>9</td>

</tr>      <tr>
        <td>27/03/2023<br/>to<br/>01/04/2023</td>
      
<td class="r">2<br>3<br>0</td>
<td class="r">55</td>
<td class="r">2<br>4<br>9</td>


<td class="">5<br>7<br>0</td>
<td class="">28</td>
<td class="">4<br>5<br>9</td>


<td class="r">3<br>7<br>0</td>
<td class="r">00</td>
<td class="r">1<br>3<br>6</td>


<td class="">6<br>7<br>9</td>
<td class="">20</td>
<td class="">2<br>4<br>4</td>


<td class="r">2<br>3<br>3</td>
<td class="r">88</td>
<td class="r">1<br>2<br>5</td>


<td class="">5<br>8<br>9</td>
<td class="">29</td>
<td class="">2<br>8<br>9</td>

</tr>      <tr>
        <td>03/04/2023<br/>to<br/>08/04/2023</td>
      
<td class="">4<br>5<br>9</td>
<td class="">82</td>
<td class="">1<br>2<br>9</td>


<td class="">3<br>7<br>8</td>
<td class="">89</td>
<td class="">5<br>6<br>8</td>


<td class="">7<br>7<br>8</td>
<td class="">28</td>
<td class="">1<br>7<br>0</td>


<td class="">3<br>3<br>7</td>
<td class="">35</td>
<td class="">1<br>6<br>8</td>


<td class="">1<br>2<br>7</td>
<td class="">07</td>
<td class="">4<br>5<br>8</td>


<td class="">3<br>4<br>6</td>
<td class="">37</td>
<td class="">1<br>8<br>8</td>

</tr>      <tr>
        <td>10/04/2023<br/>to<br/>15/04/2023</td>
      
<td class="r">4<br>5<br>6</td>
<td class="r">55</td>
<td class="r">1<br>1<br>3</td>


<td class="r">5<br>7<br>7</td>
<td class="r">99</td>
<td class="r">6<br>6<br>7</td>


<td class="">8<br>9<br>0</td>
<td class="">78</td>
<td class="">8<br>0<br>0</td>


<td class="">1<br>6<br>0</td>
<td class="">70</td>
<td class="">2<br>4<br>4</td>


<td class="r">4<br>6<br>0</td>
<td class="r">05</td>
<td class="r">1<br>4<br>0</td>


<td class="">2<br>9<br>9</td>
<td class="">08</td>
<td class="">4<br>4<br>0</td>

</tr>      <tr>
        <td>17/04/2023<br/>to<br/>22/04/2023</td>
      
<td class="r">6<br>6<br>0</td>
<td class="r">27</td>
<td class="r">4<br>6<br>7</td>


<td class="r">1<br>3<br>6</td>
<td class="r">05</td>
<td class="r">1<br>7<br>7</td>


<td class="r">3<br>4<br>0</td>
<td class="r">72</td>
<td class="r">2<br>3<br>7</td>


<td class="">6<br>9<br>0</td>
<td class="">58</td>
<td class="">3<br>7<br>8</td>


<td class="">1<br>8<br>8</td>
<td class="">75</td>
<td class="">7<br>8<br>0</td>


<td class="r">2<br>3<br>9</td>
<td class="r">49</td>
<td class="r">1<br>2<br>6</td>

</tr>      <tr>
        <td>24/04/2023<br/>to<br/>29/04/2023</td>
      
<td class="">3<br>4<br>5</td>
<td class="">29</td>
<td class="">4<br>5<br>0</td>


<td class="">2<br>2<br>6</td>
<td class="">07</td>
<td class="">1<br>2<br>4</td>


<td class="">4<br>6<br>7</td>
<td class="">79</td>
<td class="">4<br>6<br>9</td>


<td class="">3<br>7<br>7</td>
<td class="">76</td>
<td class="">3<br>5<br>8</td>


<td class="">3<br>6<br>8</td>
<td class="">76</td>
<td class="">2<br>5<br>9</td>


<td class="">1<br>1<br>4</td>
<td class="">64</td>
<td class="">5<br>9<br>0</td>

</tr>      <tr>
        <td>01/05/2023<br/>to<br/>06/05/2023</td>
      
<td class="r">7<br>9<br>0</td>
<td class="r">66</td>
<td class="r">2<br>6<br>8</td>


<td class="">2<br>3<br>8</td>
<td class="">39</td>
<td class="">2<br>3<br>4</td>


<td class="">3<br>5<br>7</td>
<td class="">53</td>
<td class="">7<br>8<br>8</td>


<td class="">1<br>7<br>0</td>
<td class="">89</td>
<td class="">1<br>3<br>5</td>


<td class="">2<br>5<br>6</td>
<td class="">32</td>
<td class="">3<br>4<br>5</td>


<td class="r">1<br>5<br>8</td>
<td class="r">49</td>
<td class="r">1<br>9<br>9</td>

</tr>      <tr>
        <td>08/05/2023<br/>to<br/>13/05/2023</td>
      
<td class="">8<br>9<br>0</td>
<td class="">75</td>
<td class="">4<br>5<br>6</td>


<td class="r">3<br>6<br>9</td>
<td class="r">83</td>
<td class="r">2<br>4<br>7</td>


<td class="">5<br>6<br>7</td>
<td class="">89</td>
<td class="">2<br>7<br>0</td>


<td class="r">3<br>3<br>0</td>
<td class="r">61</td>
<td class="r">3<br>4<br>4</td>


<td class="r">1<br>5<br>0</td>
<td class="r">61</td>
<td class="r">3<br>4<br>4</td>


<td class="">2<br>6<br>6</td>
<td class="">46</td>
<td class="">2<br>6<br>8</td>

</tr>      <tr>
        <td>15/05/2023<br/>to<br/>20/05/2023</td>
      
<td class="">4<br>7<br>8</td>
<td class="">92</td>
<td class="">2<br>0<br>0</td>


<td class="">5<br>9<br>9</td>
<td class="">30</td>
<td class="">6<br>7<br>7</td>


<td class="">6<br>8<br>0</td>
<td class="">46</td>
<td class="">2<br>4<br>0</td>


<td class="">3<br>4<br>6</td>
<td class="">32</td>
<td class="">3<br>9<br>0</td>


<td class="">1<br>1<br>6</td>
<td class="">82</td>
<td class="">3<br>9<br>0</td>


<td class="">4<br>7<br>9</td>
<td class="">06</td>
<td class="">5<br>5<br>6</td>

</tr>      <tr>
        <td>22/05/2023<br/>to<br/>27/05/2023</td>
      
<td class="">2<br>2<br>8</td>
<td class="">21</td>
<td class="">3<br>3<br>5</td>


<td class="">4<br>4<br>8</td>
<td class="">62</td>
<td class="">2<br>4<br>6</td>


<td class="">1<br>7<br>8</td>
<td class="">62</td>
<td class="">1<br>2<br>9</td>


<td class="">4<br>5<br>9</td>
<td class="">81</td>
<td class="">2<br>3<br>6</td>


<td class="r">1<br>5<br>5</td>
<td class="r">11</td>
<td class="r">1<br>0<br>0</td>


<td class="">3<br>6<br>8</td>
<td class="">79</td>
<td class="">4<br>7<br>8</td>

</tr>      <tr>
        <td>29/05/2023<br/>to<br/>03/06/2023</td>
      
<td class="">1<br>3<br>0</td>
<td class="">45</td>
<td class="">1<br>6<br>8</td>


<td class="r">4<br>6<br>0</td>
<td class="r">09</td>
<td class="r">5<br>5<br>9</td>


<td class="">3<br>4<br>8</td>
<td class="">53</td>
<td class="">6<br>7<br>0</td>


<td class="r">5<br>7<br>8</td>
<td class="r">00</td>
<td class="r">3<br>8<br>9</td>


<td class="r">1<br>1<br>5</td>
<td class="r">72</td>
<td class="r">6<br>8<br>8</td>


<td class="">1<br>3<br>7</td>
<td class="">19</td>
<td class="">1<br>4<br>4</td>

</tr>      <tr>
        <td>05/06/2023<br/>to<br/>10/06/2023</td>
      
<td class="">1<br>2<br>7</td>
<td class="">07</td>
<td class="">3<br>5<br>9</td>


<td class="r">1<br>3<br>7</td>
<td class="r">16</td>
<td class="r">8<br>9<br>9</td>


<td class="r">6<br>8<br>8</td>
<td class="r">22</td>
<td class="r">2<br>2<br>8</td>


<td class="">2<br>7<br>8</td>
<td class="">70</td>
<td class="">1<br>1<br>8</td>


<td class="">5<br>0<br>0</td>
<td class="">54</td>
<td class="">2<br>4<br>8</td>


<td class="">2<br>2<br>0</td>
<td class="">41</td>
<td class="">1<br>3<br>7</td>

</tr>      <tr>
        <td>12/06/2023<br/>to<br/>17/06/2023</td>
      
<td class="">6<br>6<br>9</td>
<td class="">18</td>
<td class="">1<br>8<br>9</td>


<td class="">2<br>2<br>3</td>
<td class="">75</td>
<td class="">8<br>8<br>9</td>


<td class="">5<br>7<br>8</td>
<td class="">09</td>
<td class="">1<br>1<br>7</td>


<td class="">5<br>8<br>9</td>
<td class="">23</td>
<td class="">4<br>9<br>0</td>


<td class="r">3<br>3<br>8</td>
<td class="r">44</td>
<td class="r">1<br>6<br>7</td>


<td class="">2<br>5<br>8</td>
<td class="">51</td>
<td class="">1<br>3<br>7</td>

</tr>      <tr>
        <td>19/06/2023<br/>to<br/>24/06/2023</td>
      
<td class="">4<br>5<br>9</td>
<td class="">81</td>
<td class="">1<br>5<br>5</td>


<td class="r">3<br>5<br>7</td>
<td class="r">55</td>
<td class="r">8<br>8<br>9</td>


<td class="">9<br>9<br>0</td>
<td class="">89</td>
<td class="">2<br>7<br>0</td>


<td class="">1<br>3<br>4</td>
<td class="">81</td>
<td class="">2<br>4<br>5</td>


<td class="">6<br>7<br>0</td>
<td class="">31</td>
<td class="">3<br>8<br>0</td>


<td class="">4<br>5<br>9</td>
<td class="">87</td>
<td class="">2<br>5<br>0</td>

</tr>      <tr>
        <td>26/06/2023<br/>to<br/>01/07/2023</td>
      
<td class="r">1<br>7<br>0</td>
<td class="r">83</td>
<td class="r">1<br>6<br>6</td>


<td class="">1<br>2<br>8</td>
<td class="">14</td>
<td class="">1<br>5<br>8</td>


<td class="">1<br>7<br>9</td>
<td class="">75</td>
<td class="">3<br>5<br>7</td>


<td class="">3<br>7<br>8</td>
<td class="">85</td>
<td class="">3<br>4<br>8</td>


<td class="">3<br>9<br>0</td>
<td class="">24</td>
<td class="">1<br>1<br>2</td>


<td class="r">1<br>4<br>9</td>
<td class="r">44</td>
<td class="r">3<br>5<br>6</td>

</tr>      <tr>
        <td>03/07/2023<br/>to<br/>08/07/2023</td>
      
<td class="">2<br>5<br>7</td>
<td class="">45</td>
<td class="">8<br>8<br>9</td>


<td class="">2<br>7<br>9</td>
<td class="">89</td>
<td class="">4<br>7<br>8</td>


<td class="">9<br>0<br>0</td>
<td class="">96</td>
<td class="">3<br>5<br>8</td>


<td class="">2<br>8<br>8</td>
<td class="">81</td>
<td class="">2<br>2<br>7</td>


<td class="">4<br>4<br>8</td>
<td class="">62</td>
<td class="">7<br>7<br>8</td>


<td class="r">9<br>0<br>0</td>
<td class="r">99</td>
<td class="r">9<br>0<br>0</td>

</tr>      <tr>
        <td>10/07/2023<br/>to<br/>15/07/2023</td>
      
<td class="">3<br>9<br>0</td>
<td class="">26</td>
<td class="">3<br>6<br>7</td>


<td class="r">4<br>6<br>0</td>
<td class="r">05</td>
<td class="r">2<br>4<br>9</td>


<td class="r">2<br>8<br>9</td>
<td class="r">99</td>
<td class="r">5<br>7<br>7</td>


<td class="">1<br>6<br>6</td>
<td class="">30</td>
<td class="">1<br>3<br>6</td>


<td class="">1<br>7<br>0</td>
<td class="">81</td>
<td class="">3<br>4<br>4</td>


<td class="">4<br>7<br>8</td>
<td class="">98</td>
<td class="">1<br>1<br>6</td>

</tr>      <tr>
        <td>17/07/2023<br/>to<br/>22/07/2023</td>
      
<td class="">6<br>6<br>8</td>
<td class="">02</td>
<td class="">3<br>4<br>5</td>


<td class="">4<br>7<br>9</td>
<td class="">02</td>
<td class="">3<br>3<br>6</td>


<td class="">1<br>5<br>0</td>
<td class="">67</td>
<td class="">1<br>2<br>4</td>


<td class="">3<br>7<br>9</td>
<td class="">92</td>
<td class="">1<br>4<br>7</td>


<td class="">4<br>5<br>7</td>
<td class="">60</td>
<td class="">1<br>1<br>8</td>


<td class="r">1<br>8<br>0</td>
<td class="r">94</td>
<td class="r">1<br>5<br>8</td>

</tr>      <tr>
        <td>24/07/2023<br/>to<br/>29/07/2023</td>
      
<td class="r">1<br>6<br>7</td>
<td class="r">49</td>
<td class="r">5<br>5<br>9</td>


<td class="">1<br>9<br>9</td>
<td class="">90</td>
<td class="">1<br>3<br>6</td>


<td class="r">3<br>4<br>7</td>
<td class="r">44</td>
<td class="r">1<br>4<br>9</td>


<td class="">2<br>3<br>0</td>
<td class="">56</td>
<td class="">8<br>8<br>0</td>


<td class="">1<br>1<br>6</td>
<td class="">84</td>
<td class="">6<br>9<br>9</td>


<td class="r">5<br>8<br>9</td>
<td class="r">27</td>
<td class="r">3<br>4<br>0</td>

</tr>      <tr>
        <td>31/07/2023<br/>to<br/>05/08/2023</td>
      
<td class="">3<br>6<br>8</td>
<td class="">76</td>
<td class="">3<br>3<br>0</td>


<td class="r">5<br>6<br>7</td>
<td class="r">83</td>
<td class="r">2<br>4<br>7</td>


<td class="">2<br>8<br>9</td>
<td class="">95</td>
<td class="">3<br>4<br>8</td>


<td class="r">2<br>4<br>8</td>
<td class="r">49</td>
<td class="r">4<br>7<br>8</td>


<td class="">4<br>6<br>9</td>
<td class="">91</td>
<td class="">2<br>9<br>0</td>


<td class="">6<br>9<br>9</td>
<td class="">40</td>
<td class="">4<br>7<br>9</td>

</tr>      <tr>
        <td>07/08/2023<br/>to<br/>12/08/2023</td>
      
<td class="">4<br>8<br>9</td>
<td class="">19</td>
<td class="">1<br>3<br>5</td>


<td class="">3<br>5<br>9</td>
<td class="">71</td>
<td class="">1<br>4<br>6</td>


<td class="">9<br>9<br>0</td>
<td class="">86</td>
<td class="">7<br>9<br>0</td>


<td class="">3<br>9<br>0</td>
<td class="">23</td>
<td class="">7<br>8<br>8</td>


<td class="">4<br>0<br>0</td>
<td class="">42</td>
<td class="">6<br>7<br>9</td>


<td class="">3<br>9<br>0</td>
<td class="">28</td>
<td class="">9<br>9<br>0</td>

</tr>      <tr>
        <td>14/08/2023<br/>to<br/>19/08/2023</td>
      
<td class="r">3<br>3<br>8</td>
<td class="r">44</td>
<td class="r">2<br>3<br>9</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">3<br>4<br>9</td>
<td class="">68</td>
<td class="">2<br>7<br>9</td>


<td class="r">1<br>7<br>8</td>
<td class="r">61</td>
<td class="r">2<br>3<br>6</td>


<td class="">1<br>5<br>8</td>
<td class="">46</td>
<td class="">3<br>6<br>7</td>


<td class="">5<br>5<br>8</td>
<td class="">82</td>
<td class="">1<br>5<br>6</td>

</tr>      <tr>
        <td>21/08/2023<br/>to<br/>26/08/2023</td>
      
<td class="">1<br>1<br>5</td>
<td class="">79</td>
<td class="">3<br>8<br>8</td>


<td class="r">2<br>4<br>5</td>
<td class="r">16</td>
<td class="r">4<br>4<br>8</td>


<td class="">6<br>6<br>7</td>
<td class="">98</td>
<td class="">4<br>6<br>8</td>


<td class="r">6<br>7<br>9</td>
<td class="r">22</td>
<td class="r">3<br>4<br>5</td>


<td class="r">1<br>2<br>8</td>
<td class="r">11</td>
<td class="r">4<br>7<br>0</td>


<td class="">2<br>3<br>4</td>
<td class="">95</td>
<td class="">1<br>6<br>8</td>

</tr>      <tr>
        <td>28/08/2023<br/>to<br/>02/09/2023</td>
      
<td class="">2<br>3<br>3</td>
<td class="">82</td>
<td class="">1<br>4<br>7</td>


<td class="">2<br>6<br>8</td>
<td class="">62</td>
<td class="">3<br>4<br>5</td>


<td class="">1<br>1<br>9</td>
<td class="">18</td>
<td class="">5<br>5<br>8</td>


<td class="r">2<br>8<br>9</td>
<td class="r">99</td>
<td class="r">4<br>7<br>8</td>


<td class="">3<br>5<br>6</td>
<td class="">46</td>
<td class="">3<br>4<br>9</td>


<td class="">6<br>7<br>9</td>
<td class="">29</td>
<td class="">2<br>3<br>4</td>

</tr>      <tr>
        <td>04/09/2023<br/>to<br/>09/09/2023</td>
      
<td class="">5<br>5<br>7</td>
<td class="">76</td>
<td class="">1<br>5<br>0</td>


<td class="r">1<br>2<br>4</td>
<td class="r">77</td>
<td class="r">1<br>6<br>0</td>


<td class="">3<br>8<br>0</td>
<td class="">12</td>
<td class="">3<br>9<br>0</td>


<td class="">2<br>5<br>7</td>
<td class="">42</td>
<td class="">5<br>8<br>9</td>


<td class="">2<br>5<br>5</td>
<td class="">25</td>
<td class="">6<br>9<br>0</td>


<td class="r">7<br>7<br>9</td>
<td class="r">38</td>
<td class="r">3<br>7<br>8</td>

</tr>      <tr>
        <td>11/09/2023<br/>to<br/>16/09/2023</td>
      
<td class="">3<br>5<br>9</td>
<td class="">70</td>
<td class="">1<br>4<br>5</td>


<td class="">3<br>5<br>8</td>
<td class="">62</td>
<td class="">2<br>3<br>7</td>


<td class="">5<br>8<br>9</td>
<td class="">20</td>
<td class="">4<br>6<br>0</td>


<td class="">3<br>4<br>9</td>
<td class="">67</td>
<td class="">1<br>3<br>3</td>


<td class="">1<br>1<br>7</td>
<td class="">90</td>
<td class="">4<br>6<br>0</td>


<td class="">3<br>8<br>8</td>
<td class="">96</td>
<td class="">2<br>4<br>0</td>

</tr>      <tr>
        <td>18/09/2023<br/>to<br/>23/09/2023</td>
      
<td class="">1<br>6<br>8</td>
<td class="">59</td>
<td class="">3<br>8<br>8</td>


<td class="r">3<br>4<br>8</td>
<td class="r">55</td>
<td class="r">2<br>4<br>9</td>


<td class="r">2<br>4<br>9</td>
<td class="r">55</td>
<td class="r">6<br>9<br>0</td>


<td class="">3<br>6<br>7</td>
<td class="">60</td>
<td class="">5<br>7<br>8</td>


<td class="">4<br>5<br>6</td>
<td class="">57</td>
<td class="">2<br>7<br>8</td>


<td class="">2<br>6<br>7</td>
<td class="">59</td>
<td class="">2<br>8<br>9</td>

</tr>      <tr>
        <td>25/09/2023<br/>to<br/>30/09/2023</td>
      
<td class="">3<br>4<br>6</td>
<td class="">37</td>
<td class="">1<br>7<br>9</td>


<td class="">6<br>8<br>0</td>
<td class="">42</td>
<td class="">2<br>0<br>0</td>


<td class="">4<br>5<br>0</td>
<td class="">98</td>
<td class="">5<br>5<br>8</td>


<td class="r">1<br>1<br>9</td>
<td class="r">11</td>
<td class="r">4<br>8<br>9</td>


<td class="">3<br>7<br>0</td>
<td class="">02</td>
<td class="">1<br>5<br>6</td>


<td class="">3<br>5<br>7</td>
<td class="">56</td>
<td class="">4<br>6<br>6</td>

</tr>      <tr>
        <td>02/10/2023<br/>to<br/>07/10/2023</td>
      
<td class="r">8<br>8<br>9</td>
<td class="r">55</td>
<td class="r">4<br>4<br>7</td>


<td class="">1<br>7<br>0</td>
<td class="">87</td>
<td class="">2<br>6<br>9</td>


<td class="">1<br>7<br>0</td>
<td class="">84</td>
<td class="">1<br>4<br>9</td>


<td class="">5<br>7<br>9</td>
<td class="">10</td>
<td class="">3<br>7<br>0</td>


<td class="">1<br>8<br>9</td>
<td class="">82</td>
<td class="">3<br>9<br>0</td>


<td class="">6<br>8<br>0</td>
<td class="">42</td>
<td class="">2<br>3<br>7</td>

</tr>      <tr>
        <td>09/10/2023<br/>to<br/>14/10/2023</td>
      
<td class="">9<br>9<br>0</td>
<td class="">87</td>
<td class="">3<br>5<br>9</td>


<td class="r">1<br>3<br>0</td>
<td class="r">44</td>
<td class="r">1<br>4<br>9</td>


<td class="">3<br>0<br>0</td>
<td class="">35</td>
<td class="">1<br>4<br>0</td>


<td class="">1<br>1<br>4</td>
<td class="">60</td>
<td class="">2<br>8<br>0</td>


<td class="">1<br>2<br>9</td>
<td class="">20</td>
<td class="">1<br>9<br>0</td>


<td class="">3<br>9<br>0</td>
<td class="">20</td>
<td class="">4<br>6<br>0</td>

</tr>      <tr>
        <td>16/10/2023<br/>to<br/>21/10/2023</td>
      
<td class="r">3<br>7<br>0</td>
<td class="r">05</td>
<td class="r">7<br>8<br>0</td>


<td class="">7<br>8<br>9</td>
<td class="">42</td>
<td class="">6<br>8<br>8</td>


<td class="">1<br>2<br>6</td>
<td class="">97</td>
<td class="">4<br>6<br>7</td>


<td class="">2<br>5<br>7</td>
<td class="">43</td>
<td class="">1<br>5<br>7</td>


<td class="">4<br>7<br>8</td>
<td class="">97</td>
<td class="">3<br>6<br>8</td>


<td class="">2<br>4<br>0</td>
<td class="">60</td>
<td class="">6<br>7<br>7</td>

</tr>      <tr>
        <td>23/10/2023<br/>to<br/>28/10/2023</td>
      
<td class="">2<br>2<br>0</td>
<td class="">45</td>
<td class="">4<br>5<br>6</td>


<td class="">4<br>4<br>5</td>
<td class="">30</td>
<td class="">2<br>8<br>0</td>


<td class="">2<br>2<br>6</td>
<td class="">09</td>
<td class="">4<br>6<br>9</td>


<td class="">1<br>4<br>9</td>
<td class="">41</td>
<td class="">1<br>1<br>9</td>


<td class="">5<br>8<br>8</td>
<td class="">13</td>
<td class="">7<br>8<br>8</td>


<td class="">1<br>6<br>7</td>
<td class="">42</td>
<td class="">5<br>7<br>0</td>

</tr>      <tr>
        <td>30/10/2023<br/>to<br/>04/11/2023</td>
      
<td class="r">1<br>2<br>7</td>
<td class="r">00</td>
<td class="r">4<br>7<br>9</td>


<td class="r">2<br>7<br>7</td>
<td class="r">61</td>
<td class="r">3<br>8<br>0</td>


<td class="">1<br>1<br>8</td>
<td class="">07</td>
<td class="">5<br>5<br>7</td>


<td class="r">2<br>6<br>0</td>
<td class="r">83</td>
<td class="r">1<br>5<br>7</td>


<td class="">3<br>7<br>8</td>
<td class="">86</td>
<td class="">3<br>4<br>9</td>


<td class="">2<br>7<br>7</td>
<td class="">63</td>
<td class="">1<br>3<br>9</td>

</tr>      <tr>
        <td>06/11/2023<br/>to<br/>11/11/2023</td>
      
<td class="">2<br>3<br>5</td>
<td class="">07</td>
<td class="">2<br>2<br>3</td>


<td class="">3<br>4<br>0</td>
<td class="">75</td>
<td class="">1<br>6<br>8</td>


<td class="">4<br>0<br>0</td>
<td class="">41</td>
<td class="">4<br>7<br>0</td>


<td class="">8<br>9<br>0</td>
<td class="">79</td>
<td class="">4<br>7<br>8</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>

</tr>      <tr>
        <td>13/11/2023<br/>to<br/>18/11/2023</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>

</tr>      <tr>
        <td>20/11/2023<br/>to<br/>25/11/2023</td>
      
<td class="r">1<br>2<br>6</td>
<td class="r">99</td>
<td class="r">2<br>8<br>9</td>


<td class="r">4<br>5<br>6</td>
<td class="r">55</td>
<td class="r">3<br>4<br>8</td>


<td class="r">2<br>4<br>6</td>
<td class="r">27</td>
<td class="r">3<br>7<br>7</td>


<td class="">3<br>3<br>4</td>
<td class="">03</td>
<td class="">2<br>3<br>8</td>


<td class="">2<br>3<br>3</td>
<td class="">89</td>
<td class="">1<br>3<br>5</td>


<td class="">1<br>4<br>7</td>
<td class="">29</td>
<td class="">4<br>7<br>8</td>

</tr>      <tr>
        <td>27/11/2023<br/>to<br/>02/12/2023</td>
      
<td class="">1<br>1<br>6</td>
<td class="">89</td>
<td class="">4<br>6<br>9</td>


<td class="">1<br>6<br>8</td>
<td class="">59</td>
<td class="">2<br>3<br>4</td>


<td class="">1<br>4<br>4</td>
<td class="">98</td>
<td class="">8<br>0<br>0</td>


<td class="r">2<br>9<br>0</td>
<td class="r">11</td>
<td class="r">4<br>7<br>0</td>


<td class="">2<br>7<br>9</td>
<td class="">80</td>
<td class="">1<br>2<br>7</td>


<td class="">1<br>5<br>5</td>
<td class="">15</td>
<td class="">4<br>4<br>7</td>

</tr>      <tr>
        <td>04/12/2023<br/>to<br/>09/12/2023</td>
      
<td class="">7<br>8<br>9</td>
<td class="">43</td>
<td class="">7<br>7<br>9</td>


<td class="">2<br>5<br>9</td>
<td class="">64</td>
<td class="">6<br>8<br>0</td>


<td class="">1<br>2<br>7</td>
<td class="">02</td>
<td class="">7<br>7<br>8</td>


<td class="">2<br>3<br>5</td>
<td class="">09</td>
<td class="">4<br>6<br>9</td>


<td class="">1<br>5<br>7</td>
<td class="">30</td>
<td class="">1<br>3<br>6</td>


<td class="r">5<br>8<br>9</td>
<td class="r">22</td>
<td class="r">1<br>4<br>7</td>

</tr>      <tr>
        <td>11/12/2023<br/>to<br/>16/12/2023</td>
      
<td class="">1<br>8<br>9</td>
<td class="">86</td>
<td class="">2<br>5<br>9</td>


<td class="">6<br>6<br>9</td>
<td class="">15</td>
<td class="">2<br>6<br>7</td>


<td class="">2<br>9<br>0</td>
<td class="">13</td>
<td class="">2<br>5<br>6</td>


<td class="">8<br>8<br>0</td>
<td class="">69</td>
<td class="">1<br>2<br>6</td>


<td class="">8<br>9<br>9</td>
<td class="">69</td>
<td class="">1<br>3<br>5</td>


<td class="">2<br>4<br>5</td>
<td class="">18</td>
<td class="">3<br>7<br>8</td>

</tr>      <tr>
        <td>18/12/2023<br/>to<br/>23/12/2023</td>
      
<td class="">3<br>5<br>6</td>
<td class="">43</td>
<td class="">6<br>7<br>0</td>


<td class="">1<br>4<br>8</td>
<td class="">37</td>
<td class="">1<br>2<br>4</td>


<td class="">2<br>4<br>9</td>
<td class="">58</td>
<td class="">4<br>6<br>8</td>


<td class="">4<br>5<br>0</td>
<td class="">98</td>
<td class="">5<br>6<br>7</td>


<td class="">2<br>5<br>7</td>
<td class="">41</td>
<td class="">5<br>6<br>0</td>


<td class="">3<br>7<br>8</td>
<td class="">87</td>
<td class="">1<br>1<br>5</td>

</tr>      <tr>
        <td>25/12/2023<br/>to<br/>30/12/2023</td>
      
<td class="">2<br>7<br>0</td>
<td class="">98</td>
<td class="">3<br>5<br>0</td>


<td class="">1<br>1<br>7</td>
<td class="">91</td>
<td class="">5<br>8<br>8</td>


<td class="">6<br>6<br>0</td>
<td class="">29</td>
<td class="">5<br>5<br>9</td>


<td class="">1<br>4<br>6</td>
<td class="">12</td>
<td class="">6<br>7<br>9</td>


<td class="">1<br>4<br>6</td>
<td class="">17</td>
<td class="">1<br>8<br>8</td>


<td class="">3<br>4<br>0</td>
<td class="">71</td>
<td class="">5<br>6<br>0</td>

</tr>      <tr>
        <td>01/01/2024<br/>to<br/>06/01/2024</td>
      
<td class="">2<br>3<br>0</td>
<td class="">53</td>
<td class="">2<br>5<br>6</td>


<td class="">5<br>7<br>9</td>
<td class="">12</td>
<td class="">7<br>7<br>8</td>


<td class="">4<br>7<br>7</td>
<td class="">86</td>
<td class="">3<br>6<br>7</td>


<td class="">3<br>3<br>5</td>
<td class="">19</td>
<td class="">2<br>7<br>0</td>


<td class="r">1<br>2<br>5</td>
<td class="r">83</td>
<td class="r">1<br>4<br>8</td>


<td class="">1<br>5<br>9</td>
<td class="">59</td>
<td class="">5<br>7<br>7</td>

</tr>      <tr>
        <td>08/01/2024<br/>to<br/>13/01/2024</td>
      
<td class="">1<br>3<br>8</td>
<td class="">29</td>
<td class="">4<br>7<br>8</td>


<td class="r">2<br>3<br>0</td>
<td class="r">50</td>
<td class="r">4<br>8<br>8</td>


<td class="r">5<br>7<br>0</td>
<td class="r">22</td>
<td class="r">2<br>4<br>6</td>


<td class="r">3<br>6<br>8</td>
<td class="r">77</td>
<td class="r">2<br>7<br>8</td>


<td class="">4<br>8<br>9</td>
<td class="">17</td>
<td class="">3<br>4<br>0</td>


<td class="">2<br>6<br>8</td>
<td class="">65</td>
<td class="">3<br>3<br>9</td>

</tr>      <tr>
        <td>15/01/2024<br/>to<br/>20/01/2024</td>
      
<td class="">1<br>4<br>8</td>
<td class="">32</td>
<td class="">7<br>7<br>8</td>


<td class="">8<br>8<br>9</td>
<td class="">57</td>
<td class="">1<br>2<br>4</td>


<td class="">2<br>4<br>7</td>
<td class="">36</td>
<td class="">1<br>1<br>4</td>


<td class="">5<br>0<br>0</td>
<td class="">51</td>
<td class="">1<br>5<br>5</td>


<td class="r">4<br>5<br>0</td>
<td class="r">94</td>
<td class="r">2<br>3<br>9</td>


<td class="">5<br>9<br>0</td>
<td class="">40</td>
<td class="">5<br>7<br>8</td>

</tr>      <tr>
        <td>22/01/2024<br/>to<br/>27/01/2024</td>
      
<td class="">4<br>5<br>6</td>
<td class="">51</td>
<td class="">6<br>6<br>9</td>


<td class="r">2<br>2<br>0</td>
<td class="r">44</td>
<td class="r">7<br>8<br>9</td>


<td class="">3<br>3<br>5</td>
<td class="">12</td>
<td class="">1<br>5<br>6</td>


<td class="r">4<br>5<br>8</td>
<td class="r">72</td>
<td class="r">6<br>8<br>8</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">5<br>7<br>9</td>
<td class="">17</td>
<td class="">4<br>5<br>8</td>

</tr>      <tr>
        <td>29/01/2024<br/>to<br/>03/02/2024</td>
      
<td class="r">4<br>8<br>9</td>
<td class="r">16</td>
<td class="r">3<br>6<br>7</td>


<td class="">4<br>7<br>9</td>
<td class="">07</td>
<td class="">2<br>6<br>9</td>


<td class="">2<br>7<br>8</td>
<td class="">79</td>
<td class="">4<br>7<br>8</td>


<td class="r">4<br>6<br>0</td>
<td class="r">05</td>
<td class="r">2<br>5<br>8</td>


<td class="">3<br>7<br>9</td>
<td class="">95</td>
<td class="">2<br>5<br>8</td>


<td class="">1<br>2<br>7</td>
<td class="">02</td>
<td class="">1<br>5<br>6</td>

</tr>      <tr>
        <td>05/02/2024<br/>to<br/>10/02/2024</td>
      
<td class="">1<br>2<br>7</td>
<td class="">09</td>
<td class="">4<br>6<br>9</td>


<td class="r">4<br>8<br>8</td>
<td class="r">03</td>
<td class="r">4<br>9<br>0</td>


<td class="">2<br>4<br>0</td>
<td class="">63</td>
<td class="">4<br>4<br>5</td>


<td class="">2<br>3<br>5</td>
<td class="">03</td>
<td class="">2<br>5<br>6</td>


<td class="">1<br>5<br>6</td>
<td class="">21</td>
<td class="">6<br>6<br>9</td>


<td class="">2<br>8<br>0</td>
<td class="">01</td>
<td class="">6<br>7<br>8</td>

</tr>      <tr>
        <td>12/02/2024<br/>to<br/>17/02/2024</td>
      
<td class="">6<br>7<br>9</td>
<td class="">23</td>
<td class="">6<br>7<br>0</td>


<td class="">2<br>4<br>6</td>
<td class="">26</td>
<td class="">3<br>5<br>8</td>


<td class="">5<br>6<br>0</td>
<td class="">17</td>
<td class="">5<br>5<br>7</td>


<td class="r">2<br>7<br>7</td>
<td class="r">66</td>
<td class="r">3<br>4<br>9</td>


<td class="">1<br>2<br>8</td>
<td class="">15</td>
<td class="">7<br>9<br>9</td>


<td class="">3<br>3<br>7</td>
<td class="">39</td>
<td class="">5<br>7<br>7</td>

</tr>      <tr>
        <td>19/02/2024<br/>to<br/>24/02/2024</td>
      
<td class="">2<br>4<br>8</td>
<td class="">42</td>
<td class="">3<br>4<br>5</td>


<td class="">1<br>4<br>0</td>
<td class="">58</td>
<td class="">4<br>6<br>8</td>


<td class="">2<br>8<br>8</td>
<td class="">85</td>
<td class="">7<br>9<br>9</td>


<td class="">3<br>6<br>9</td>
<td class="">84</td>
<td class="">1<br>5<br>8</td>


<td class="r">2<br>6<br>6</td>
<td class="r">44</td>
<td class="r">2<br>5<br>7</td>


<td class="">3<br>5<br>9</td>
<td class="">71</td>
<td class="">2<br>3<br>6</td>

</tr>      <tr>
        <td>26/02/2024<br/>to<br/>02/03/2024</td>
      
<td class="">5<br>7<br>8</td>
<td class="">07</td>
<td class="">4<br>6<br>7</td>


<td class="">2<br>6<br>7</td>
<td class="">54</td>
<td class="">6<br>8<br>0</td>


<td class="r">1<br>1<br>4</td>
<td class="r">61</td>
<td class="r">6<br>6<br>9</td>


<td class="r">5<br>6<br>8</td>
<td class="r">94</td>
<td class="r">3<br>4<br>7</td>


<td class="">4<br>5<br>5</td>
<td class="">45</td>
<td class="">3<br>5<br>7</td>


<td class="">6<br>9<br>9</td>
<td class="">48</td>
<td class="">4<br>5<br>9</td>

</tr>      <tr>
        <td>04/03/2024<br/>to<br/>09/03/2024</td>
      
<td class="">2<br>5<br>7</td>
<td class="">47</td>
<td class="">8<br>9<br>0</td>


<td class="">1<br>6<br>7</td>
<td class="">45</td>
<td class="">1<br>1<br>3</td>


<td class="">7<br>8<br>8</td>
<td class="">35</td>
<td class="">2<br>5<br>8</td>


<td class="">2<br>3<br>6</td>
<td class="">19</td>
<td class="">2<br>3<br>4</td>


<td class="">1<br>2<br>8</td>
<td class="">18</td>
<td class="">4<br>5<br>9</td>


<td class="">1<br>2<br>4</td>
<td class="">71</td>
<td class="">3<br>9<br>9</td>

</tr>      <tr>
        <td>11/03/2024<br/>to<br/>16/03/2024</td>
      
<td class="r">2<br>6<br>8</td>
<td class="r">66</td>
<td class="r">2<br>4<br>0</td>


<td class="">3<br>7<br>0</td>
<td class="">01</td>
<td class="">2<br>2<br>7</td>


<td class="r">2<br>4<br>4</td>
<td class="r">05</td>
<td class="r">5<br>0<br>0</td>


<td class="">5<br>6<br>9</td>
<td class="">08</td>
<td class="">8<br>0<br>0</td>


<td class="">7<br>8<br>0</td>
<td class="">59</td>
<td class="">2<br>3<br>4</td>


<td class="r">7<br>8<br>8</td>
<td class="r">33</td>
<td class="r">1<br>4<br>8</td>

</tr>      <tr>
        <td>18/03/2024<br/>to<br/>23/03/2024</td>
      
<td class="">2<br>9<br>0</td>
<td class="">19</td>
<td class="">4<br>7<br>8</td>


<td class="r">8<br>9<br>0</td>
<td class="r">77</td>
<td class="r">3<br>4<br>0</td>


<td class="r">2<br>4<br>8</td>
<td class="r">44</td>
<td class="r">1<br>4<br>9</td>


<td class="">1<br>6<br>6</td>
<td class="">34</td>
<td class="">1<br>3<br>0</td>


<td class="r">4<br>4<br>8</td>
<td class="r">66</td>
<td class="r">7<br>9<br>0</td>


<td class="">4<br>5<br>7</td>
<td class="">62</td>
<td class="">2<br>3<br>7</td>

</tr>      <tr>
        <td>25/03/2024<br/>to<br/>30/03/2024</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">1<br>4<br>6</td>
<td class="">13</td>
<td class="">1<br>3<br>9</td>


<td class="">1<br>2<br>6</td>
<td class="">95</td>
<td class="">6<br>9<br>0</td>


<td class="">2<br>3<br>9</td>
<td class="">48</td>
<td class="">4<br>6<br>8</td>


<td class="r">2<br>7<br>9</td>
<td class="r">83</td>
<td class="r">1<br>2<br>0</td>


<td class="">4<br>5<br>8</td>
<td class="">70</td>
<td class="">6<br>6<br>8</td>

</tr>      <tr>
        <td>01/04/2024<br/>to<br/>06/04/2024</td>
      
<td class="r">2<br>7<br>0</td>
<td class="r">94</td>
<td class="r">2<br>4<br>8</td>


<td class="">7<br>9<br>9</td>
<td class="">54</td>
<td class="">3<br>4<br>7</td>


<td class="">1<br>2<br>8</td>
<td class="">15</td>
<td class="">3<br>4<br>8</td>


<td class="">3<br>6<br>6</td>
<td class="">53</td>
<td class="">2<br>4<br>7</td>


<td class="">4<br>7<br>8</td>
<td class="">91</td>
<td class="">3<br>8<br>0</td>


<td class="">2<br>2<br>7</td>
<td class="">14</td>
<td class="">1<br>1<br>2</td>

</tr>      <tr>
        <td>08/04/2024<br/>to<br/>13/04/2024</td>
      
<td class="">4<br>5<br>8</td>
<td class="">73</td>
<td class="">4<br>9<br>0</td>


<td class="">7<br>7<br>9</td>
<td class="">30</td>
<td class="">4<br>6<br>0</td>


<td class="r">6<br>8<br>9</td>
<td class="r">38</td>
<td class="r">3<br>6<br>9</td>


<td class="">1<br>5<br>6</td>
<td class="">25</td>
<td class="">1<br>1<br>3</td>


<td class="r">5<br>8<br>8</td>
<td class="r">16</td>
<td class="r">3<br>5<br>8</td>


<td class="">1<br>5<br>7</td>
<td class="">39</td>
<td class="">1<br>1<br>7</td>

</tr>      <tr>
        <td>15/04/2024<br/>to<br/>20/04/2024</td>
      
<td class="">3<br>8<br>9</td>
<td class="">02</td>
<td class="">1<br>3<br>8</td>


<td class="">4<br>8<br>9</td>
<td class="">18</td>
<td class="">3<br>7<br>8</td>


<td class="">5<br>8<br>8</td>
<td class="">13</td>
<td class="">3<br>4<br>6</td>


<td class="">5<br>6<br>0</td>
<td class="">18</td>
<td class="">1<br>3<br>4</td>


<td class="">3<br>4<br>7</td>
<td class="">43</td>
<td class="">6<br>8<br>9</td>


<td class="">2<br>4<br>8</td>
<td class="">40</td>
<td class="">5<br>6<br>9</td>

</tr>      <tr>
        <td>22/04/2024<br/>to<br/>27/04/2024</td>
      
<td class="">6<br>9<br>0</td>
<td class="">54</td>
<td class="">2<br>3<br>9</td>


<td class="">2<br>9<br>9</td>
<td class="">02</td>
<td class="">1<br>5<br>6</td>


<td class="r">1<br>6<br>8</td>
<td class="r">50</td>
<td class="r">2<br>8<br>0</td>


<td class="">1<br>6<br>8</td>
<td class="">54</td>
<td class="">1<br>6<br>7</td>


<td class="">5<br>5<br>9</td>
<td class="">97</td>
<td class="">1<br>3<br>3</td>


<td class="">2<br>3<br>3</td>
<td class="">89</td>
<td class="">4<br>6<br>9</td>

</tr>      <tr>
        <td>29/04/2024<br/>to<br/>04/05/2024</td>
      
<td class="r">1<br>2<br>8</td>
<td class="r">11</td>
<td class="r">1<br>4<br>6</td>


<td class="">1<br>1<br>7</td>
<td class="">90</td>
<td class="">5<br>5<br>0</td>


<td class="">1<br>5<br>8</td>
<td class="">41</td>
<td class="">1<br>4<br>6</td>


<td class="">8<br>9<br>0</td>
<td class="">78</td>
<td class="">9<br>9<br>0</td>


<td class="">2<br>2<br>3</td>
<td class="">76</td>
<td class="">2<br>7<br>7</td>


<td class="">6<br>8<br>0</td>
<td class="">48</td>
<td class="">2<br>2<br>4</td>

</tr>      <tr>
        <td>06/05/2024<br/>to<br/>11/05/2024</td>
      
<td class="">2<br>3<br>3</td>
<td class="">80</td>
<td class="">1<br>9<br>0</td>


<td class="">6<br>7<br>0</td>
<td class="">30</td>
<td class="">5<br>7<br>8</td>


<td class="">1<br>8<br>8</td>
<td class="">74</td>
<td class="">2<br>3<br>9</td>


<td class="">1<br>3<br>7</td>
<td class="">15</td>
<td class="">4<br>4<br>7</td>


<td class="">1<br>1<br>3</td>
<td class="">59</td>
<td class="">1<br>9<br>9</td>


<td class="">4<br>6<br>7</td>
<td class="">76</td>
<td class="">1<br>5<br>0</td>

</tr>      <tr>
        <td>13/05/2024<br/>to<br/>18/05/2024</td>
      
<td class="r">3<br>4<br>9</td>
<td class="r">61</td>
<td class="r">1<br>4<br>6</td>


<td class="r">2<br>3<br>8</td>
<td class="r">33</td>
<td class="r">3<br>4<br>6</td>


<td class="">2<br>6<br>6</td>
<td class="">48</td>
<td class="">8<br>0<br>0</td>


<td class="r">1<br>8<br>8</td>
<td class="r">72</td>
<td class="r">3<br>9<br>0</td>


<td class="">1<br>2<br>3</td>
<td class="">69</td>
<td class="">5<br>5<br>9</td>


<td class="">2<br>7<br>9</td>
<td class="">84</td>
<td class="">7<br>8<br>9</td>

</tr>      <tr>
        <td>20/05/2024<br/>to<br/>25/05/2024</td>
      
<td class="r">4<br>5<br>9</td>
<td class="r">88</td>
<td class="r">3<br>6<br>9</td>


<td class="r">2<br>4<br>5</td>
<td class="r">11</td>
<td class="r">2<br>4<br>5</td>


<td class="">4<br>4<br>8</td>
<td class="">69</td>
<td class="">3<br>7<br>9</td>


<td class="r">1<br>7<br>8</td>
<td class="r">61</td>
<td class="r">4<br>8<br>9</td>


<td class="">3<br>4<br>4</td>
<td class="">19</td>
<td class="">1<br>3<br>5</td>


<td class="">1<br>1<br>0</td>
<td class="">21</td>
<td class="">1<br>2<br>8</td>

</tr>      <tr>
        <td>27/05/2024<br/>to<br/>01/06/2024</td>
      
<td class="">1<br>7<br>0</td>
<td class="">82</td>
<td class="">3<br>4<br>5</td>


<td class="">4<br>6<br>0</td>
<td class="">08</td>
<td class="">5<br>5<br>8</td>


<td class="">4<br>7<br>9</td>
<td class="">02</td>
<td class="">2<br>2<br>8</td>


<td class="">2<br>8<br>9</td>
<td class="">90</td>
<td class="">6<br>7<br>7</td>


<td class="">1<br>1<br>5</td>
<td class="">70</td>
<td class="">1<br>2<br>7</td>


<td class="">6<br>7<br>9</td>
<td class="">21</td>
<td class="">6<br>6<br>9</td>

</tr>      <tr>
        <td>03/06/2024<br/>to<br/>08/06/2024</td>
      
<td class="r">5<br>7<br>9</td>
<td class="r">16</td>
<td class="r">2<br>6<br>8</td>


<td class="">7<br>7<br>8</td>
<td class="">21</td>
<td class="">5<br>6<br>0</td>


<td class="">3<br>4<br>0</td>
<td class="">71</td>
<td class="">1<br>2<br>8</td>


<td class="">4<br>7<br>9</td>
<td class="">01</td>
<td class="">4<br>8<br>9</td>


<td class="r">2<br>9<br>0</td>
<td class="r">16</td>
<td class="r">3<br>5<br>8</td>


<td class="">2<br>3<br>8</td>
<td class="">35</td>
<td class="">1<br>4<br>0</td>

</tr>      <tr>
        <td>10/06/2024<br/>to<br/>15/06/2024</td>
      
<td class="">4<br>6<br>0</td>
<td class="">08</td>
<td class="">2<br>7<br>9</td>


<td class="">1<br>5<br>8</td>
<td class="">40</td>
<td class="">5<br>6<br>9</td>


<td class="r">7<br>8<br>9</td>
<td class="r">44</td>
<td class="r">2<br>5<br>7</td>


<td class="">4<br>4<br>6</td>
<td class="">42</td>
<td class="">2<br>3<br>7</td>


<td class="">6<br>7<br>0</td>
<td class="">39</td>
<td class="">3<br>6<br>0</td>


<td class="">3<br>5<br>8</td>
<td class="">64</td>
<td class="">5<br>9<br>0</td>

</tr>      <tr>
        <td>17/06/2024<br/>to<br/>22/06/2024</td>
      
<td class="r">5<br>6<br>7</td>
<td class="r">83</td>
<td class="r">1<br>4<br>8</td>


<td class="">6<br>7<br>0</td>
<td class="">32</td>
<td class="">2<br>2<br>8</td>


<td class="">4<br>8<br>9</td>
<td class="">10</td>
<td class="">1<br>2<br>7</td>


<td class="">1<br>5<br>5</td>
<td class="">15</td>
<td class="">8<br>8<br>9</td>


<td class="">4<br>5<br>7</td>
<td class="">62</td>
<td class="">6<br>8<br>8</td>


<td class="">1<br>9<br>0</td>
<td class="">02</td>
<td class="">5<br>8<br>9</td>

</tr>      <tr>
        <td>24/06/2024<br/>to<br/>29/06/2024</td>
      
<td class="r">5<br>9<br>9</td>
<td class="r">38</td>
<td class="r">1<br>8<br>9</td>


<td class="">2<br>5<br>7</td>
<td class="">45</td>
<td class="">7<br>9<br>9</td>


<td class="">2<br>2<br>7</td>
<td class="">17</td>
<td class="">1<br>7<br>9</td>


<td class="">3<br>6<br>9</td>
<td class="">82</td>
<td class="">3<br>4<br>5</td>


<td class="r">3<br>0<br>0</td>
<td class="r">38</td>
<td class="r">2<br>7<br>9</td>


<td class="">6<br>6<br>9</td>
<td class="">14</td>
<td class="">2<br>5<br>7</td>

</tr>      <tr>
        <td>01/07/2024<br/>to<br/>06/07/2024</td>
      
<td class="">1<br>2<br>6</td>
<td class="">93</td>
<td class="">2<br>2<br>9</td>


<td class="">1<br>3<br>0</td>
<td class="">42</td>
<td class="">1<br>3<br>8</td>


<td class="">3<br>4<br>5</td>
<td class="">21</td>
<td class="">1<br>4<br>6</td>


<td class="">2<br>3<br>3</td>
<td class="">89</td>
<td class="">6<br>6<br>7</td>


<td class="">4<br>7<br>8</td>
<td class="">92</td>
<td class="">6<br>7<br>9</td>


<td class="">5<br>5<br>8</td>
<td class="">87</td>
<td class="">2<br>5<br>0</td>

</tr>      <tr>
        <td>08/07/2024<br/>to<br/>13/07/2024</td>
      
<td class="">1<br>8<br>9</td>
<td class="">86</td>
<td class="">7<br>9<br>0</td>


<td class="r">3<br>4<br>7</td>
<td class="r">44</td>
<td class="r">1<br>4<br>9</td>


<td class="r">1<br>2<br>7</td>
<td class="r">00</td>
<td class="r">5<br>7<br>8</td>


<td class="">1<br>2<br>7</td>
<td class="">08</td>
<td class="">4<br>5<br>9</td>


<td class="r">5<br>8<br>9</td>
<td class="r">27</td>
<td class="r">2<br>6<br>9</td>


<td class="">1<br>5<br>6</td>
<td class="">25</td>
<td class="">6<br>9<br>0</td>

</tr>      <tr>
        <td>15/07/2024<br/>to<br/>20/07/2024</td>
      
<td class="">1<br>5<br>6</td>
<td class="">28</td>
<td class="">1<br>2<br>5</td>


<td class="">1<br>2<br>9</td>
<td class="">28</td>
<td class="">1<br>8<br>9</td>


<td class="r">6<br>7<br>7</td>
<td class="r">00</td>
<td class="r">1<br>3<br>6</td>


<td class="">7<br>8<br>8</td>
<td class="">34</td>
<td class="">7<br>7<br>0</td>


<td class="">1<br>4<br>7</td>
<td class="">20</td>
<td class="">4<br>6<br>0</td>


<td class="r">6<br>8<br>9</td>
<td class="r">38</td>
<td class="r">2<br>7<br>9</td>

</tr>      <tr>
        <td>22/07/2024<br/>to<br/>27/07/2024</td>
      
<td class="">6<br>6<br>0</td>
<td class="">23</td>
<td class="">4<br>9<br>0</td>


<td class="">1<br>3<br>4</td>
<td class="">80</td>
<td class="">1<br>3<br>6</td>


<td class="r">3<br>6<br>8</td>
<td class="r">77</td>
<td class="r">1<br>6<br>0</td>


<td class="r">2<br>3<br>4</td>
<td class="r">94</td>
<td class="r">1<br>5<br>8</td>


<td class="">3<br>5<br>9</td>
<td class="">75</td>
<td class="">7<br>9<br>9</td>


<td class="">6<br>7<br>8</td>
<td class="">14</td>
<td class="">3<br>5<br>6</td>

</tr>      <tr>
        <td>29/07/2024<br/>to<br/>03/08/2024</td>
      
<td class="">1<br>7<br>8</td>
<td class="">62</td>
<td class="">2<br>4<br>6</td>


<td class="">5<br>7<br>9</td>
<td class="">18</td>
<td class="">2<br>3<br>3</td>


<td class="">1<br>4<br>7</td>
<td class="">21</td>
<td class="">5<br>7<br>9</td>


<td class="">5<br>6<br>9</td>
<td class="">09</td>
<td class="">2<br>3<br>4</td>


<td class="">2<br>6<br>0</td>
<td class="">80</td>
<td class="">4<br>8<br>8</td>


<td class="">7<br>7<br>8</td>
<td class="">24</td>
<td class="">1<br>6<br>7</td>

</tr>      <tr>
        <td>05/08/2024<br/>to<br/>10/08/2024</td>
      
<td class="">1<br>7<br>0</td>
<td class="">80</td>
<td class="">2<br>9<br>9</td>


<td class="r">3<br>6<br>9</td>
<td class="r">83</td>
<td class="r">4<br>4<br>5</td>


<td class="">4<br>6<br>8</td>
<td class="">80</td>
<td class="">5<br>6<br>9</td>


<td class="">1<br>6<br>6</td>
<td class="">32</td>
<td class="">1<br>1<br>0</td>


<td class="">7<br>9<br>0</td>
<td class="">64</td>
<td class="">5<br>9<br>0</td>


<td class="">6<br>6<br>7</td>
<td class="">97</td>
<td class="">1<br>3<br>3</td>

</tr>      <tr>
        <td>12/08/2024<br/>to<br/>17/08/2024</td>
      
<td class="r">1<br>5<br>8</td>
<td class="r">44</td>
<td class="r">3<br>5<br>6</td>


<td class="">3<br>5<br>8</td>
<td class="">65</td>
<td class="">3<br>5<br>7</td>


<td class="">3<br>4<br>7</td>
<td class="">45</td>
<td class="">4<br>5<br>6</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">3<br>6<br>0</td>
<td class="">98</td>
<td class="">4<br>7<br>7</td>


<td class="">3<br>4<br>8</td>
<td class="">59</td>
<td class="">2<br>7<br>0</td>

</tr>      <tr>
        <td>19/08/2024<br/>to<br/>24/08/2024</td>
      
<td class="r">5<br>6<br>8</td>
<td class="r">94</td>
<td class="r">1<br>6<br>7</td>


<td class="">2<br>3<br>0</td>
<td class="">59</td>
<td class="">2<br>3<br>4</td>


<td class="">3<br>5<br>7</td>
<td class="">59</td>
<td class="">5<br>6<br>8</td>


<td class="">4<br>4<br>8</td>
<td class="">65</td>
<td class="">2<br>3<br>0</td>


<td class="">2<br>4<br>6</td>
<td class="">20</td>
<td class="">1<br>3<br>6</td>


<td class="">1<br>1<br>3</td>
<td class="">56</td>
<td class="">8<br>8<br>0</td>

</tr>      <tr>
        <td>26/08/2024<br/>to<br/>31/08/2024</td>
      
<td class="">1<br>3<br>4</td>
<td class="">85</td>
<td class="">8<br>8<br>9</td>


<td class="r">2<br>6<br>6</td>
<td class="r">49</td>
<td class="r">1<br>4<br>4</td>


<td class="">3<br>6<br>0</td>
<td class="">97</td>
<td class="">2<br>5<br>0</td>


<td class="">5<br>5<br>0</td>
<td class="">02</td>
<td class="">3<br>3<br>6</td>


<td class="">2<br>2<br>6</td>
<td class="">09</td>
<td class="">3<br>8<br>8</td>


<td class="r">1<br>7<br>9</td>
<td class="r">77</td>
<td class="r">4<br>5<br>8</td>

</tr>      <tr>
        <td>02/09/2024<br/>to<br/>07/09/2024</td>
      
<td class="">4<br>6<br>8</td>
<td class="">84</td>
<td class="">7<br>8<br>9</td>


<td class="">1<br>1<br>0</td>
<td class="">24</td>
<td class="">6<br>8<br>0</td>


<td class="">5<br>8<br>9</td>
<td class="">28</td>
<td class="">1<br>8<br>9</td>


<td class="">1<br>1<br>4</td>
<td class="">69</td>
<td class="">5<br>6<br>8</td>


<td class="">1<br>3<br>6</td>
<td class="">06</td>
<td class="">1<br>1<br>4</td>


<td class="">1<br>3<br>7</td>
<td class="">15</td>
<td class="">2<br>6<br>7</td>

</tr>      <tr>
        <td>09/09/2024<br/>to<br/>14/09/2024</td>
      
<td class="">3<br>4<br>7</td>
<td class="">41</td>
<td class="">3<br>4<br>4</td>


<td class="">1<br>5<br>7</td>
<td class="">30</td>
<td class="">5<br>7<br>8</td>


<td class="">1<br>7<br>0</td>
<td class="">85</td>
<td class="">1<br>5<br>9</td>


<td class="r">4<br>5<br>8</td>
<td class="r">72</td>
<td class="r">1<br>5<br>6</td>


<td class="">3<br>9<br>0</td>
<td class="">29</td>
<td class="">5<br>5<br>9</td>


<td class="r">1<br>2<br>3</td>
<td class="r">61</td>
<td class="r">5<br>6<br>0</td>

</tr>      <tr>
        <td>16/09/2024<br/>to<br/>21/09/2024</td>
      
<td class="r">3<br>5<br>8</td>
<td class="r">61</td>
<td class="r">1<br>4<br>6</td>


<td class="r">1<br>8<br>0</td>
<td class="r">94</td>
<td class="r">3<br>4<br>7</td>


<td class="">4<br>7<br>8</td>
<td class="">90</td>
<td class="">2<br>3<br>5</td>


<td class="">2<br>3<br>4</td>
<td class="">95</td>
<td class="">3<br>3<br>9</td>


<td class="">1<br>1<br>2</td>
<td class="">45</td>
<td class="">3<br>4<br>8</td>


<td class="r">4<br>6<br>9</td>
<td class="r">94</td>
<td class="r">4<br>5<br>5</td>

</tr>      <tr>
        <td>23/09/2024<br/>to<br/>28/09/2024</td>
      
<td class="">3<br>3<br>8</td>
<td class="">42</td>
<td class="">1<br>4<br>7</td>


<td class="">4<br>0<br>0</td>
<td class="">48</td>
<td class="">2<br>2<br>4</td>


<td class="">2<br>6<br>0</td>
<td class="">81</td>
<td class="">6<br>7<br>8</td>


<td class="r">4<br>8<br>9</td>
<td class="r">11</td>
<td class="r">5<br>7<br>9</td>


<td class="">4<br>4<br>0</td>
<td class="">82</td>
<td class="">3<br>3<br>6</td>


<td class="r">6<br>6<br>9</td>
<td class="r">11</td>
<td class="r">4<br>7<br>0</td>

</tr>      <tr>
        <td>30/09/2024<br/>to<br/>05/10/2024</td>
      
<td class="">2<br>5<br>0</td>
<td class="">74</td>
<td class="">5<br>9<br>0</td>


<td class="">2<br>5<br>6</td>
<td class="">35</td>
<td class="">1<br>5<br>9</td>

</tbody>
</table>
</div>
</div>
</div>

</div>



<div class="chart-result">    
		<div>TARA MUMBAI DAY</div>
		<span>256-35-159</span><br>
		<a href="tara-mumbai-day.php">Refresh Result</a>
</div>
<center>
	<div id="bottom"></div>
	<a href="#top" class="button2"> Go to Top </a>
</center>
<p>
29</p>
	
<!-- adv & links -->
<!-- footer -->
<footer style="font-style: normal;">
  <div>
    <a style="color: red;" href="https://spboss.in" title="SATTA MATKA">Home</a> |
    <a style="color: green;" href="https://spboss.in/guessing-forum.php" title="Satta matka guessing">Guessing Forum</a> |
    <a style="color: purple;" href="https://spboss.in/ever-green-tricks/satta-matka-tricks-zone-tips.php" title="Satta matka tricks">100% Fix Jodi Tricks</a> |
    <a style="color: blue;" href="https://spboss.in/satta-matka-fix-game.php" title="SATTA MATKA">Date Fix Game</a> |
	<br>
	<a style="color: purple;" href="https://spboss.in/about.php" title="About">About Us</a> |
	<a style="color: purple;" href="https://spboss.in/contact.php" title="Contact">Contact Us</a> |
	<a style="color: purple;" href="https://spboss.in/tos.php" title="Term and Conditions">T&C</a> |
	<a style="color: purple;" href="https://spboss.in/privacy.php" title="Privacy Policy">Privacy Policy</a> |
  </div>
  <a class="ftr-icon" href="https://spboss.in">spboss.in</a>
</footer>

<!--<a class="mp-btn" href="https://spboss.in/dpbossplay-matka-online.php"><i>Matka Play</i></a> -->
<a class="mp-btn" href="https://sachin99.com" rel="nofollow" target="_blank"><i>Matka Play</i></a>

    
</body>
</html>