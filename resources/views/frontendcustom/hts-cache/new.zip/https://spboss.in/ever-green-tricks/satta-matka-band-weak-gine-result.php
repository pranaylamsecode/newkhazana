<!DOCTYPE html>
<html lang="en-in">
<head>
<meta charset="UTF-8">
<title>How to Count Closed Week tips and tricks: SPBOSS</title>
<meta name="description" content="Master the art of counting closed weeks with expert tips and tricks from SPBOSS. Unlock the secrets to maximizing your success and staying ahead of the game." />
<meta name="keywords" content="band din ko kese gine, how to count closed week, kalyan open to close ank, milan day. satta matka tricks" />
<link rel="canonical" href="https://spboss.in/ever-green-tricks/satta-matka-band-weak-gine-result.php" />
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="yes" name="apple-touch-fullscreen">
<meta name="robots" content="follow, all" />
<meta name="author" content="spboss.in">
<meta name="copyright" content="spboss.in" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="img/favicon.ico">

<link rel="stylesheet" href="css-js/style.css">
</head>
<body>

<div id="top"></div>
<header class="bdr mb-1">
<a href="#">
<img src="img/logo.webp" alt="Image of spboss.in" width="220" height="82.324">
</a>
</header>

<div class="para-1 bdr mb-1 p-1">
<h4 class="h4 title1">❋ SATTA MATKA ❋</h4>
<p class="p p1 my-1">❋ SATTA MATKA ❋ MATKA ❋ SATTAMATKA ❋ SATTA MATKA NUMBER ❋ SATTA MATKA NUMBER ❋ SATTA MATKA SITE ❋ SATTA-KING ❋ FAST RESULT❋ SATTA NUMBER ❋ MATKA NUMBER ❋ KALYAN ❋ MUMBAI ❋ MILAN ❋ RAJDHANI ❋ GALI ❋ DISAWAR ❋ GHAZIABAD ❋ FARIDABAD ❋</p>
<a href="#" class="red-btn">[ CALL ]</a>
</div>
<div class="para-2 bdr  mb-1 p-1 bdr2">
<p class="p p1">ALL TRICKS ARE CREATED BY :- PROF. ADMIN SIR ( MATKA PROFESSOR )</p>
<p class="p1 my-1">spboss.in</p>
<a href="#" class="red-btn mb-1">[ CALL ]</a>
<p class="p p1">DONT COPY OR MISSUSE THIS TRICKS</p>
</div>
<div class="btn-div1  bdr  mb-1 p-1">
<a href="#" class="btn red-btn">HOME</a>
<a href="#" class="btn yellow-btn">BLOG</a>
<a href="#" class="btn red-btn">FORUM</a>
<a href="#" class="btn yellow-btn">RECORD</a>
<p style="margin-top: 10px;" class="p p1 ">DO NOT FORGET TO THANK TO THE AUTHOR FOR SHARING THIS VALUABLE INFORMATION WITH US.</p>
</div>
<div class="bdr bdr3 mb-1 my-card">
<h1 class="h4 bg bg-primary">AGAR KISI DIN BAND HO TO USE KAISE GINE</h1>
<small>Created: 20.11 09:03 by Admin Sir</small>
<p>
<b>Views: </b> 36389
WAISE TO SATTA/MATKA ME KOI RULE PERMANENT NAHI HOTA..!<br>
Par kuchh rule barso se satte me chal rahe hai wo basic rule hai jo kabhi nahi tutate...<br>
<span class="bg bg-dark my-2 d-inline">CASE I:</span>
<br>
Sabse pahle to ye sawaal..<br><br>
Q. JO WEEK BAND HAI KYA USE GINANA HAI...???<br><br>
Aksar guessers mujhe call karke puchhate hai ki jo week band hai use count kare yaa nahi.. hame kuchh week pahle ki jodi niche lani hai to bichh me aane wala band week gine yaa nahi...<br><br>
TO MAI BATA DU KI KOI BHI WEEK HO BAND YAA CHALU SABHI GINANE HOTE HAI.. BHALE HI 1 WEEK BAND HO 2 WEEK BAND HO.. YAA 3 MAHINE (aapko pata hoga kab band huaa tha.)... <br><br>
Par jaruri nahi hai ki satte wale wo week count hi kare..<br>
kyonki aisa pahle bhi huaa hai.. ki un logo ne band week count naa kiya ho...<br><br>
For example..<br>
12.10.2009 wale week me aise hi... 11 dino ke liye band tha.. tab.. un logo ne band week count nahi kiya tha...<br><br>
<span class="sm-title">KALYAN</span>
<br>
<b>[06-04-2009]</b>
<br>
37 97 76 09 <span class="bg bg-danger">12</span> 41<br>
28 40 56 48 19 54<br>
04 09 30 81 37 57<br>
60 93 52 <span class="bg bg-danger">60</span> 65 02<br>
42 72 33 81 50 54<br>
<span class="bg bg-primary">33</span> 77 <span class="bg bg-primary">33</span> 35 78 31<br>
87 71 86 <span class="bg bg-primary">07</span> 61 79<br>
03 38 29 67 13 43<br>
65 03 35 14 <span class="bg bg-danger">12</span> 92<br>
17 15 99 <span class="bg bg-danger">06</span> 56 95<br><br>
<b>[14-09-2009]</b><br>
47 97 91 10 <span class="bg bg-danger">14</span> 76<br>
** 50 27 25 94 57<br>
** 03 79 31 72 27<br>
07 72 87 <span class="bg bg-danger">95</span> 08 63<br>
75 96 41 ** ** **<br>
**-**-**-**-**-**--X<br>
<span class="bg bg-primary">38</span> 99 <span class="bg bg-primary">33</span> 26 69 62<br>
40 67 98 <span class="bg bg-primary">25</span> 00 62<br>
69 59 82 63 44 48<br>
83 01 02 29 <span class="bg bg-danger">46</span> 07<br>
98 84 41 <span class="bg bg-danger">59</span> 23 **<br>
<span class="bg bg-danger my-2 d-inline">DONO JAGAH SAME CONDITION BANI HAI ... AUR YAHA PAR BAND WEEK COUNT NAHI KIYA HAI..</span><br>
<small>JAB PAHLI BAAR 2 WEEK UPPER KI JODI 60 PALATKAR 4 WEEK NICHE 06 BANI TO SAME DUSRI BAAR.. 2 WEEK UPPER KI JODI 95[BAND WEEK CHHODKAR 2 WEEK UPPER] 4 WEEK NICHE PALATKAR 59 AAYI...<br>
14 GROUP KE SATH BHI YAHI HUAA..</small><br>
<span class="bg bg-danger my-2 d-inline">PAR HUM LOG MAIN ME WEEK COUNT KARENGE... KYONKI JYADATAR WEEK COUNT HOTA HAI....</span><br>
<span class="bg bg-dark my-2 d-inline">CASE II:</span>
<br>
Ab dusra sawaal ye ki ..<br>
<b>Q. JIS DIN KI JODI HAME LENA THI WAHA PAR BAND HAI.. KYA KARE ?</b>
<br><br>
Ab hota ye hai.. ki hum koi scheme pakadate hai aur use 1 , 2 week yaa kai aur din khelte huye chalate hai.. par kabhi kabhi jis din ki jodi uthana hota hai us din band hota hai.. tab..<br>
do condition ban sakti hai... yaa to jodi kai din uper ki ho yaa fir just upper ki cross me...<br><br>
i]Jyadatar ye hota hai ki jab kabhi bhi kuchh din upper ki jodi niche lana ho aur jis din ki jodi lena hai waha holiday ho to uske ek din upper ki jodi aati hai....<br><br>
jaise EXAMPLE:<br><br>
<b>FIRST TIME:</b><br>
<span class="bg bg-danger">53</span> 36 95 18 69 **<br>
** 60 74 44 43 09<br>
25 67 65 97 00 94<br>
26 32 ** 88 ** 81<br>
26 69 16 62 41 91<br>
81 87 21 88 28 65<br>
81 46 62 35 78 59<br>
97 51 24 42 80 78<br>
39 85 69 ** 69 04<br>
72 78 81 60 62 65<br>
20 36 01 74 88 73<br>
98 77 37 30 39 37<br>
** 01 66 59 03 27<br>
08 27 41 81 40 76<br>
85 75 99 57 17 44<br>
50 13 35 69 19 61<br>
31 78 12 17 71 21<br>
70 82 50 87 64 03<br>
88 79 44 11 81 64<br>
31 80 54 57 69 33<br>
36 17 93 82 95 33<br>
<span class="bg bg-primary">07</span> 79 59 41 <span class="bg bg-danger">53</span> **<br><br>
<b>SECOND TIME:</b><br>
<span class="bg bg-danger">63</span> 00 31 04 70 88<br>
53 21 66 78 66 56<br>
21 18 50 20 23 67<br>
17 98 36 77 47 93<br>
00 97 56 15 05 56<br>
53 10 53 29 21 86<br>
94 42 52 65 98 40<br>
80 33 59 38 91 48<br>
46 72 29 83 05 71<br>
71 79 15 75 66 91<br>
33 48 26 95 02 75<br>
70 61 66 89 02 82<br>
17 46 98 56 48 23<br>
82 65 31 ** 43 42<br>
11 60 56 95 63 82<br>
67 55 ** 26 50 29<br>
** ** 14 01 09 43<br>
38 80 35 36 71 75<br>
48 35 07 03 11 55<br>
97 09 92 28 97 39<br>
<span class="bg bg-primary">07</span> 06 83 12 <span class="bg bg-danger">63</span> 18<br><br>
<small>KUCHH DINO PAHLE YE SCHEME BANI THI KI 07 SE 20 WEEK UPPER KI JODI 07 KE FRIDAY KO AANA THI.. PAR 20 WEEK UPPER HOLIDAY HONE KE KAARAN <br>EK WEEK UPPER 21 WE WEEK KI JODI 53 07 KE FRIDAY KO 53 AAYI..<br>
AISE HI CONDITION DUSRI TISRI BAAR BANANE PAR THIK TARAH SE 20 WEEK KI HI JODI 63 FRIDAY KO 63 AAYI HAI...</small><br><br>
<span class="bg bg-danger fz-16 d-inline">YAHA PAR PURI SCHEME AUR CONDITION SATH HI PAHLE BAAR KI JODIYA NAHI SHOW KI HAI....</span><br><br>
ii]Ab agar jodi cross me girna ho aur us din jodi naa ho to uske side ki jodi aati hai...<br><br>
EXAMPLE:<br><br>
<b>FIRST TIME:</b><br>
33 48 26 95 <span class="bg bg-primary">02</span> 75<br>
70 61 66 <span class="bg bg-danger">89</span> <span class="bg bg-primary">02</span> 82<br>
17 46 98 56 <span class="bg bg-danger">48</span> 23<br><br>
<b>SECOND TIME:</b><br>
17 46 98 56 <span class="bg bg-primary">48</span> 23<br>
82 65 <span class="bg bg-danger">31</span> ** <span class="bg bg-primary">43</span> 42<br>
11 60 56 95 <span class="bg bg-danger">63</span> 82<br><br>
<b>THIRD TIME:</b><br>
57 62 65 53 <span class="bg bg-primary">59</span> 20<br>
56 55 85 <span class="bg bg-danger">97</span> <span class="bg bg-primary">59</span> 73<br>
42 86 ** 11 <span class="bg bg-danger">47</span> **<br><br>
<small>YE SCHEME ME SUCCESSIVE FRIDAYS KO EK HI GROUP KI JODI BANANE PAR NEXT FRIDAY KO CROSS ME EK WEEK UPPER KE THURSDAY KI JODI AATI HAI..<br>
SECOND TIME ME CROSS ME HOLIDAY HONE KE KAARAN US DIN KE SIDE KI JODI AAYI HAI...</small><br><br>
Isme ek dikkat aur hai.. ki agar cross waala din week ka pahla yaa aakhari din ho to... kya kare...<br>
to us jagah jo pahle bataya hai.. ek week uper ki jodi hi aati hai...<br><br>
EXAMPLE: <br>
<b>FIRST TIME:</b><br>
70 82 50 87 64 03<br>
88 79 44 <span class="bg bg-primary">11</span> 81 <span class="bg bg-danger">64</span><br>
31 <span class="bg bg-primary">80</span> 54 57 <span class="bg bg-danger">69</span> 33<br><br>
<b>SECOND TIME:</b><br>
56 55 85 97 59 <span class="bg bg-danger">73</span><br>
42 86 ** <span class="bg bg-primary">11</span> 47 **<br>
51 <span class="bg bg-primary">80</span> 90 41 <span class="bg bg-danger">37</span> 72<br><br>
<small>YAHA PAR JODIYA 11 80 KE AASPASS AA RAHI THI.. 64 JODI 69 AAYI , PAR SECOND TIME HOLIDAY HONE KE KAARAN EK WEEK UPPER KI JODI 73 KI 37 AAYI...</small><br><br>
<span class="bg bg-dark my-2 d-inline">CASE III:</span>
<br>
Ab kabhi kabhi ye condition banati hai ki jis din jodi aana hoti hai .. agar waha par holiday aa jaye to...<br>
<br>
Q. SCHEME KE ANUSAAR KISI DIN EK JAGAH KA BRACKET AANA HAI PAR US DIN HOLIDAY HAI.. KYA HOGA?<br>
Aise din ye hota hai ki scheme agar strong hai to jodi aati hi aati hai.. chahe wo next week hi kyo naa aaye to holiday hone par usi din next week jodi aati hai...<br><br>
EXAMPLE:<br>
<b>FIRST TIME:</b><br>
06 87 84 33 12 <span class="bg bg-danger">24</span><br>
83 63 66 84 31 81<br>
63 00 31 04 70 88<br>
53 21 66 78 66 56<br>
21 18 50 20 23 67<br>
17 98 36 77 47 93<br>
00 97 56 <span class="bg bg-primary">15</span> 05 56<br>
53 10 53 <span class="bg bg-danger">29</span> 21 86<br>
63 00 31 04 70 88<br><br>
<b>SECOND TIME:</b><br>
63 00 31 04 70 <span class="bg bg-danger">88</span><br>
53 21 66 78 66 56<br>
21 18 50 20 23 67<br>
17 98 36 77 47 93<br>
00 97 56 15 05 56<br>
53 10 53 29 21 86<br>
94 42 52 <span class="bg bg-primary">65</span> 98 40<br>
80 33 59 <span class="bg bg-danger">38</span> 91 48<br>
46 72 29 83 05 71<br><br>
<b>THIRD TIME:</b><br>
94 42 52 65 98 <span class="bg bg-danger">40</span><br>
80 33 59 38 91 48<br>
46 72 29 83 05 71<br>
71 79 15 75 66 91<br>
33 48 26 95 02 75<br>
70 61 66 89 02 82<br>
17 46 98 <span class="bg bg-primary">56</span> 48 23<br>
82 65 31 ** 43 42<br>
11 60 56 <span class="bg bg-danger">95</span> 63 82<br><br>
<small>YAHA YE HO RAHA HAI.. KI 15 KE GROUP ME JODI THURSDAY KO BANANE PAR 15 GROUP KE 6 WEEK UPPER SATURDAY KI JODI EK WEEK NICHE THURSDAY ME AA RAHI HAI...<br>
FIRST TIME 24 KI 29 AAYI<br>
SECOND TIME 88 KI 38 AAYI<br>
THIRD TIME THURSDAY KO HOLIDAY HO GAYA TO... NEXT WEEK 40 KI 95 AAYI.....</small><br><br>
</p>
<div class="btn-div my-1">
<a class="btn red-btn" href="#">New</a>
<a class="btn yellow-btn" href="#">Old</a>
</div>
</div>

<center>
<div id="bottom"></div>
<a href="#top" class="button2"> Go to Top </a>
</center>
<style>

html{overflow-x:hidden;scroll-behavior:smooth}body{background-color:#fc9;color:#000;font-weight:700;text-align:center!important;margin-bottom:0;margin-top:4px;font-family:Helvetica,sans-serif!important}*{transition:all .3s}a{text-decoration:none!important;color:inherit}.my-header{border-radius:10px 0 10px 10px;margin-bottom:3px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:1px 2px}.my-header img{height:160px;width:auto;margin:-28px 0 -34px}.open-close{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:20px 5px 22px}.open-close h2{color:#fff;font-size:32px;background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);display:inline-block;padding:10px 20px 10px;margin:0;border-radius:10px}.open-close h3{color:#1a237e;font-size:29px;margin:0 0 20px}.my-card{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #9c27b0;box-shadow:0 0 9px -1px #ffeddc;padding:0 0 2px;overflow:hidden}.my-card h3{color:#fff;font-size:32px;margin:0;padding:2px 0 1px}.headering-1 h3{background-color:#50005b}.headering-2 h3{background-color:#ff0;color:#000}.headering-3 h3{background-color:#0f005b}.my-card h2{color:#232323;margin:10px 0;font-size:22px}.my-footer{border-radius:10px 0 10px 10px;margin-bottom:2px!important;border:2px solid #eb008b;box-shadow:0 0 9px -1px #ffeddc;padding:0 5px 22px}.my-footer .top-div{z-index:81}.my-footer .top-div a{z-index:41;cursor:pointer}.my-footer .my-img{z-index:-10}.my-footer .my-img img{height:160px;width:auto;margin:-28px 0 -34px;z-index:-9}.my-footer .two-btn a{border:2px solid #e91e63;padding:3px 8px 4px;border-radius:5px;font-size:18px;color:#fff;background-color:#e91e63;font-weight:500;display:inline-block}.my-footer .last-para{margin:20px 0 0}.my-footer .last-para p{margin:6px 0 0;font-size:20px;font-weight:400;color:#151515}@media only screen and (max-width:500px){.my-header img{height:90px;width:auto;margin:-16px 0 -19px}.open-close{padding:8px 0 10px}.open-close h3{font-size:20px;margin-bottom:10px}.open-close h2{font-size:22px}.my-card h3{font-size:24px}.my-card h2{font-size:17px}.my-footer{padding-bottom:10px}.my-footer .my-img img{height:100px;width:auto;margin:-16px 0 -19px}.my-footer .two-btn a{font-size:14px;padding:5px 5px 6px}.my-footer .last-para p{font-size:16px}}@media only screen and (max-width:320px){.my-footer .two-btn a{font-size:12px;padding:3px}}


.logo {
border: 2px solid #eb008b;
border-radius: 10px 0 10px 10px;
margin: 2px;
overflow: hidden;
}
.logo amp-img {
width: 220px;
height: auto;
padding: 6px 0 0;
}
.button2 {
background-color: #a0d5ff;
color: #220c82;
padding: 10px 30px;
font-size: 16px;
margin: 20px auto;
border-radius: 10px;
border: 2px solid #0000005c;
font-weight: 800;
text-shadow: 1px 1px #00bcd4;
box-shadow: 0 8px 10px 0 rgb(0 0 0 / 20%), 0 6px 8px 0 rgb(0 0 0 / 19%);
display: inline-block;
transition: all .3s;
}.ad-div11 {
text-align: center;
margin: 0 0 10px;
}
.chart-list {
border: 2px solid #eb008b;
border-radius: 10px 0 10px 10px;
margin-bottom: 2px;
width: 50%;
margin: 0 auto 10px;
text-align: center;
font-weight: 600;
}
.chart-list.ab1 {
border-color: #003c6c;
}
.chart-list h4 {
color: #fff;
padding: 5px 10px 3px;
font-size: 24px;
border-top-left-radius: 7px;
margin: 0;
}
.chart-list.ab1 h4 {
background-color: #024c88;
}
.chart-list a {
display: block;
font-size: 22px;
padding: 5px 7px 4px;
text-decoration: none;
}
.chart-list.ab1 a {
border-bottom: 2px solid #024c88;
color: #003c6c;
}
footer {
background-color: #fff;
color: red;
font-weight: bold;
font-size: 25px;
text-decoration: none;
border: 4px groove purple;
border-radius: 10px 0 0 0;
text-shadow: 1px 1px gold;
margin: 3px;
}
footer > div {
border-bottom: 2px solid #b2ddff;
padding: 10px 0;
margin-bottom: 10px;
}
footer > div a {
text-decoration: none;
}
footer > div a:hover {
text-decoration: none;
}
footer .ftr-icon {
text-decoration: none;
font-size: 35px;
text-transform: uppercase;
color: #007bff;
}
footer p {
margin: 10px 0 10px;
line-height: 35px;
}
footer p span {
color: #36f;
}

body {
  background-color: #fc9;
  text-align: center;
  padding-left: 10px;
  padding-right: 10px;
  font-family: 'Roboto',sans-serif;
}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
</style>
<div class="chart-list ab1">
<h4>SPECIAL DAILY GAME ZONE</h4>
<a href="https://spboss.in/guessing-forum.php"> Dpboss Guessing Forum </a>
<a href="https://spboss.in/satta-matka-fix-game.php"> 100% Date Fix Free Game Open TO Close </a>
<a href="https://spboss.in/khatris-favourite-panna-chart.php"> Ratan Khatri Fix Panel Chart </a>
<a href="https://spboss.in/matka-final-number-chart.php"> Matka Final Number Trick Chart </a>
<a href="https://spboss.in/matka-jodi-count-chart.php">Matka Jodi Count Chart</a>
<a href="https://spboss.in/fix-open-to-close-by-date.php">Dhanvarsha Daily Fix Open To Close</a>
<a href="https://spboss.in/jodi-chart-family-matka.php">Matka Jodi Family Chart</a>
<a href="https://spboss.in/penal-count-chart.php">Penal Count Chart</a>
<a href="https://spboss.in/penal-total-chart.php">Penal Total Chart</a>
<a href="https://spboss.in/all-22-card-panna-penal-patti-chart.php">All 220 Card List</a>
</div>


<footer>
<div>
<a style="color: red;" href="https://spboss.in" title="SATTA MATKA">Home</a> |
<a style="color: green;" href="https://spboss.in/guessing-forum.php" title="Satta matka guessing">Guessing Forum</a> |
<a style="color: purple;" href="https://spboss.in/ever-green-tricks/satta-matka-tricks-zone-tips.php" title="Satta matka tricks">100% Fix Jodi Tricks</a> |
<a style="color: blue;" href="https://spboss.in/satta-matka-fix-game.php" title="SATTA MATKA">Date Fix Game</a>
</div>
<a class="ftr-icon" href="https://spboss.in">spboss.in</a>
<p>
All Rights Reseved®
<br>
(1980-2022)
<br>
Contact (Astrologer-<span>Dpboss</span>)
</p>
</footer>
</body>
</html>