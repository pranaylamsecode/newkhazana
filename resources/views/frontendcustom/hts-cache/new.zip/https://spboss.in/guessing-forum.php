
<!-- Cached copy, generated 11:14:12 -->

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Satta Matka Guessing Kalyan Fix Number 143 Madhur Matka</title>
<meta name="description" content="Satta matka guru Satta Matka Guessing Forum For Kalyan Matka Result Main Bazar Madhur Matka Milan Rajdhani Time Bazar Morning Night Fix Satta Number All Satta King Matka Guessing 143 Satta Batta Pakka Matka 143 24 Guessing Tricks For Today Lucky Number Top Matka Professor Post Your SattaMatka Leak Jodi Fix Ank Matka Games Online Matka Play Website App Trusted Dp boss Matka Net" />
<meta name="keywords" content="satta matka, matka guessing, fix satta number, madhur matka. matka result, satta, matka, sattamatka, matka lucky number, today satta number, kalyan fix jodi, kalyan matka guessing, matka guessing 143, matka 24, dpboss guessing, dp boss, online matka play, online matka" />
<link rel="canonical" href="https://spboss.in/guessing-forum.php" />

<link rel="icon" href="images1/favicon-96x96.png" type="image/gif" sizes="16x16">


<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

@media (max-width:480px){.row{padding:0;margin:0}}@media (max-width:720px){.panel-heading h2{font-size:14px;padding:5px!important}.panel-body h2{font-size:14px;padding:5px!important}}body{padding-top:70px}.navbar-header{float:none}.navbar-toggle{display:block}.navbar-collapse.collapse{display:none!important}.navbar-nav{float:none!important}.navbar-nav>li{float:none}.navbar-collapse.collapse.in{display:block!important}

/*!
 * Start Bootstrap - 4 Col Portfolio HTML Template (http://startbootstrap.com)
 * Code licensed under the Apache License v2.0.
 * For details, see http://www.apache.org/licenses/LICENSE-2.0.
 */body{padding-top:0;background-color:#fc9;color:#000;font-size:14px;font-weight:700}.container-fluid,.row{padding:0;margin:0}.portfolio-item{margin-bottom:25px}.green_bg_color{background-image:-webkit-linear-gradient(0deg,#7e8080 20%,#b1bcbe 40%,#506465 100%);color:#fff}.panel-info>.panel-heading{background-color:none}.alert-success{background-color:#121312}.alert-info2{color:#31708f;padding:0;border-bottom:2px solid #615c5c}.ss{text-shadow:0 0 3px red,0 0 5px #968512}.card1{border:0;font-weight:400;background-color:#615c5c;padding:0;margin:7px}.panel2{padding:15px;box-shadow:1px 12px 13px grey;margin-bottom:29px;border-radius:0 7px;border-left:20px solid #696666;border-right:23px solid transparent;border-top:12px solid transparent}.panel{border:2px solid #ff006c}.well-sm{margin-bottom:-4px;border-radius:0 7px;font-weight:600;color:#000}a{color:#0f0f0f;text-decoration:none}.btn-info{color:#fff;background-color:#897117;border-color:#6d736d;box-shadow:2px 3px #88888878}.btn-success{color:#fff;background-color:#897117;border-color:#6d736d;box-shadow:2px 3px #88888878}.col12{background:#8e7061;padding:0;margin-top:0;margin-bottom:20px}hr{margin-top:0;margin-bottom:15px;border:0;border-top:2px solid #e60a0a;margin-left:25%;margin-right:25%}.dropdown-menu{background:#ff0ad6;position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px 0;margin:2px 0 0;font-size:14px;text-align:left;list-style:none;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box}.s{text-shadow:2px 0 0 #800040,3px 2px 0 rgba(77,0,38,.5),3px 0 3px #ff002b,5px 0 3px #800015,6px 2px 3px rgba(77,0,13,.5),6px 0 9px #f50,8px 0 9px #802a00,9px 2px 9px rgba(77,25,0,.5),9px 0 18px #ffd500,11px 0 18px #806a00,12px 2px 18px rgba(77,66,0,.5),12px 0 30px #d4ff00,14px 0 30px #6a8000,15px 2px 30px rgba(64,77,0,.5),15px 0 45px #80ff00,17px 0 45px #408000,17px 2px 45px rgba(38,77,0,.5);color:#f0f3ea;font-size:23px}.blinking{animation:blinkingText 4.8s infinite}@keyframes blinkingText{0%{color:red}10%{color:#ff0}20%{color:#00f}40%{color:green}50%{color:pink}60%{color:orange}80%{color:#000}100%{color:brown}}.navbar-nav>li>a{padding-top:0;padding-bottom:12px}.nav>li>a{position:relative;display:block;padding:10px 15px}.form-control{font-family:Montserrat-Bold;font-size:15px;line-height:1.2;color:#333;display:block;width:100%;background:#fff;height:35px;border-radius:25px;padding:0 30px 0 53px;margin-bottom:9px}.home-game-name{font-size:24px;font-family:serif;text-transform:uppercase;font-weight:600;color:#ffef29}ul.breadcrumb{display:none}.card1 a{text-decoration:none}.a-no-underline{text-decoration:none}.h6,h6{font-size:15px}.white{color:#000}.black{color:#000}footer{margin:50px 0}.logo{padding-top:27px;color:#fff!important}.navbar{background:0 0}.navbar-nav a{color:#fff!important;margin-top:12px}.error{color:red;font-size:11px;font-weight:400}.dropdown-menu{background:#f1f1f1}.dropdown-menu li a{color:#000!important;padding:5px;margin-top:0}.dashboard-box{margin-bottom:24px;padding:20px;box-sizing:border-box}.dashbozrd-box-inner{box-shadow:0 0 4px 0 rgba(0,0,0,.08),0 2px 4px 0 rgba(0,0,0,.12);border-radius:4px;background:#fff}.legend{display:block;text-align:left;border-bottom:solid 1px #ddd;color:#444;font-weight:400;line-height:1.583em;padding-bottom:.75em;margin-bottom:1.5em;font-size:1.33em}.checkbox-container{position:relative;padding-left:18px;cursor:pointer;font-size:12px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.checkbox-container input{position:absolute;opacity:0;cursor:pointer;height:0;width:0}.checkmark{position:absolute;top:0;left:0;height:0;width:0;background-color:#eee}.checkbox-container:hover input~.checkmark{background-color:#ccc}.checkbox-container input:checked~.checkmark{background-color:#2196f3}.checkmark:after{content:"";position:absolute;display:none}.checkbox-container input:checked~.checkmark:after{display:block}.checkbox-container .checkmark:after{left:9px;top:5px;width:5px;height:6px;border:solid #fff;border-width:0 3px 3px 0;-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg)}.results h1,h2,h3,h4,h5{color:#fff;font-size:19px}.chart-table h1,.chart-table h2,.chart-table h3,.chart-table h4,.chart-table h5{color:#280098;font-size:19px}.no-pad{padding:2px}.h1,.h2,.h3,h1,h2,h3{margin-top:5px;margin-bottom:5px}.panel-chart p{color:#0c00c3;font-size:19px}.panel-chart h1,h2{color:#000;font-weight:600;font-size:25px}.heading-h3{text-shadow:1px 1px 2px #000,0 0 25px #fff,0 0 5px #b3a7a7;font-size:24px;color:#fcfcfc;font-family:serif;text-transform:uppercase}.panel-success>.panel-heading{border-color:#ff006c!important}.panel-success .panel-footer,.panel-success .panel-heading{background:gold;color:#000;padding:0;font-weight:700}.forum-post-footer1{background:gold}.forum-post-footer2{background:#dcbb00}.panel{background:0 0}.panel-info>.panel-heading{color:#31708f;background-color:#d9edf700;border-color:#ff006c}.headingBck{background-color:#00008b;color:#fff;text-align:center;box-sizing:border-box;box-shadow:0 0 20px #86757a;border-radius:16%;margin:0;padding:0}.no-padding{padding:15px 7px}.navbar-default{border:2px solid #ff006c}.panel{margin-bottom:20px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05);background:0 0}.panel-info{border:2px solid #ff006c}.panel-info .panel-heading{color:#fff}.panel-danger{border:3px solid #bd904d}.refresh-button{position:absolute;transition:opacity .6s ease-in-out;z-index:999;right:20px;bottom:20px}.like_unlike{cursor:pointer!important}.bg-grey{background:#e1e1e1!important}.form-href{color:#000}.forum-btn-b1{background-color:#f1f1f1;border-radius:0!important;color:#000;text-decoration:none;padding:4px 4px!important;min-width:108px}.forum-special-offer{background:#dd984f;border:2px solid #e0009e;color:#fff;font-weight:600;font-style:italic}.small-text-h5{font-size:16px}@media (max-width:768px){.small-text-h5{font-size:12px}.alert-info2{color:#31708f;padding:0;border-bottom:2px solid #615c5c}.form-post-top{font-size:12px}.panel-chart p{color:#0c00c3;font-size:12px}.col-md-12,.col-sm-12,.col-xs-12{padding-right:1px;padding-left:1px}}@media (max-width:767px){.nav.nav-pills.nav-justified{min-width:118px;display:flex}.btn-info{color:#fff;background-color:#897117;border-color:#6d736d;box-shadow:2px 3px #88888878;width:100%;margin-top:10px}input#btnSubmit{width:100%}.dropdown-menu li a{color:#f1eeee!important;padding:5px;margin-top:0}}.welcome h3{text-align:center!important;font-size:25px;color:red}
 
 


.well-sm{background-color:#6ff;color:red}.forum-special-offer{background-color:#fff;border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;box-shadow:0 2px 10px rgba(0,0,0,.3);overflow:hidden;max-width:470px;margin:0 auto 0;color:#000}.h4,.h5,.h6,h4,h5,h6{margin-top:0;margin-bottom:0}html{overflow-x:hidden;scroll-behavior:smooth}body{background-color:#fc9;text-align:center;padding:3px 0px;margin:0;scroll-behavior:smooth;font-family:Helvetica,sans-serif;font-weight:700;padding-bottom:90px}*{margin:0;padding:0;box-sizing:border-box}a,a:hover{text-decoration:none}.btn{display:inline-block;font-weight:400;color:#212529;text-align:center;vertical-align:middle;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:1px solid transparent;padding:.375rem .75rem;font-size:1rem;line-height:1.5;border-radius:.25rem}.forum-rules1 h4{background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);font-size:22px;padding:6px 5px 5px;color:#fff;background-color:#006064;box-shadow:0 0 10px -7px #000}.forum-rules1{border:2px solid #eb008b;border-radius:10px 0 10px 10px}.forum-rules div,.login-area,.para1 p{border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;overflow:hidden}.forum-rules h4,.login-area h4{background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);font-size:22px;padding:6px 5px 5px;color:#fff;background-color:#006064;box-shadow:0 0 10px -7px #000}.logo-div{border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;overflow:hidden}.logo-div img{width:180px;height:auto;margin-top:7px}.para1 p{line-height:1.4;font-size:14px;margin-top:5px;margin-bottom:5px;font-weight:600;border-radius:5px;padding:5px 10px}.para1 a{color:#e91e63}.forum-rules div{border-radius:10px;margin-top:5px}.forum-rules ul{list-style:none;text-align:left;padding:20px 20px 0}.forum-rules li{font-size:18px;text-shadow:1px 1px 2px #ffcad2;font-weight:600;word-spacing:2px;color:#000;padding-bottom:4px;font-family:monospace;margin-bottom:5px;border-bottom:1px solid #7a0029}.forum-rules p{margin-top:20px;font-size:13px;margin-bottom:10px}.forum-rules p span{color:#e91e63}.login-area{margin:10px 0;padding-bottom:10px}.login-area h2{margin-top:5px}.login-area .my-btn22{border:2px solid #219826;background-color:#4caf50;border-radius:15px 0;box-shadow:0 0 1px #000000d6;display:block;text-shadow:1px 1px 4px #333;padding:12px 0;text-align:center;color:#fff;font-size:18px;margin:15px auto;transition:ease-in-out all .3s;width:50%}.login-area a.btn-aa:hover{background-image:linear-gradient(-45deg,#9c27b0 50%,#9c27b0 50%);box-shadow:0 0 10px -3px #000;border-color:#0ff}.form-control{display:block;width:100%;height:calc(1.5em + .75rem + 2px);padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}.login-area select,.login-area textarea{display:block;margin:10px auto;width:95%;border:2px solid #f24790}.login-area select{padding:10px;height:auto}.login-area textarea{height:250px;font-size:17px}.login-area select:focus,.login-area select:hover,.login-area textarea:focus,.login-area textarea:hover{border:2px solid red;outline:0}.extra-feature h5{color:#e91e63;margin-bottom:10px}.extra-feature a{padding:3px 10px;box-shadow:0 0 10px -7px #000;transition:all .3s;color:#fff;font-size:15px}.extra-feature .btn-aa1{background-color:#9c27b0}.extra-feature .btn-bb1{background-color:#e91e63;margin-left:10px;margin-right:10px}.extra-feature .btn-cc1{background-color:#9c27b0}.extra-feature a:hover{box-shadow:0 0 10px -5px #000}.quote-card-div{margin-top:20px}.quote-card-div .my-card{margin-top:10px;overflow:hidden;border:2px inset #d00047;border-radius:5px;box-shadow:0 0 10px -5px #000;background-image:linear-gradient(45deg,#ffc58a 50%,transparent 50%)}.quote-card-div .card-head{display:flex;justify-content:space-between;padding:10px 13px;font-size:18px;background-color:#d00047;border-bottom:2px solid #d00047}.quote-card-div .card-head a{font-style:italic}.quote-card-div .card-head a:hover{text-decoration:underline}.quote-card-div .card-head h5{font-family:serif;letter-spacing:1px;font-size:12px;align-self:center}.quote-card-div .card-head a,.quote-card-div .card-head h5{text-shadow:1px 1px 2px #000;color:#fff}.quote-card-div .card-body{padding-top:0px}.card-body p{text-shadow:1px 1px 2px #ffcad2;padding-top:7px}.quote-card-div .card-body p:last-child{padding-bottom:10px;margin-top:6px}.quote-card-div .card-footer{display:flex;justify-content:space-around;border-top:2px solid #01514a}.quote-card-div .card-footer .card-btn{padding:8px 0;color:#000;text-shadow:1px 1px 2px #fff;width:100%;transition:all .3s}.quote-card-div .card-footer .btn-11{background-color:#00ff7f;border-right:1px solid #000}.quote-card-div .card-footer .btn-22{border-right:1px solid #000;background-color:#0ff}.quote-card-div .card-footer .btn-33{background-color:#87ceeb}.quote-card-div .card-footer .card-btn:hover{color:#000;text-shadow:1px 1px 2px #fff;background-color:#ff0}.page-no{margin:20px 0 5px}.page-no ul{display:flex;list-style:none;justify-content:center;border-radius:10px 0 10px 10px}.page-no li{display:block;width:29px;background-color:red;margin:0 3px;border-radius:10px}.page-no .active,.page-no li:hover{background-color:#900031}.page-no li a{color:#fff;line-height:2}.fixed-footer{padding:0;display:flex;position:fixed;bottom:0;left:0;width:100%;box-shadow:0 -2px 13px -3px #000}.fixed-footer>div{width:25%;padding:0}.fixed-footer a{background-color:#900031;display:flex;justify-content:center;align-items:center;color:#fff;border-left:1px solid #6f0026;transition:all .3s;flex-direction:column;padding:12px 0 6px}.fixed-footer>div:first-child a{border-left-width:0}.fixed-footer a:hover{color:#fff;background-color:#710027;text-shadow:1px 1px 2px #333}.fixed-footer a svg{margin-bottom:8px;font-size:24px}.fixed-footer a span{display:block}@media only screen and (max-width:768px){.login-area textarea:focus+.fixed-footer{display:none}}@media only screen and (max-width:500px){.fixed-footer a{font-size:12px}.page-no-ul li{padding:5px 8px;font-size:13px}.fixed-footer a svg{font-size:18px}}@media only screen and (max-width:375px){.fixed-footer a span{height:27px}}.switch{position:relative;display:inline-block;width:60px;height:34px}.switch input{opacity:0;width:0;height:0}.slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#df1f6d;-webkit-transition:.4s;transition:.4s}.slider:before{position:absolute;content:"";height:26px;width:26px;left:4px;bottom:4px;background-color:#fff;-webkit-transition:.4s;transition:.4s}input:checked+.slider{background-color:#2196f3}input:focus+.slider{box-shadow:0 0 1px #2196f3}input:checked+.slider:before{-webkit-transform:translateX(26px);-ms-transform:translateX(26px);transform:translateX(26px)}.slider.round{border-radius:34px}.slider.round:before{border-radius:50%}i.fa.fa-user.icon{padding-left:14px;position:absolute;padding-top:10px}i.fa.fa-key.icon{padding-left:14px;position:absolute;padding-top:10px}.panel-heading{color:#fff!important}.white{color:#fff}.modal-body{height:60vh;overflow-y:scroll;overflow-x:hidden;margin-top:10px}.modal-open{padding-right:0!important}.login-area input{display:block;margin:0 auto;width:95%;border:2px solid #f24790;font-size:17px}.btn-mahi{cursor:pointer;background-color:#e91e63;border:2px solid #e91e63;border-radius:4px;color:#fff;display:block;font-size:20px;padding:10px;margin-top:20px;width:100%;text-transform:uppercase;font-weight:700;display:block;margin:10px auto;width:95%;border:2px solid #f24790;font-size:17px}.btn-mahi:hover{color:#fff}:root{--success-color:#2ecc71;--error-color:#e74c3c}*{box-sizing:border-box}h2{text-align:center;margin:0 0 20px;color:#e91e63}.form{padding:30px 40px;width:inherit}#signup-form{background-color:#fff;border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;box-shadow:0 2px 10px rgba(0,0,0,.3);overflow:hidden;max-width:470px;margin:0 auto 0}.form-control{margin-bottom:10px;padding-bottom:10px;position:relative}.form-control label{color:#e91e63;display:block;margin-bottom:5px;font-weight:700;font-size:18px;margin:0 0 10px}.form-control input{border:1px solid #e91e63;border-radius:4px;display:block;width:100%;padding:10px;font-size:14px}.form-control input:focus{outline:0;border-color:#777}.form-control.success input{border-color:var(--success-color)}.form-control.error input{border-color:var(--error-color)}.form-control small{color:var(--error-color);position:absolute;bottom:0;left:0;visibility:hidden}.form-control.error small{visibility:visible}.form button{cursor:pointer;background-color:#e91e63;border:2px solid #e91e63;border-radius:4px;color:#fff;display:block;font-size:20px;padding:10px;margin-top:20px;width:100%;text-transform:uppercase;font-weight:700}.form_error{color:#d83d5a}input::-webkit-inner-spin-button,input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}input[type=date]{-moz-appearance:textfield}@media only screen and (max-width:768px){.container{width:580px}}@media only screen and (max-width:500px){.container{display:block;width:92%;justify-content:space-between}.form{padding:20px 25px;width:initial}}input.if_input_state:focus{outline:0;border-color:#777}.if_label_state{color:#777;display:block;margin-bottom:15px;margin-top:-10px}input#mobileno,select#scripts{border:2px solid #f0f0f0;border-radius:4px;display:block;width:100%;padding:10px 10px;font-size:14px}select#scripts{font-size:13px}input#mobileno:focus,select#scripts:focus{outline:0;border-color:#777}.dd-option.dd-option-selected{display:flex}ul.dd-options a{width:110px;overflow-x:hidden}ul.dd-options{width:100px!important;overflow-x:hidden}.dd-option.dd-option-selected li{width:110px}.dd-option-image,.dd-selected-image{width:30px!important;margin-top:3px;height:auto!important}a.dd-option{height:35px;padding:5px}#slick a.dd-selected{height:35px;padding:5px;display:flex}#slick{width:30%!important;float:left;z-index:7;margin-top:10px}.dd-selected-text{line-height:30px!important}.dd-select{width:90px!important}#mobileno{width:65%!important;margin-top:10px;float:right}.container{margin-bottom:300px}.dd-pointer.dd-pointer-down{visibility:hidden}.dateofbirth{margin-top:60px}.dd-selected{display:flex}.closebtn{margin-left:15px;color:#fff;font-weight:700;font-size:22px;line-height:20px}.closebtn:hover{color:#000}.mmm{text-align:center;margin-left:auto;margin-right:auto;background-color:#4caf50!important;border:2px solid #4caf50!important;border-radius:4px;color:#fff;display:block;font-size:16px;padding:10px;margin-top:20px;width:100%}.modal{display:none;position:fixed;z-index:1;padding-top:100px;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:#000;background-color:rgba(0,0,0,.4)}.modal-content{background-color:#fefefe;margin:auto;padding:20px;border:1px solid #888;width:20%}.close{color:#aaa;float:right;font-size:28px;font-weight:700}.close:focus,.close:hover{color:#000;text-decoration:none;cursor:pointer}.modal-content .modal-input{border:2px solid #f0f0f0;border-radius:4px;display:block;width:100%;padding:10px;font-size:14px;margin-right:10px;margin-left:10px}#myModal{z-index:9}.btn.btn-success{text-align:center;margin-left:auto;margin-right:auto;background-color:#4caf50!important;border:2px solid #4caf50!important;border-radius:4px;color:#fff;display:block;font-size:16px;padding:10px;margin-top:20px;width:100%}#slick2{width:120px!important}#slick2 .dd-selected{display:flex}.d-flex{display:flex}.modal-content{width:30%}@media only screen and (max-width:768px){.modal-content{width:50%}}@media only screen and (max-width:500px){.modal-content{width:75%}}.col-md-12,.col-sm-12,.col-xs-12{padding-right:5px;padding-left:5px}@media (max-width:768px){.col-md-10,.col-md-12,.col-sm-12,.col-xs-12{padding-right:0;padding-left:0}}.chart-00,.chart-11,.chart-22,.chart-33,.chart-44,.chart-55,.chart-66,.chart-77,.chart-88,.chart-99,.chat-05,.chat-16,.chat-27,.chat-38,.chat-49,.chat-50,.chat-61,.chat-72,.chat-83,.chat-94{color:red!important}.footer-btn{text-align:center;font-size:14px;padding:8px;display:grid;color:#414141;margin:5px}.footer-btn a{font-size:inherit;color:inherit;display:inherit;text-decoration:none}.container-fluid{padding-right:0!important;padding-left:0!important}


.well-sm {
    border-radius: 3px;
    border: 0px !important;
    box-shadow: none !important;
}
.well-sm {
    padding: 0px;
	margin: 0px 7px !important;
	background:#fff3e8;
	color: #564949;
}
</style><Style>
.admin_block a {
    background: white;
}

.form-group {
    margin-bottom: 0px;
}

.show_more_main {
    margin: 30px 0px 0px 0px;
}
.show_more {
    background-color: #f8f8f8;
    background-image: -webkit-linear-gradient(top,#fcfcfc 0,#f8f8f8 100%);
    background-image: linear-gradient(top,#fcfcfc 0,#f8f8f8 100%);
    border: 1px solid;
    border-color: #fff;
	cursor: pointer;
padding: 10px;
background: #900031;
color: white;
font-size: 15px;
}
   
   
.admin-img{width: 25px;margin-left: 10px;box-shadow: 0px 0px 3px white;border-radius: 32px;}
.ex-feature{margin-top: 5px;background-color: #9c27b0;color:white;padding: 3px 10px;box-shadow: 0 0 10px -7px #000;font-size: 15px;}
.card-footer a{cursor:pointer;}
.dddd{margin-top:10px;line-height: 2;}
.qcd{margin-top: 20px;}
.wwh {
  padding: 0;
  margin: 0 0 !important;
  background: yellow;
  color: #730000;
  border-radius: 3px;
  border: 0 !important;
  box-shadow: none !important;
  font-weight: 600;
}

.notlogged {
  height: 100px !important;
}
</style>
</head>
<body id="bodyId">
<div class="container-fluid">
<div class="logo-div">
<a href="#">
<img src="images1/logo.webp" alt>
</a>
</div>
</div>

<div class="container-fluid">
<div class="para1">
<div style="line-height: 1.4;border: 2px solid #eb008b;font-size: 12px;margin-top: 5px;margin-bottom: 5px;font-weight: 600;padding: 5px 10px;">
<h1 style="font-size: 20px;font-weight: bold;">Dpboss Satta Matka Guessing Kalyan Main Bazar Madhur Matka</h1>Dpboss Satta Matka Guessing Forum For Kalyan Milan Main Bazar Rajdhani Madhur Matka Time Bazar Morning Madhur Sridevi All Matka Guessing Open To Close Free Ank Kalyan Fix Jodi Aaj Ke Liye Today Locky Fix Matka Satta Number Satta Matka 143 24 69Games satta king Matta Batta Online Matka Play Trusted Best सात्त मटका कल्याण मधुर मटका रेसुल्ट ऑनलाइन प्ले<br>
<a style="
      background: yellow;
padding: 6px 5px 5px;
color: #0c0c0c;
display: block;
font-size: 14px;
margin: 10px 0 10px;
border: 2px solid #fff;
box-shadow: 0 0 10px -5px #000;
      ">Duniya Ko Dikhao Apni Guessing Ka Jalwa, Guessing Post Karne Ke Liye Application Download Kare<br></a><a href="https://app.dpbossx.net/apk/com.dpbosss.forum.main_303.apk" style="font-size: 10px;padding: 6px 5px 5px;color: #fff;background-color: #080808;box-shadow: 0 0 10px -7px #000;display: inline;font-size: 14px;margin: 10px 0 15px;border: 2px solid #fff;border-radius: 6px;box-shadow: 0 0 10px -5px #000;"><big><b>Click Here to Downlod App</b></big>
</a></div>
</div>
<div style="line-height: 1.4;border: 2px solid #eb008b;font-size: 13px;margin-top: 5px;margin-bottom: 5px;font-weight: 600;padding: 5px 10px;padding: 5px 0px 0px 0px;">
<b>-:Posting Rules:-</b>
<br>
3 OPEN YA CLOSE<br>
6 JODI<br>
AUR 8 PANNA<br>
AUR RESULT TIME SE 15 MIN PHELE GAME POST KARNA HOGA....!!!!<br>
Dont Mention Date Or Time In Your Post.<br>
<a style="background-color: #0d0d0d;color:white;padding: 3px 10px;box-shadow: 0 0 10px -7px #000;font-size: 16px;width: 100%;display: inline-block;" href="forum-rules.php">Click Here To Read Full Guessing Forum Rules</a>
</div>
<div style="line-height: 1.4;border: 2px solid #eb008b;font-size: 15px;margin-top: 5px;margin-bottom: 5px;font-weight: 600;padding: 5px 0px 0px 0px;color: navy;">
Play Matka Online <br>
101% Trusted - Fast Withdrawl<br>
<a href="https://jodi99.com/" target="_blank" style="color: red;"> Download Now </a>
</div>
<div style="clear: both">&nbsp;</div>
<div class="col-md-12 forum-post-list">
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
ADMINSIR
<img src="images1/user.png" class="admin-img" alt="Admin">
</a>
<h5>02 Oct 2024 11:10 AM</h5>
</div>
<div class="card-body">
<p class="eeee">🌹 KALYAN MORNING 🌹<br> 238-3</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
NIRMA BHAI
</a>
<h5>02 Oct 2024 11:08 AM</h5>
</div>
<div class="card-body">
<p class="eeee">SRIDEVI<br><br>11--15<br/><br/>16--01<br/><br/>05--06<br/><br/>127--677--128--227</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
Omkarkhammam
</a>
<h5>02 Oct 2024 10:52 AM</h5>
</div>
<div class="card-body">
<p class="eeee">MILAN MORNING CLOSE<br><br>🌹. Milan morning close. 🌹<br/><br/><br/><br/> 2<br/><br/><br/> 🤘</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
dubai ka bap
</a>
<h5>02 Oct 2024 10:51 AM</h5>
</div>
<div class="card-body">
<p class="eeee">SRIDEVI<br><br>02<br/><br/><br/>01</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
vk
<img src="images1/user.png" class="admin-img" alt="Admin">
</a>
<h5>02 Oct 2024 10:46 AM</h5>
</div>
<div class="card-body">
<p class="dddd"><div class="wwh">Original Posted By: A1786<br><div class="wwh">Original Posted By: A1786<br> KARNATAKA DAY<br><br>333333====355==238==580<br/><br/>555555====357==258==348<br/><br/>888888====350==378=====<br/><br/>Jodi 39==30==59==58==89==80<br/>Gl....king khan....</div><br> 3333333333🤗😎😎😎🤗🤗</div> </p>
<p class="eeee">Congratulations 🎉❤️</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
A1786
</a>
<h5>02 Oct 2024 10:44 AM</h5>
</div>
<div class="card-body">
<p class="dddd"><div class="wwh">Original Posted By: A1786<br> KARNATAKA DAY<br><br>333333====355==238==580<br/><br/>555555====357==258==348<br/><br/>888888====350==378=====<br/><br/>Jodi 39==30==59==58==89==80<br/>Gl....king khan....</div> </p>
<p class="eeee">3333333333🤗😎😎😎🤗🤗</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
SANA77
</a>
<h5>02 Oct 2024 10:24 AM</h5>
</div>
<div class="card-body">
<p class="eeee">SRIDEVI<br><br>.<br/><br/><br/><br/><br/><br/><br/><br/>42<br/>48<br/>93<br/>97<br/><br/>248 ___ 360<br/><br/><br/><br/><br/><br/><br/><br/><br/>.</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
ArhamBahal
</a>
<h5>02 Oct 2024 10:07 AM</h5>
</div>
<div class="card-body">
<p class="eeee">MADHUR DAY<br><br>4.5.9<br/><br/>Play Now</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
ArhamBahal
</a>
<h5>02 Oct 2024 10:06 AM</h5>
</div>
<div class="card-body">
<p class="eeee">MILAN DAY<br><br>3/4/5<br/><br/><br/>Play Now</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
ArhamBahal
</a>
<h5>02 Oct 2024 10:06 AM</h5>
</div>
<div class="card-body">
<p class="eeee">TIME BAZAR<br><br>2/3/7<br/><br/>Play Now</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
ArhamBahal
</a>
<h5>02 Oct 2024 10:06 AM</h5>
</div>
<div class="card-body">
<p class="eeee">SRIDEVI<br><br>4.7.0<br/><br/>Play Now</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
A1786
</a>
<h5>02 Oct 2024 09:58 AM</h5>
</div>
<div class="card-body">
<p class="eeee">MADHURI<br><br>BHOT HARD GAME H DONT MISS....<br/><br/>SINGLE ANK 11111111<br/>146==669==489==560<br/><br/>LITTLE ANK 66666666<br/>169==466==457==150<br/><br/>Jodi 14==19==18==64==69==68<br/>Gl....FULL POWER PLAY MY FOLLOWERS ...KING KHAN...</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
A1786
</a>
<h5>02 Oct 2024 09:55 AM</h5>
</div>
<div class="card-body">
<p class="eeee">SRIDEVI<br><br>7777777====278==890======<br/><br/>8888888====378==800==170<br/><br/>0000000====370==280==578<br/><br/>Jodi 70==80==02==08==89==78<br/>Gl.....full printed king khan....</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
A1786
</a>
<h5>02 Oct 2024 09:52 AM</h5>
</div>
<div class="card-body">
<p class="eeee">KALYAN MORNING<br><br>3333333===238==337==788<br/><br/>7777777===368==377==278<br/><br/>8888888===378==170=====<br/><br/>Jodi 31==30==79==78==89==81<br/>Gl....king khan...</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
A1786
</a>
<h5>02 Oct 2024 09:50 AM</h5>
</div>
<div class="card-body">
<p class="eeee">KARNATAKA DAY<br><br>333333====355==238==580<br/><br/>555555====357==258==348<br/><br/>888888====350==378=====<br/><br/>Jodi 39==30==59==58==89==80<br/>Gl....king khan....</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
A1786
</a>
<h5>02 Oct 2024 09:46 AM</h5>
</div>
<div class="card-body">
<p class="eeee">MILAN MORNING<br><br>3333333===346==670==337<br/><br/>6666666===367==259==150<br/><br/>7777777===368==467======<br/><br/>Jodi 39==31==69==62==78==79<br/>GL...KING KHAN.</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
king3030
</a>
<h5>02 Oct 2024 09:16 AM</h5>
</div>
<div class="card-body">
<p class="eeee">KALYAN<br><br>Only kalyan<br/>22--------------------27<br/><br/>72--------------------77<br/><br/>11--------------------16</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
arunt43
</a>
<h5>02 Oct 2024 09:04 AM</h5>
</div>
<div class="card-body">
<p class="eeee">KALYAN MORNING<br><br>KALYAN MORNING <br/><br/>330====66/69<br/>OPENINGS</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
arunt43
</a>
<h5>02 Oct 2024 09:00 AM</h5>
</div>
<div class="card-body">
<p class="dddd"><div class="wwh">Original Posted By: vk<br> Last Warning<br/><br/>arunt43<br/><br/>Game Fail Hone Ke Bad Cut Ya Palti Mai Post Quote Na Kare<br/><br/>Otherwise Your Id Blocked Permanently<br/>Follow Site Rules..</div> </p>
<p class="eeee">Ok</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
arunt43
</a>
<h5>02 Oct 2024 08:54 AM</h5>
</div>
<div class="card-body">
<p class="eeee">MILAN MORNING<br><br>MILAN MORNING <br/><br/>SINGAL =========4<br/>MIS==2/5<br/><br/>690/770<br/>660/679<br/><br/>49/50<br/>27/25<br/>OPENING</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
Rockybhai7
</a>
<h5>02 Oct 2024 07:34 AM</h5>
</div>
<div class="card-body">
<p class="eeee">MILAN MORNING<br><br>(((((((((((((((((((85))))))))))))))))))))<br/> (((((80___35___30))))))<br/> (((((((((24____25)))))))) <br/> ((((260__670__246))))))</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
Rockybhai7
</a>
<h5>02 Oct 2024 07:08 AM</h5>
</div>
<div class="card-body">
<p class="dddd"><div class="wwh">Original Posted By: SANA77<br><div class="wwh">Original Posted By: Rockybhai7<br><div class="wwh">Original Posted By: arunt43<br><div class="wwh">Original Posted By: Rockybhai7<br><div class="wwh">Original Posted By: Yndy<br><div class="wwh">Original Posted By: Rockybhai7<br><div class="wwh">Original Posted By: SINGLEKILLER143<br><div class="wwh">Original Posted By: sonuji1983<br><div class="wwh">Original Posted By: vk<br><div class="wwh">Original Posted By: Dinesh Sahani<br><div class="wwh">Original Posted By: vk<br><div class="wwh">Original Posted By: Rockybhai7<br> RAJDHANI NIGHT<br><br>(((((((((((((((((15))))))))))))))))<br/> ((((((((18__65__68)))))</div><br> Congratulations</div><br> Big congratulations sir ji</div><br> Congratulations 🎉&hearts;️</div><br> Congratulations rocky yaar</div><br> Congratulations bhai</div><br> Tq <br/>Vk sir <br/>Dinesh savani bhai<br/>Sonuji bhai<br/>Single killer bhai</div><br> Congratulations Bhai</div><br> Tq yndy bhai</div><br> Big congratulations brother</div><br> Tq arunt43 bhai</div><br> Congratulations bhai</div> </p>
<p class="eeee">Tq sana bhai</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
vk
<img src="images1/user.png" class="admin-img" alt="Admin">
</a>
<h5>02 Oct 2024 06:24 AM</h5>
</div>
<div class="card-body">
<p class="eeee">Posting Rules<br/><br/>3 OPEN YA CLOSE<br/>6 JODI<br/>AUR 8 PANNA<br/>AUR RESULT TIME SE 15 MIN PHELE GAME POST KARNA HOGA....!!!!<br/>Dont Mention Date Or Time In Your Post</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
SANA77
</a>
<h5>02 Oct 2024 02:08 AM</h5>
</div>
<div class="card-body">
<p class="dddd"><div class="wwh">Original Posted By: Rockybhai7<br><div class="wwh">Original Posted By: arunt43<br><div class="wwh">Original Posted By: Rockybhai7<br><div class="wwh">Original Posted By: Yndy<br><div class="wwh">Original Posted By: Rockybhai7<br><div class="wwh">Original Posted By: SINGLEKILLER143<br><div class="wwh">Original Posted By: sonuji1983<br><div class="wwh">Original Posted By: vk<br><div class="wwh">Original Posted By: Dinesh Sahani<br><div class="wwh">Original Posted By: vk<br><div class="wwh">Original Posted By: Rockybhai7<br> RAJDHANI NIGHT<br><br>(((((((((((((((((15))))))))))))))))<br/> ((((((((18__65__68)))))</div><br> Congratulations</div><br> Big congratulations sir ji</div><br> Congratulations 🎉&hearts;️</div><br> Congratulations rocky yaar</div><br> Congratulations bhai</div><br> Tq <br/>Vk sir <br/>Dinesh savani bhai<br/>Sonuji bhai<br/>Single killer bhai</div><br> Congratulations Bhai</div><br> Tq yndy bhai</div><br> Big congratulations brother</div><br> Tq arunt43 bhai</div> </p>
<p class="eeee">Congratulations bhai</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="quote-card-div">
<div class="my-card">
<div class="card-head">
<a href="#">
SANA77
</a>
<h5>02 Oct 2024 02:07 AM</h5>
</div>
<div class="card-body">
<p class="dddd"><div class="wwh">Original Posted By: ArhamBahal<br><div class="wwh">Original Posted By: ADMINSIR<br><div class="wwh">Original Posted By: vk<br><div class="wwh">Original Posted By: ArhamBahal<br> MILAN NIGHT CLOSE<br><br>2/3/7<br/><br/> Play Now</div><br> Congratulations</div><br> Congratulations</div><br> Thank you Admin Sir <br/><br/>Thank you vk Bhai</div> </p>
<p class="eeee">Congratulations bhai</p>
</div>
<div class="card-footer">
<a href="#" class="card-btn btn-11">[Quote]</a>
<a onClick="topFunction()" class="card-btn btn-22">[Top]</a>
<a onClick="bottomFunction()" class="card-btn btn-33">[Down]</a>
</div>
</div>
</div>
<div class="show_more_main" id="show_more_main7314170">
<span id="7314170" class="show_more" title="Load more posts">Show more / Next Page</span>
<span class="loding" style="display: none;"><span class="loding_txt">Loading...</span></span>
</div>
</div>
</div>
<div style="clear: both">&nbsp;</div>

<center> <a href="https://matkabookings.com"><img src="https://spboss.in/images1/RS3.webp" alt="Online Matka Play"></a></center>
<div class="fixed-footer">
<div style="width:30%">
<a href="https://spboss.in/">
<i class="fa fa-home"></i>
<span>Go to Home</span>
</a>
</div>
<div style="width:40%">
<a href="https://matkabookings.com">
<i class="fa fa-android"></i>
<span>Matka Play (New)</span>
</a>
</div>
<div style="width:30%">
<a onClick="window.location.reload();" style="cursor: pointer;">
<i class="fa fa-refresh"></i>
<span>Refresh</span>
</a>
</div>
</div>

<script src="SITEURLjs/jquery.js"></script>

<script src="SITEURLjs/bootstrap.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="SITEURLjs/vendor/jquery-1.11.0.min.js"></script>
<script src="SITEURLjs/plugins.js"></script>
<script src="SITEURLjs/main.js"></script>
<script type="text/javascript">

	        $('#taMessage').bind('keydown', function(event) {
            var market_name_str = $("#game_name").val();
            if (market_name_str !== '') {
                $("#err_select_market_name").html("");
            } else {
                $("#err_select_market_name").html("Please Select Market First");
                $("#taMessage").val('');
            }
        });
        $('#taMessage').on('blur', function(event) {
            var market_name_str = $("#game_name").val();
            if (market_name_str !== '') {
                $("#err_select_market_name").html("");
            } else {
                $("#err_select_market_name").html("Please Select Market First");
                $("#taMessage").val('');
            }
        });
	


function marketNameAppend(){
	
	
	var e = document.getElementById("game_name");
	document.getElementById("market_name_div").innerHTML = e.value;
}


$(document).ready(function(){
    $(document).on('click','.show_more',function(){
        var ID = $(this).attr('id');
        $('.show_more').hide();
        $('.loding').show();
        $.ajax({
            type:'POST',
            url:'ajax_more.php',
            data:'id='+ID,
            success:function(html){
                $('#show_more_main'+ID).remove();
                $('.forum-post-list').append(html);
            }
        });
    });
});
</script>
<script src="SITEURLjs/jquery.validate.min.js"></script>
<script>
		$(function() {
			$("#form1").validate({
				rules: {
					taMessage: 'required',
				},				
				submitHandler: function(form) {
					form.submit();
				}
			});
		});
	</script>
</body>
</html>
